/*
 * @Author: torii
 * @Date: 2023-03-13 10:49:26
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2023-03-22 16:26:54
 * @FilePath: \wkp-demo\assets\js\style.js
 * @Description: 
 * 
 * Copyright (c) 2023 by ${git_name_email}, All Rights Reserved. 
 */


 
$(".openbtn4").click(function () {
  $(this).toggleClass("active");
  $('#container').toggleClass('back-blur');
});

$(".openbtn1").click(function () {
  //ボタンがクリックされたら
  $(this).toggleClass("active"); //ボタン自身に activeクラスを付与し
});



//画面リサイズの後サイドバーメニューの表示設置

const resize = ()=>{
 
  let timeoutID = 0;
  let delay = 500;

  window.addEventListener("resize", ()=>{
      clearTimeout(timeoutID);
      timeoutID = setTimeout(()=>{

          //ここにリサイズした後に実行したい処理を記述
          $(function () {
            if (window.matchMedia('(min-width: 992px)').matches) {
              $('#js-navbarNav').addClass("show");
            }
            else{
              $('#js-navbarNav').removeClass("show");
              $('#container').removeClass('back-blur');
            }   
          });
          console.log("resize");

      }, delay);
  }, false);
};
resize();

//sidebar dropdown js

$(function () {
  var Accordion = function (el, multiple) {
    this.el = el || {};
    this.multiple = multiple || false;

    // Variables privadas
    var links = this.el.find(".link");
    // Evento
    links.on("click", { el: this.el, multiple: this.multiple }, this.dropdown);
  };

  Accordion.prototype.dropdown = function (e) {
    var $el = e.data.el;
    ($this = $(this)), ($next = $this.next());

    $next.slideToggle();
    $this.parent().toggleClass("open");

    if (!e.data.multiple) {
      $el.find(".submenu").not($next).slideUp().parent().removeClass("open");
    }
  };

  var accordion = new Accordion($("#accordion"), false);
});