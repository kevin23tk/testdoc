
/////////////////////////////Loading モーダルを開く Start/////////////////////////////

function ShowModalWindow(arrParam) {
    let openModal = document.getElementById('modal-loader');
    if (arrParam ==="on"){
        alert("AAA");
        openModal.style.display = "block"; // 显示 div
    }
    if (arrParam ==="off"){
        // openModal.style.display = "none"; // 隐藏 div
    }
}

/////////////////////////////Loading モーダルEnd /////////////////////////////