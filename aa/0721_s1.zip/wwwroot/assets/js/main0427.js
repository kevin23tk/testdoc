

  /**   
  *ドロップダウンリストのオプションを動的に作成する。        
  *データベースからデータを読み込んで動的に作成することができる。        
  */

$(document).ready(function() {
  $("#add").click(function() {
    if ($("#fb_list option:selected").length > 0) {
      $("#fb_list option:selected").each(function() {
        $("#select_list").append("<option value='" + $(this).val() + "'>" + $(this).text() + "</option>");
        $(this).remove();
      });
    }
  });
  
  $("#delete").click(function() {
    if ($("#select_list option:selected").length > 0) {
      $("#select_list option:selected").each(function() {
        $("#fb_list").append("<option value='" + $(this).val() + "'>" + $(this).text() + "</option>");
        $(this).remove();
      });
    }
  });

  function sel() {
    var obj = document.getElementById('fb_list');
    var str = "";
    for (var i = 0; i < obj.options.length; i++) {
      if (str.length > 0) str = str + "," + obj.options[i].value;
      else str = obj.options[i].value;
    }
    alert(str);
  }
  
  $("#btnMoveUp, #btnMoveDown").click(function() {
    var $opt = $("#select_list option:selected:first");
    if (!$opt.length) return;
    if (this.id == "btnMoveUp") $opt.prev().before($opt);
    else $opt.next().after($opt);
  });
  
  $("#btnMoveUpTop, #btnMoveDownBot").click(function() {
    var $opt = $("#select_list option:selected:first");
    if (!$opt.length) return;
    if (this.id == "btnMoveUpTop") $("#select_list option:nth-child(2)").prev().before($opt);
    else $opt.appendTo("#select_list");
  });

  $("#select_list").keydown(function(evt) {
    if (!evt.altKey) return;
    var k = evt.which;
    if (k == 38) {
      $("#btnMoveUp").click();
      return false;
    } else if (k == 40) {
      $("#btnMoveDown").click();
      return false;
    }
  });
});


//　右上のハンバーガーメニュー
const rightHugButton = document.getElementById("rightHugBtn");
const contContainer = document.getElementById("container");
  rightHugButton.addEventListener("click", function() {
    if (this.classList.contains("active")) {
      this.classList.remove("active");
      } else {
      this.classList.add("active");
      }
  });
//    contContainer.toggleClass('back-blur');

 //　左上のハンバーガーメニュー 
 const leftHugButton = document.getElementById("leftHugBtn");
leftHugButton.addEventListener("click", function() {
    //ボタンがクリックされたら
    if (this.classList.contains("active")) {
      this.classList.remove("active");
      } else {
      this.classList.add("active");
      }
  });
 

  
  //画面リサイズの後サイドバーメニューの表示設置
  
  const resize = ()=>{
   
    let timeoutID = 0;
    let delay = 500;
  
    window.addEventListener("resize", ()=>{
        clearTimeout(timeoutID);
        timeoutID = setTimeout(()=>{
  
            //ここにリサイズした後に実行したい処理を記述
        if (window.matchMedia('(max-width: 992px)').matches) {
        // $('#js-navbarNav').addClass('show');
        // } else {
        $('#js-navbarNav').removeClass('show');
        $('#container').removeClass('back-blur');
        }
  
        }, delay);
    }, false);
  };
  resize();
  
  
  
  //サイドメニュー　ドロップダウン
  
  $(function () {
    var Accordion = function (el, multiple) {
      this.el = el || {};
      this.multiple = multiple || false;
  
      // Variables privadas
      var links = this.el.find(".link");
      // Evento
      links.on("click", { el: this.el, multiple: this.multiple }, this.dropdown);
    };
  
    Accordion.prototype.dropdown = function (e) {
      var $el = e.data.el;
      ($this = $(this)), ($next = $this.next());
  
      $next.slideToggle();
      $this.parent().toggleClass("open");
  
      if (!e.data.multiple) {
        $el.find(".submenu").not($next).slideUp().parent().removeClass("open");
      }
    };
  
    var accordion = new Accordion($("#accordion"), false);
  });
  
/////////////////////////////テーブルの行をクリックしたら、背景色を変更する //////////////////////////

const table = document.querySelector('#searchDataTable');
const rows = [...table.getElementsByTagName('tr')];


for (let i = 0; i < rows.length; i++) {
  const row = rows[i];
  row.addEventListener('click', function() {
    // Remove selection from other rows
    for (let j = 0; j < rows.length; j++) {
      rows[j].classList.remove('selected');
      rows[j].querySelector('.arrow')?.remove();
    }
    
    // Add selection to current row
    this.classList.add('selected');
    
    // Add arrow to current row's first cell
    const arrow = document.createElement('div');
    arrow.classList.add('arrow');
    this.querySelector('td:first-child').appendChild(arrow);
  });
}



/////////////////////////////テーブルの行をクリックしたら、背景色を変更する //////////////////////////
  
  // // 日時表示
  // // timerID = setInterval('clock()',1000); //0.5秒毎にclock()を実行
  // document.getElementById("view_today").innerHTML = getToday();
  // function getToday() {
  //     var now = new Date();
  //     var year = now.getFullYear();
  //     var mon = now.getMonth()+1; //１を足すこと
  //     var day = now.getDate();
  //     var you = now.getDay(); //曜日(0～6=日～土)
  
  //     //曜日の選択肢
  //     var youbi = new Array("日","月","火","水","木","金","土");
  //     //出力用
  //     var s = year + "年" + mon + "月" + day + "日(" + youbi[you] + ") ";
  //     return s;
  // }
  
  
  // document.getElementById("view_time").innerHTML = getNow();
  // function getNow() {
  //     var now = new Date();
  //     var hour = now.getHours();
  //     var min = now.getMinutes();
	//   var sec = now.getSeconds();

	// //出力用
	// var s =  hour + ":" + min + ":" + sec; 
	// return s;
  // }


