/*
 * @Author: Kamikawa
 * @Date: 2023-03-16 16:27:54
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2023-06-14 16:13:32
 * @FilePath: \JS_TEST\wkp-demo-0522\comclient2.js
 * @Description: 
 * 
 * Copyright (c) 2023 by ${git_name_email}, All Rights Reserved. 
 */


/**
 * Json 定義
 * { 
 *   "datetime": "2023-02-20 11:28:01", 
 *   "loginid": "L001", 
 *   "devid": "D001", 
 *   "tkid": "T001", 
 *   "snid": "S001", 
 *   "model": "A001", 
 *   "lang": "ja-jp", 
 *   "option": "showheaders|showrequest",
 *   "dl1max": "1",
 *   "dl2max": "",
 *   "dl3max": "",
 *   "dl4max": "",
 *   "dl5max": "",
 *   "dl1": [ 
 *      { "c": [ "name","gender","age"] }, 
 *      { "c": [ "EEEE", "mmmm", "35"] } 
 *          ],
 *   "dl2": [],
 *   "dl3": [],
 *   "dl4": [],
 *   "dl5": []
 * } 
 */
class jdatain {
    constructor(datetime, loginid, devid, tkid, snid, module, lang, option) {
        this.datetime = datetime;
        this.loginid = loginid;
        this.devid = devid;
        this.tkid = tkid;
        this.snid = snid;
        this.module = module;
        this.lang = lang;
        this.option = option;
        this.dl1max = "";
        this.dl2max = "";
        this.dl3max = "";
        this.dl4max = "";
        this.dl5max = "";
        this.dl1 = [];
        this.dl2 = [];
        this.dl3 = [];
        this.dl4 = [];
        this.dl5 = [];
    }
    setdataList(id, value) {
        if (id === 1) { this.dl1 = value; }
        if (id === 2) { this.dl2 = value; }
        if (id === 3) { this.dl3 = value; }
        if (id === 4) { this.dl4 = value; }
        if (id === 5) { this.dl5 = value; }
    }
    getdataList(id) {
        if (id === 1) { return this.dl1; }
        if (id === 2) { return this.dl2; }
        if (id === 3) { return this.dl3; }
        if (id === 4) { return this.dl4; }
        if (id === 5) { return this.dl5; }
    }

    setlistMax(id, value) {
        if (id === 1) { this.dl1max = value; }
        if (id === 2) { this.dl2max = value; }
        if (id === 3) { this.dl3max = value; }
        if (id === 4) { this.dl4max = value; }
        if (id === 5) { this.dl5max = value; }
    }
    getlistMax(id) {
        if (id === 1) { return this.dl1max; }
        if (id === 2) { return this.dl2max; }
        if (id === 3) { return this.dl3max; }
        if (id === 4) { return this.dl4max; }
        if (id === 5) { return this.dl5max; }
    }
}

/**
 * Json 定義 dl 部分
 * *  "dl": [ 
 *      { "c": [ "name","gender","age"] }, 
 *      { "c": [ "EEEE", "mmmm", "35"] } 
 *  ] 
 * } 
 */
class jdatainrow {
    constructor() {
        this.c = [];
    }
    set dataRow(value) {
        this.c = value;
    }
    get dataRow() {
        return this.c;
    }
}

/**
 * @description: Client POST Class for Communication
 * @return {*}
 */
class ClientPost {

    constructor(modUrl, modName, customFunction) {
        this._modUrl = modUrl;
        this._modName = modName;
        this._callBackFunction = customFunction;
    }

    // CurrentTime ：yyyy-MM-dd HH:MM:SS
    GetyyyyMMddHHmmss(){
        const currentDate = new Date();
        const year = currentDate.getFullYear();
        const month = String(currentDate.getMonth()).padStart(2, '0');
        const day = String(currentDate.getDate()).padStart(2, '0');

        const hour = String(currentDate.getHours()).padStart(2, '0');//時
        const minute = String(currentDate.getMinutes()).padStart(2, '0');//分
        const second = String(currentDate.getSeconds()).padStart(2, '0');//秒
        return (year + "-" + month + "-" + day + " " + hour + ":" + minute + ":" + second);
    }

    // sModule use Blank
    InitDataClass(sLoginid, sDevid, sTkid, sSnid, sModule, sLang, sOption) {
        if (sLang == '') { sLang = 'ja-jp'; }
        // datetime, loginid, devid, tkid, snid, model, lang, option
        this._jobj = new jdatain(this.GetyyyyMMddHHmmss(), sLoginid, sDevid, sTkid, sSnid, this._modName, sLang, sOption);
    }

    //* Map data convert to jdatainrow
    //* Set dl1 -- only one row data for pass condition or property
    //* dl1max = '1'
    SetParamTable1(argMap){
        // let keys = keys = [...sdata.keys()];
        // let vals = [...sdata.values()];
        let keys = Array.from(argMap.keys());
        let vals = Array.from(argMap.values());

        let mylist = [];
        mylist[0] = new jdatainrow();
        mylist[1] = new jdatainrow();
        //console.log(keys.length);
        for (let i = 0; i < keys.length; i++) {
            mylist[0].c[i] = keys[i];
            mylist[1].c[i] = vals[i];
        }
        this._jobj.setdataList(1, mylist);
        this._jobj.setlistMax(1, "1");
    }

    SetParamTable2(argArr){
        let mylist = [];
        for (let i = 0; i < argArr.length; i++) {
            mylist[i] = new jdatainrow();
            mylist[i].c = argArr[i];            
        }
        let rMax = argArr.length - 1;
        this._jobj.setdataList(2, mylist);
        this._jobj.setlistMax(2, rMax.toString());
    }

    SetParamTable3(argArr){
        let mylist = [];
        for (let i = 0; i < argArr.length; i++) {
            mylist[i] = new jdatainrow();
            mylist[i].c = argArr[i];            
        }
        let rMax = argArr.length - 1;
        this._jobj.setdataList(3, mylist);
        this._jobj.setlistMax(3, rMax.toString());
    }

    SetParamTable4(argArr) {
        let mylist = [];
        for (let i = 0; i < argArr.length; i++) {
            mylist[i] = new jdatainrow();
            mylist[i].c = argArr[i];
        }
        let rMax = argArr.length - 1;
        this._jobj.setdataList(4, mylist);
        this._jobj.setlistMax(4, rMax.toString());
    }

    SetParamTable5(argArr) {
        let mylist = [];
        for (let i = 0; i < argArr.length; i++) {
            mylist[i] = new jdatainrow();
            mylist[i].c = argArr[i];
        }
        let rMax = argArr.length - 1;
        this._jobj.setdataList(5, mylist);
        this._jobj.setlistMax(5, rMax.toString());
    }

    DoPost(){
        alert(JSON.stringify(this._jobj));
        //Call axios post
        this.AxiosPost(this._modUrl, this._jobj, this._callBackFunction);
    }

    
    /**
     * @description: Call POST
     * @param {*} fName
     * @param {*} sUrl
     * @param {*} jClsData
     * @return {*}
     */
    AxiosPost(sUrl, jClsData, callback) {
    
        axios({
            method: 'post',
            url: sUrl,  //'./GetPostTest/TestPost2',
            data: JSON.stringify(jClsData),
            //timeout: 0
        })
            .then(function (response) {
                //console.log(response);
                
                //let jsonStr = JSON.stringify(response.data);
                //console.log(JSON.stringify(response.data, null, 4));
                //jsonStr = jsonStr.replace(/\\"/g, '"');
                //GetPostResponse(fName, jsonStr);

                callback(response.data);
                //this._callBackFunction(response.data);
                //GetPostResponse(fName, response.data);
            })
            .catch(function (error) {
                if (error.response) {
                    // The request was made and the server responded with a status code
                    // that falls out of the range of 2xx
                    console.log(error.response.data);
                    console.log(error.response.status);
                    console.log(error.response.statusText);
                    //console.log(error.response.headers);
                    console.log(JSON.stringify(error.response.headers, null, 4));
                } else if (error.request) {
                    // The request was made but no response was received
                    // `error.request` is an instance of XMLHttpRequest in the browser and an instance of
                    // http.ClientRequest in node.js
                    console.log(error.request);
                } else {
                    // Something happened in setting up the request that triggered an Error
                    console.log('Error', error.message);
                }
                //console.log(error.config);
            })
            .finally(function () {
                // always executed
            });
    }
}





//Sample P005 After
function P005After(rData) {

    let jsonStr = JSON.stringify(rData);
    jsonStr = jsonStr.replace(/\\"/g, '"');

    let output = document.getElementById('msg');
    output.innerHTML = jsonStr;

    let debugStr = rData.msgd;
    debugStr = debugStr.replace(/\\"/g, '"');
    if (debugStr != "" && debugStr != null && debugStr != undefined) {
        document.getElementById('debug_msg').value = debugStr;
        rData.msgd = "Show below";
    }

    document.getElementById('rejson').value = JSON.stringify(rData, null, 4);
}

//Sample P005 Before
function P005Before() {

    const post5 = new ClientPost('./WkpGetPost/DoPost', 'NkYoteiDataSearch', P005After);

    let sdata = new Map();
    sdata.set('syscode', 'sys01');
    sdata.set('cuscode', 'cus01');
    sdata.set('logistics', 'log01');
    sdata.set('slipno', 'slipno2');
    sdata.set('programid', 'yotei1');

    post5.InitDataClass("L001", "D001", "T001", "S001", "", "ja-jp", "");
    post5.SetParamTable1(sdata);
    post5.DoPost();
}


//public class JobjOut {
//    public string datetime = "";
//    public string code = "";
//    public string msg = "";
//    public string msgd = "";        // debug + Exception Msg
//    public string lang = "";
//    public string dl1max = "";
//    public string dl2max = "";
//    public string dl3max = "";
//    public string dl4max = "";
//    public string dl5max = "";
//    public Data_dl[] dl1 = new Data_dl[0];
//    public Data_dl[] dl2 = new Data_dl[0];
//    public Data_dl[] dl3 = new Data_dl[0];
//    public Data_dl[] dl4 = new Data_dl[0];
//    public Data_dl[] dl5 = new Data_dl[0];
//}
//public class Data_dl {
//    public string[] c;
//}

/**
 * @description: Get Response Data
 * usage:  GetRespArrData(response.data.dl1) ---> Data Array (first row is title)
 *       let dl_Data = [];
 *       dl_Data = GetRespArrData(responsedata.dl1); }
 * 
 * @param {*} response.data.dl1......dl5
 * @return {*}
 */
function GetRespArrData(responsedata) {

    //responsedata = response.data.dln  n=1-5
    //let r = responsedata.length;
    //let c = responsedata[0].c.length;

    let arrC = new Array();
    for (let i = 0; i < responsedata.length; i++) {

        arrC[i] = new Array();

        for (let j = 0; j < responsedata[i].c.length; j++) {
            arrC[i][j] = responsedata[i].c[j];
        }
    }
    return arrC;
}


