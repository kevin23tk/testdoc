/*
 * @Author: Kamikawa
 * @Date: 2023-04-14 20:42:47
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2023-04-27 13:33:52
 * @FilePath: \JS_TEST\wkp-demo-grid0427\wkp-demo-up1\setpage2.js
 * @Description: 
 * 
 * Copyright (c) 2023 by ${git_name_email}, All Rights Reserved. 
 */

// POST Function Before/After 定義
const Post_Type_Info = [
    ["P001", "./WkpGetPost/DoPost", "WebGridModel", "P001After"]
];

function P001Before() {

    let typeName = "P001";
    // sdata.set( パラメータ名(任意) , パラメータ 値);
    let sdata = new Map();
    sdata.set('systemcode', 'sys01');
    sdata.set('customercode', 'cus01');
    sdata.set('programid', 'test01');

    //共通 Send POST Function
    SendPostReq(typeName, sdata, "L001", "D001", "T001", "S001", "ja-jp", "");
}

var tbData = [];
var tbSetting = [];
//['tb01serti15', 'red']
//['tb01serti11', 'black']
var tbRowColorSetting = [];

function P001After(rData) {

    tbData = GetRespArrData(rData.dl1);
    tbSetting = GetRespArrData(rData.dl2);
    console.log(tbData);
    console.log(tbSetting);

    //let jsonStr = JSON.stringify(rData);
    //jsonStr = jsonStr.replace(/\\"/g, '"');

    //let output = document.getElementById('msg');
    //output.innerHTML = jsonStr;

    //let debugStr = rData.msgd;
    //debugStr = debugStr.replace(/\\"/g, '"');
    //if (debugStr != "" && debugStr != null && debugStr != undefined) {
    //    document.getElementById('debug_msg').value = debugStr;
    //    rData.msgd = "Show below";
    //}

    //document.getElementById('rejson').value = JSON.stringify(rData, null, 4);
}

//const tbData = [
//["tb_key","customer_code","logistics_base_code","arrival_slip_no","order_no","regist_datetime","prod_code","prod_name","prod_qty","extinfo1","extinfo2","extinfo3","extinfo4","extinfo5"],
//["tb01serti01","NNS-001","KT-63222","NK000000002","H-0010001","2023/03/23 9:12:23","A001","商品名001","11","文字1","文字2","文字3","文字4","文字5"],
//["tb01serti02","NNS-001","KT-63222","NK000000002","H-0010002","2023/03/16 8:15:24","A002","商品名002","9","文字1","文字2","文字3","文字4","文字5"],
//["tb01serti03","NNS-001","SE-00652","NK000000002","H-0010003","2023/03/14 11:06:25","A001","商品名001","7","文字1","文字2","文字3","文字4","文字5"],
//["tb01serti04","NNS-001","SE-00652","NK000000002","H-0010001","2023/03/12 21:04:26","A001","商品名001","25","文字1","文字2","文字3","文字4","文字5"],
//["tb01serti05","NNS-002","KT-63222","NK000000002","H-0010002","2023/03/23 6:11:27","A005","商品名005","4","文字1","文字2","文字3","文字4","文字5"],
//["tb01serti06","NNS-002","KT-63222","NK000000002","H-0010003","2023/03/11 8:17:28","A001","商品名001","35","文字1","文字2","文字3","文字4","文字5"],
//["tb01serti07","NNS-002","AB-0003","NK000000002","H-0010001","2023/03/16 7:26:29","A005","商品名005","12","文字1","文字2","文字3","文字4","文字5"],
//["tb01serti08","NNS-002","AB-0003","NK000000002","H-0010002","2023/03/20 19:32:30","A005","商品名005","2","文字1","文字2","文字3","文字4","文字5"],
//["tb01serti09","NNS-002","AB-0003","NK000000009","H-0010003","2023/03/22 15:22:31","A009","商品名009","3","文字1","文字2","文字3","文字4","文字5"],
//["tb01serti10","NNS-003","SE-00652","NK000000009","H-0010001","2023/03/17 8:42:32","A009","商品名009","7","文字1","文字2","文字3","文字4","文字5"],
//["tb01serti11","NNS-003","SE-00652","NK000000009","H-0010002","2023/03/18 15:52:33","A002","商品名002","12","文字1","文字2","文字3","文字4","文字5"],
//["tb01serti12","NNS-003","SE-00652","NK000000009","H-0010003","2023/03/23 21:47:34","A009","商品名009","35","文字1","文字2","文字3","文字4","文字5"],
//["tb01serti13","NNS-003","KT-63222","NK000000009","H-0010001","2023/03/19 8:58:35","A001","商品名001","10","文字1","文字2","文字3","文字4","文字5"],
//["tb01serti14","NNS-003","KT-63222","NK000000009","H-0010002","2023/03/18 10:32:36","A002","商品名002","8","文字1","文字2","文字3","文字4","文字5"],
//["tb01serti15","NNS-003","AB-0003","NK000000009","H-0010003","2023/03/20 15:38:37","A009","商品名009","5","文字1","文字2","文字3","文字4","文字5"]
//];
  
//const tbSetting =[
//  ["rkey","list_column_pg_name","list_column_display_name","data_type","digits","display_kinds","display_order","sort_order","asc_desc"],
//  ["sys01#cus01#test01","tb_key","table_key","varchar","12","key","0","",""],
//  ["sys01#cus01#test01","customer_code","荷主_コード","varchar","12","visible","13","",""],
//  ["sys01#cus01#test01","logistics_base_code","拠点_コード","varchar","12","visible","14","1","A"],
//  ["sys01#cus01#test01","arrival_slip_no","入荷_伝票_番号","varchar","12","hide","0","",""],
//  ["sys01#cus01#test01","order_no","発注_番号","varchar","25","hide","0","",""],
//  ["sys01#cus01#test01","regist_datetime","登録_日時","timestamp","20","hide","0","",""],
//  ["sys01#cus01#test01","prod_code","商品コード","varchar","50","visible","10","",""],
//  ["sys01#cus01#test01","prod_name","商品名","varchar","50","visible","11","2","A"],
//  ["sys01#cus01#test01","prod_qty","数量","integer","10","visible","12","3","D"],
//  ["sys01#cus01#test01","extinfo1","在庫キー（文字1）","varchar","50","hide","0","",""],
//  ["sys01#cus01#test01","extinfo2","在庫キー（文字2）","varchar","50","hide","0","",""],
//  ["sys01#cus01#test01","extinfo3","在庫キー（文字3）","varchar","50","hide","0","",""],
//  ["sys01#cus01#test01","extinfo4","在庫キー（文字4）","varchar","50","hide","0","",""],
//  ["sys01#cus01#test01","extinfo5","在庫キー（文字5）","varchar","50","hide","0","",""]
//  ];



const tbIdx_key = 0;
const tbIdx_customer_code = 1;
const tbIdx_logistics_code = 2;
const tbIdx_slip_no = 3;
const tbIdx_order_no = 4;
const tbIdx_datetime = 5;
const tbIdx_prod_code = 6;
const tbIdx_prod_name = 7;
const tbIdx_prod_qty = 8;
const tbIdx_extinfo1 = 9;
const tbIdx_extinfo2 = 10;
const tbIdx_extinfo3 = 11;
const tbIdx_extinfo4 = 12;
const tbIdx_extinfo5 = 13;

// ******************************   外部利用共通関数BASE BEGIN   *****************************

// GetHVCols(tbSetting, 'hide') --> Get hide Data Array
// [ [ 3, '入荷_伝票_番号', '0' ],
//   [ 4, '発注_番号', '0' ],
//   [ 5, '登録_日時', '0' ],
//   [ 9, '在庫キー（文字1）', '0' ],
//   [ 10, '在庫キー（文字2）', '0' ],
//   [ 11, '在庫キー（文字3）', '0' ],
//   [ 12, '在庫キー（文字4）', '0' ],
//   [ 13, '在庫キー（文字5）', '0' ] ]

// GetHVCols(tbSetting, 'visible') --> Get visible Data Array
// [ [ 0, 'table_key', '0' ],
//   [ 6, '商品コード', '10' ],
//   [ 7, '商品名', '11' ],
//   [ 8, '数量', '12' ],
//   [ 1, '荷主_コード', '13' ],
//   [ 2, '拠点_コード', '14' ] ]

  /**
   * @description: 
   * GetHVCols(tbSetting, 'hide') --> Get hide Data Array
   * GetHVCols(tbSetting, 'visible') --> Get visible Data Array
   * @param {*} arrParam
   * @param {*} hideOrVisible
   * @return {*}
   */    
  function GetHVCols(arrParam, hideOrVisible) {
    let arrV = [];
    let COL_KEY = 0;
    let COL_COL = 1;
    let COL_NAME = 2;
    let COL_TYPE = 3;
    let COL_LENGTH = 4;
    let COL_VISIBLE = 5;
    let COL_DISPORDER = 6;
    let COL_SORTORDER = 7;
    let COL_SORTAD = 8;
    let k=0;
    
    for (i = 1; i < arrParam.length; i++) {

        let khv = arrParam[i][COL_VISIBLE];
        if(khv === 'key'){khv ='visible';}
        //hideOrVisible = hide || visible
        if (khv===hideOrVisible)
        {
            arrV[k] = [];        
            arrV[k][0] = i - 1;
            arrV[k][1] = arrParam[i][COL_NAME];
            arrV[k][2] = arrParam[i][COL_DISPORDER];    
            k++;
        }        
    }
    //console.log(arrV);

    let sortedArr = [...arrV].sort((a, b) => a[2] - b[2]);
    //console.log(sortedArr);
    return sortedArr;    
  }

  // GetSortItems(tbSetting)
  // [ [ 999, '-- ソート項目 --', '' ],
  // [ 1, '荷主_コード', '' ],
  // [ 2, '拠点_コード', '' ],
  // [ 3, '入荷_伝票_番号', '' ],
  // [ 4, '発注_番号', '' ],
  // [ 5, '登録_日時', '' ],
  // [ 6, '商品コード', '' ],
  // [ 7, '商品名', '' ],
  // [ 8, '数量', '' ],
  // [ 9, '在庫キー（文字1）', '' ],
  // [ 10, '在庫キー（文字2）', '' ],
  // [ 11, '在庫キー（文字3）', '' ],
  // [ 12, '在庫キー（文字4）', '' ],
  // [ 13, '在庫キー（文字5）', '' ] ]
  /**
   * @description: 
   *  GetSortItems(tbSetting) --> Get Sort List Items (except key)
   * @param {*} arrParam
   * @return {*}
   */  
  function GetSortItems(arrParam) {
    let arrS = [];
    let COL_KEY = 0;
    let COL_COL = 1;
    let COL_NAME = 2;
    let COL_TYPE = 3;
    let COL_LENGTH = 4;
    let COL_VISIBLE = 5;
    let COL_DISPORDER = 6;
    let COL_SORTORDER = 7;
    let COL_SORTAD = 8;
    let k=0;

    arrS[k] = [999, '-- ソート項目 --', ''];
    k++; 
    // col01 -- col14
    for (i = 1; i < arrParam.length; i++) {
      
      if (arrParam[i][COL_VISIBLE] === 'key') {continue;}
        arrS[k] = [];        
        arrS[k][0] = i - 1;
        arrS[k][1] = arrParam[i][COL_NAME];
        arrS[k][2] = '';        
        k++; 
    }
    //console.log(arrS);
    return arrS;    
  }

  // GetSortCols(tbSetting) --> Get Sort Data Array  
  // [ [ 2, '拠点_コード', '1', 'A', 'varchar' ],
  // [ 7, '商品名', '2', 'A', 'varchar' ],
  // [ 8, '数量', '3', 'D', 'integer' ] ]
  /**
   * @description: 
   *  GetSortCols(tbSetting) --> Get Sort Data Array
   * @param {*} arrParam
   * @return {*}
   */  
  function GetSortCols(arrParam) {

    let arrS = [];
    let COL_KEY = 0;
    let COL_COL = 1;
    let COL_NAME = 2;
    let COL_TYPE = 3;
    let COL_LENGTH = 4;
    let COL_VISIBLE = 5;
    let COL_DISPORDER = 6;
    let COL_SORTORDER = 7;
    let COL_SORTAD = 8;
    let k=0;

    for (i = 1; i < arrParam.length; i++) {

        if (arrParam[i][COL_SORTORDER].trim().length === 0) {continue;}        
        arrS[k] = [];        
        arrS[k][0] = i - 1;
        arrS[k][1] = arrParam[i][COL_NAME];
        arrS[k][2] = arrParam[i][COL_SORTORDER];
        arrS[k][3] = arrParam[i][COL_SORTAD];
        arrS[k][4] = arrParam[i][COL_TYPE]; 
        k++; 
    }
    //console.log(arrS);

    let sortedArr = [...arrS].sort(function(a, b) {
        return a[2].localeCompare(b[2], 'ja') // 'zh' 表示中文，可以根据需要替换成其他语言编码
    });
    //console.log(sortedArr);
    return sortedArr;    
  }
  
    
  /**
   * @description: 
   *  let visibleItems = GetSelectControl('select_list');
   * @param {*} arrParam
   * @param {*} arrReSet
   * @return {*}
   */
  function ModifyVisible(arrParam, arrReSet) {

    let arrS = [];
      let COL_KEY = 0;
      let COL_COL = 1;
      let COL_NAME = 2;
      let COL_TYPE = 3;
      let COL_LENGTH = 4;
      let COL_VISIBLE = 5;
      let COL_DISPORDER = 6;
      let COL_SORTORDER = 7;
      let COL_SORTAD = 8;
    let k=0;

    // Set all visible --> hide
    for (i = 1; i < arrParam.length; i++) {    
      if (arrParam[i][COL_VISIBLE] === 'key') {continue;}
        arrParam[i][COL_VISIBLE] = 'hide';
        arrParam[i][COL_DISPORDER] = '';
    }

    // ['13', '在庫キー（文字5）', '10']
    // ['2', '商品コードA', '11']
    // ['3', '商品名A', '12']
    for (i = 0; i < arrReSet.length; i++) {        
      arrParam[parseInt(arrReSet[i][0])+1][COL_VISIBLE] = 'visible';
      arrParam[parseInt(arrReSet[i][0])+1][COL_DISPORDER] = arrReSet[i][2];
    }
    //console.log(arrParam);
  }
    
  /**
   * @description:  Modify tbSetting By current sort info
   *   ModifySort(tbSetting);
   * @param {*} arrParam
   * @return {*}
   */
  function ModifySort(arrParam){

    // ['999', '-- ソート項目 --']
    // ['3', '商品名A']
    // ['8', '数量'] 
    let sel = [];
    sel[0] = GetSelectChosen('sortdrop1');
    sel[1] = GetSelectChosen('sortdrop2');
    sel[2] = GetSelectChosen('sortdrop3');
    console.log(sel);

    // ['A', '昇順']
    // ['0', '-- 並び順 --']
    // ['D', '降順']
    let ad = [];
    ad[0] = GetSelectChosen('sortAD1');
    ad[1] = GetSelectChosen('sortAD2');
    ad[2] = GetSelectChosen('sortAD3');
    console.log(ad);

    let COL_KEY = 0;
    let COL_COL = 1;
    let COL_NAME = 2;
    let COL_TYPE = 3;
    let COL_LENGTH = 4;
    let COL_VISIBLE = 5;
    let COL_DISPORDER = 6;
    let COL_SORTORDER = 7;
    let COL_SORTAD = 8;

    // Clear all Sort
    for (i = 1; i < arrParam.length; i++) {    
      arrParam[i][COL_SORTORDER] = '';
      arrParam[i][COL_SORTAD] = '';
    }

    // Set Modified Sort
    for (i = 0; i < 3; i++) {
      if(sel[i][0] === '999'){continue;}  // SKIP  -- ソート項目 --  
      if(ad[i][0] === '0'){continue;}     // SKIP  -- 並び順 --
      let m = i.toString() + ad[i][0];
      arrParam[parseInt(sel[i][0])+1][COL_SORTORDER] = (i+1).toString();
      arrParam[parseInt(sel[i][0])+1][COL_SORTAD] = ad[i][0];
    }
    console.log(arrParam);
  }

// ******************************   外部利用共通関数BASE END   *****************************

  /**
   * @description: 
   *  GetDispTable(tbData, GetHVCols(tbSetting, 'visible')) --> Get all key and visible Data Array
   * @param {*} arrParam
   * @param {*} arrOrder
   * @return {*}
   */  
  function GetDispTable(arrParam, arrOrder) {    
    const vorderArr = [];
    for (let i = 0; i < arrParam.length; i++) {
      let row = [];  
      for (let j = 0; j < arrOrder.length; j++) {
        row.push(arrParam[i][arrOrder[j][0]]);
      }  
      vorderArr.push(row);
    }  
    return vorderArr;
  }

//　arrSortSet = GetSortCols(tbSetting)
// [ [ 5, '拠点_コード', '1', 'A', 'varchar' ],
//   [ 3, '商品名', '2', 'D', 'varchar' ],
//   [ 8, '数量', '3', 'D', 'integer' ] ]
  /**
   * @description: 
   *  sortMultiDimensionalArray(tbData, GetSortCols(tbSetting))  --> Sort the original data
   * @param {*} arrParam
   * @param {*} arrSortSet
   * @return {*}
   */  
  function sortMultiDimensionalArray(arrParam, arrSortSet) {   
    let sortedArr = [...arrParam].sort(function(a, b) {        
      for (let i = 0; i < arrSortSet.length; i++) {
        let col = arrSortSet[i][0];
        let direction = 'asc';
        if(arrSortSet[i][3]==='A'){direction = 'asc';}
        if(arrSortSet[i][3]==='D'){direction = 'desc';}

        if (arrSortSet[i][4] === 'integer') {
            // integer sort
            if (parseFloat(a[col]) > parseFloat(b[col])) {
                return direction === 'asc' ? 1 : -1;
            } else if (parseFloat(a[col]) < parseFloat(b[col])) {
                return direction === 'asc' ? -1 : 1;
            }else{}
        } else {
            // string sort
            if (a[col] > b[col]) {
                return direction === 'asc' ? 1 : -1;
            } else if (a[col] < b[col]) {
                return direction === 'asc' ? -1 : 1;
            }else{}
        }
        
      }
      return 0;
    });

    // for (let i = 0; i < sortedArr.length; i++) {
    //   console.log(sortedArr[i][0]); // 打印每行的第一个元素
    // }
    return sortedArr;
  }

  /**
   * @description: 
   *  Delete first Row in Array -- Title
   * @param {*} arrParam
   * @return {*}
   */  
  function DelArrayFirstRow(arrParam) {
    let newArr = arrParam.slice(1); 
    return newArr;
  }
   
  /**
   * @description: 
   *   SetSelectControl('fb_list', GetHVCols(tbSetting, 'hide'), 'hide');  --> Set hide Selectitem
   *   SetSelectControl('select_list', GetHVCols(tbSetting, 'visible'), 'visible');  --> Set visible Selectitem
   * @param {*} controlId
   * @param {*} arrParam
   * @param {*} argType
   * @return {*}
   */  
  function SetSelectControl(controlId, arrParam, argType) {
    let selectElement = document.getElementById(controlId);
    selectElement.innerHTML = "";
    for (let i = 0; i < arrParam.length; i++) {
      // when set visible select control skip the key column (arrParam[i][2] === "0")
      if(argType === "visible"){
        if(arrParam[i][2] === "0"){continue;}      
      }      
      let option = document.createElement("option");
      option.value = arrParam[i][0];
      option.text = arrParam[i][1];
      selectElement.add(option);
    }
  }

  /**
   * @description:  Set dropdown selected Value
   * @param {*} controlId
   * @param {*} selVal
   * @return {*}
   */
  function SetSelectedValue(controlId, selVal) {
    let selectElement = document.getElementById(controlId);
    for(var i=0; i<selectElement.options.length; i++){
        if(selectElement.options[i].value === selVal.toString()){
            selectElement.options[i].selected = true;
            break;
        }
    }
  }

  /**
   * @description:  Set ソート項目 and 並び順
   * @return {*}
   */  
  function Set3SelectedValue() {
    // [   [ 5, '拠点_コードB', '1', 'A', 'varchar' ],
    //     [ 3, '商品名A', '2', 'D', 'varchar' ],
    //     [ 8, '数量', '3', 'D', 'integer' ] ]
    let sortdata = GetSortCols(tbSetting);
    for (let i = 0; i < sortdata.length; i++) {
        let colVal = sortdata[i][0];    // 5 || 3 || 8 
        let control1 = 'sortdrop'+ sortdata[i][2];   // sortdrop1  sortdrop2  sortdrop3
        let control2 = 'sortAD'+ sortdata[i][2] ;  // sortAD1  sortAD2  sortAD3
        let AorD = sortdata[i][3];  // A || D
        // <option value="A">昇順</option>
        // <option value="D">降順</option>
        // if(AorD === 'A'){AorD = '1';}
        // if(AorD === 'D'){AorD = '2';}
        SetSelectedValue(control1, colVal);
        SetSelectedValue(control2, AorD);
    }
  }

  
/**
 * @description:  When first time open the page
 * @return {*}
 */
function InitPage() {

  //Set hide Selectitem
  let hideSet = GetHVCols(tbSetting, 'hide');
  SetSelectControl('fb_list', hideSet, 'hide');

  //Set visible Selectitem
  let visibleSet = GetHVCols(tbSetting, 'visible');
  SetSelectControl('select_list', visibleSet, 'visible');

  //Set sort Selectitem
  let sortItems = GetSortItems(tbSetting);
  SetSelectControl('sortdrop1', sortItems, 'sort');
  SetSelectControl('sortdrop2', sortItems, 'sort');
  SetSelectControl('sortdrop3', sortItems, 'sort');

  //Set sort Asc Desc
  Set3SelectedValue();

  //Set grid
  ReSetGrid();  
  
  //Set EditForm　Save button
  AddEventToEditSaveButton(tbData);


}

  // 編集・コピー・削除後→送信ボタンフレッシュ
function setButtonFlash() {
  const myBtn = document.getElementById('js-buttonflash');
  myBtn.classList.add('dataSubmitButton');
}

function GetRowColor(argKey) {
  //['tb01serti15', 'red']
  //['tb01serti11', 'black']
  for (let i = 0; i < tbRowColorSetting.length; i++) {
      if(tbRowColorSetting[i][0]===argKey){
        return tbRowColorSetting[i][1];
      }
  }
  return "NoColor";
}

function AddEventToEditSaveButton(arrParam) {
    //Set modalSaveButton
  let saveButton = document.getElementById("modalSaveButton");
  saveButton.addEventListener("click", function() {

    let subType= document.getElementById('check_Data').value;
    let dataKey= document.getElementById('identity_Key').value;

    //Color Setting Array
    let rowColor = [];
    rowColor[0] = dataKey;
    rowColor[1] = "red";
    // ['tb01serti15', 'red']
    tbRowColorSetting[tbRowColorSetting.length] =rowColor;

    // if new  --> append Array
    // if edit --> modify Array  
    // if copy --> append Array
    if(subType === "edit"){
        let dataIndex = GetRowIndexByKey(dataKey);
        //元データの修正
        let editRow = arrParam[dataIndex];
        editRow[tbIdx_datetime] = document.getElementById('update_Data').value;
        editRow[tbIdx_prod_code] = document.getElementById('product_Code').value;
        editRow[tbIdx_prod_name] = document.getElementById('product_Name').value;
        editRow[tbIdx_customer_code] = document.getElementById('shipper_Code').value;
        editRow[tbIdx_logistics_code] = document.getElementById('location_Code').value;
        editRow[tbIdx_slip_no] = document.getElementById('incoming_Number').value;
        editRow[tbIdx_order_no] = document.getElementById('purchase_Number').value;
        editRow[tbIdx_prod_qty] = document.getElementById('quantity').value;
        editRow[tbIdx_extinfo1] = document.getElementById('inventory_Key1').value;
        editRow[tbIdx_extinfo2] = document.getElementById('inventory_Key2').value;
        editRow[tbIdx_extinfo3] = document.getElementById('inventory_Key3').value;
        editRow[tbIdx_extinfo4] = document.getElementById('inventory_Key4').value;
        editRow[tbIdx_extinfo5] = document.getElementById('inventory_Key5').value;
    }

    if((subType === "new")||(subType === "copy")){
        //元Arrayの最後に追加
        let newRow = [];
        newRow[tbIdx_key] = dataKey;
        newRow[tbIdx_datetime] = document.getElementById('update_Data').value;
        newRow[tbIdx_prod_code] = document.getElementById('product_Code').value;
        newRow[tbIdx_prod_name] = document.getElementById('product_Name').value;
        newRow[tbIdx_customer_code] = document.getElementById('shipper_Code').value;
        newRow[tbIdx_logistics_code] = document.getElementById('location_Code').value;
        newRow[tbIdx_slip_no] = document.getElementById('incoming_Number').value;
        newRow[tbIdx_order_no] = document.getElementById('purchase_Number').value;
        newRow[tbIdx_prod_qty] = document.getElementById('quantity').value;
        newRow[tbIdx_extinfo1] = document.getElementById('inventory_Key1').value;
        newRow[tbIdx_extinfo2] = document.getElementById('inventory_Key2').value;
        newRow[tbIdx_extinfo3] = document.getElementById('inventory_Key3').value;
        newRow[tbIdx_extinfo4] = document.getElementById('inventory_Key4').value;
        newRow[tbIdx_extinfo5] = document.getElementById('inventory_Key5').value;

        arrParam[arrParam.length] = newRow;
        //alert(arrParam.length);
    }
     //Set ButtonFlash
     setButtonFlash();

    //Set grid
    ReSetGrid(); 
  });

}



/**
 * @description: 
 * @param {*} controlId
 * @return {*}
 */
function GetSelectControl(controlId) {
  let selectElement = document.getElementById(controlId);
  let options = selectElement.options;
  
  let arrOut = [];
  let seq = 10;
  for (let i = 0; i < options.length; i++) {
    arrOut[i] = [];
    let option = options[i];
    arrOut[i][0] = option.value;
    arrOut[i][1] = option.text;
    arrOut[i][2] = seq.toString();
    seq++;
    }
    console.log(arrOut);
    return arrOut;
}

/**
 * @description:  Select visible --> 適用 button click
 * @return {*}
 */
function ReSetVisibleItems(){
  let visibleItems = GetSelectControl('select_list');
  ModifyVisible(tbSetting, visibleItems);

  //Set grid
  ReSetGrid();  
  // alert(visibleItems);
}

/**
 * @description:  Get Dropdown current selected
 * @param {*} controlId
 * @return {*}
 */
function GetSelectChosen(controlId) {
  let selectElement = document.getElementById(controlId);
  // 获取选中的选项的值
  let selectedValue = selectElement.options[selectElement.selectedIndex].value;
  let selectedText = selectElement.options[selectElement.selectedIndex].text;   
  let selrow = [];
  selrow[0] = selectedValue;
  selrow[1] = selectedText;
  return selrow;
}

/**
 * @description:  Select Sort --> 適用 button click
 * @return {*}
 */
function ReSetSortItems(){
  ModifySort(tbSetting);
  //Set grid
  ReSetGrid();  
}





/**
 * @description:  Generate DataGrid HTML
 * @param {*} argTitle
 * @param {*} arglist
 * @return {*}
 */
function MakeTable(argTitle, arglist) {  

  let tableFrm = `<table id="[TABLE_ID]" class="display table-min-weight mam_dragdrop thin sortable draggable">
    <thead>
        <tr class="bg-secondary text-light">
            <td class="bg-white text-end" style="width:10px !important;"><button id="newRowBtn" class="button_custom"  data-bs-toggle="modal"
              data-bs-target="#exampleModal_edit" data-bs-whatever="@mdo" ><i class="bi bi-plus-lg"></i></button></td>
            [TH_DATA]
        </tr>
    </thead>
    <tbody>
        [TD_DATA]
    </tbody>
  </table>`;

  let tdButton = `<td class="text-center bg-white">
  <div class="dropdown-menu-static-demo">
  <div class="dropdown">
      <button class="btn btn-sm m-0 button_custom" type="button"
          id="dropdownMenuButton2" data-bs-toggle="dropdown" aria-haspopup="true"
          aria-expanded="true"><i class="bi bi-three-dots"></i></button>
      <div class="dropdown-menu table_dropmenu" aria-labelledby="dropdownMenuButton2">
          <button name = "gridrowedit" class="dropdown-item btn-sm" type="button" data-bs-toggle="modal"
              data-bs-target="#exampleModal_edit" data-bs-whatever="@mdo" [KEY_DATA]>
              <i class="bi bi-pencil"></i>&nbsp編集</button>
          <button name = "gridrowcopy" class="dropdown-item btn-sm" type="button" data-bs-toggle="modal"
              data-bs-target="#exampleModal_edit" data-bs-whatever="@mdo" [KEY_DATA]>
              <i class="bi bi-files"></i>&nbspコピー</button>
          <div class="dropdown-divider"></div>
          <button name = "gridrowdel" class="dropdown-item btn-sm" type="button" [KEY_DATA]>
              <i class="bi bi-trash-fill"></i>&nbsp削除</button>
      </div>
  </div>
  </div>
  </td>`;

  let TH_DATA = "";
  let arrVisible = [];
  let TD_DATA = "";
  let tdData = "";
  let tdTemp = "";
  let keyTemp = "";

  // th 作成
  for (let i = 0; i < argTitle.length; i++) {    
    if(argTitle[i][2]==='0')
    {
      arrVisible[i] = "key";  // したに TH_DATA 設定用
      continue;
    }
    arrVisible[i] = "data";  // したに TH_DATA 設定用
    TH_DATA += "<th scope=\"col\">" + argTitle[i][1] + "</th>";  // <th scope="col">商品コード</th>
  }

  // Loop 行
  for (let i = 0; i < arglist.length; i++) {

    keyTemp = "";
    tdData = "";
    rowColor = "";

    // Loop 列
    for (let j = 0; j < arglist[0].length; j++) {
      if(arrVisible[j] === "key"){
        // keyTemp -->  k1 = "xxxx" k2 = "xxxx"
        keyTemp += "k"+ j.toString() +" = \"" +arglist[i][j] +"\" ";
        
        let keyVal = arglist[i][j];
        rowColor = GetRowColor(keyVal);  //Get row color
      }      

      if(arrVisible[j] === "data"){
        tdData += "<td>" + arglist[i][j] + "</td>";  //<td>良品</td>
      }
    }

    tdTemp = tdButton;
    tdTemp = tdTemp.replace(/\[KEY_DATA]/g, keyTemp);

    // Set copy data background color
    
    if(rowColor === 'red')
    {
      TD_DATA += "<tr class='bg-red'>" +tdTemp + tdData + "</tr>";
    }
    else if(rowColor === 'black')
    {
      TD_DATA += "<tr class='bg-secondary'>" +tdTemp + tdData + "</tr>";
    }
    else
    {
      TD_DATA += "<tr>" +tdTemp + tdData + "</tr>";
    }    
  }
  
  tableFrm = tableFrm.replace('[TH_DATA]', TH_DATA);
  tableFrm = tableFrm.replace('[TD_DATA]', TD_DATA);  
  return tableFrm;
}

/**
 * @description: 
 *  Reset Grid Data by Sort and  Visible options
 * @return {*}
 */
function ReSetGrid() {

  let selectElement = document.getElementById('tableDiv');
  selectElement.innerHTML = "";

  let aa = GetHVCols(tbSetting, 'visible');
  let bb = DelArrayFirstRow(tbData);
  let cc = sortMultiDimensionalArray(bb, GetSortCols(tbSetting));
  let dd = GetDispTable(cc, aa);
  let ee = MakeTable(aa, dd); 
  
  let date = new Date();//CurrentTime
  let hour = zeroFill(date.getHours());//時
  let minute = zeroFill(date.getMinutes());//分
  let second = zeroFill(date.getSeconds());//秒
  let tbid = "myTable" + hour + minute + second;
  ee = ee.replace('[TABLE_ID]', tbid);
  selectElement.innerHTML = ee;
  
  SetGridRowClick();  // set button click event
  ReDrawGrid(tbid);   // reset 4 controls with the datagrid
}

function zeroFill(i) {
  if (i >= 0 && i <= 9) {
      return "0" + i;
  } else {
      return i;
  }
}

function ReDrawGrid(tbid) {

    let TB_ID = "#" + tbid;
    $(TB_ID).DataTable({
        autowidth: false,
        columnDefs: [
            { targets: 0, width: "10px" },
            { targets: 1, width: "15%" }
        ]
    });
    $(TB_ID).attr('style', 'width: 100%;');
}

function SetGridRowClick() {

  //  if new  --> clear all
  //  if modify --> set all
  //  if copy --> set all + clear key
  // 　OPEN window
    let rowButtons = document.getElementsByName("gridrowedit");
  rowButtons.forEach(function(rowButton) {
    rowButton.addEventListener("click", function() {

      const attributeNames = this.getAttributeNames(); // 获取所有属性名
      let allatt = "";
      for (let attributeName of attributeNames) { // 遍历所有属性名
        const attributeValue = this.getAttribute(attributeName); // 获取属性值
        allatt += attributeName + ": " + attributeValue + "  "; // 输出属性名和属性值
    }      
      // alert(allatt);

      let keyValue = this.getAttribute("k0"); // 获取属性值
      // alert(GetRowDataByKey(keyValue));

      let rowData = GetRowDataByKey(keyValue);
      document.getElementById('check_Data').value = "edit";
      document.getElementById('identity_Key').value = rowData[tbIdx_key];
      document.getElementById('update_Data').value = rowData[tbIdx_datetime];
      document.getElementById('product_Code').value = rowData[tbIdx_prod_code];
      document.getElementById('product_Name').value = rowData[tbIdx_prod_name];
      document.getElementById('shipper_Code').value = rowData[tbIdx_customer_code];
      document.getElementById('location_Code').value = rowData[tbIdx_logistics_code];
      document.getElementById('incoming_Number').value = rowData[tbIdx_slip_no];
      document.getElementById('purchase_Number').value = rowData[tbIdx_order_no];
      document.getElementById('quantity').value = rowData[tbIdx_prod_qty];
      document.getElementById('inventory_Key1').value = rowData[tbIdx_extinfo1];
      document.getElementById('inventory_Key2').value = rowData[tbIdx_extinfo2];
      document.getElementById('inventory_Key3').value = rowData[tbIdx_extinfo3];
      document.getElementById('inventory_Key4').value = rowData[tbIdx_extinfo4];
      document.getElementById('inventory_Key5').value = rowData[tbIdx_extinfo5];
    });
  });

  let rowDelButtons = document.getElementsByName("gridrowdel");
  rowDelButtons.forEach(function(rowButton) {
    rowButton.addEventListener("click", function() {
      let keyValue = this.getAttribute("k0"); // 获取属性值      

      let rowColor = [];
      rowColor[0] = keyValue;
      rowColor[1] = "black";
      tbRowColorSetting[tbRowColorSetting.length] = rowColor;

      //alert(keyValue);
      //DeleteOneRow(tbData, keyValue);

      //Set ButtonFlash
      setButtonFlash();

      //Set grid
      ReSetGrid();  
    });
  });

  let rowCopyButtons = document.getElementsByName("gridrowcopy");
  rowCopyButtons.forEach(function(rowButton) {
    rowButton.addEventListener("click", function() {
      let keyValue = this.getAttribute("k0"); // 获取属性值
      
      let rowData = GetRowDataByKey(keyValue);
      document.getElementById('check_Data').value = "copy";
      document.getElementById('identity_Key').value = "";
      document.getElementById('update_Data').value = rowData[tbIdx_datetime];
      document.getElementById('product_Code').value = rowData[tbIdx_prod_code];
      document.getElementById('product_Name').value = rowData[tbIdx_prod_name];
      document.getElementById('shipper_Code').value = rowData[tbIdx_customer_code];
      document.getElementById('location_Code').value = rowData[tbIdx_logistics_code];
      document.getElementById('incoming_Number').value = rowData[tbIdx_slip_no];
      document.getElementById('purchase_Number').value = rowData[tbIdx_order_no];
      document.getElementById('quantity').value = rowData[tbIdx_prod_qty];
      document.getElementById('inventory_Key1').value = rowData[tbIdx_extinfo1];
      document.getElementById('inventory_Key2').value = rowData[tbIdx_extinfo2];
      document.getElementById('inventory_Key3').value = rowData[tbIdx_extinfo3];
      document.getElementById('inventory_Key4').value = rowData[tbIdx_extinfo4];
      document.getElementById('inventory_Key5').value = rowData[tbIdx_extinfo5];
      
      //CopyOneRowAppendLast(tbData, keyValue);
      //Set grid
      // ReSetGrid();  
    });
  });

let newButton = document.getElementById("newRowBtn");
  newButton.addEventListener("click", function() {
      let keyValue = this.getAttribute("k0"); // 获取属性值
      
      let rowData = GetRowDataByKey(keyValue);
      document.getElementById('check_Data').value = "new";
      document.getElementById('identity_Key').value = "";      
      document.getElementById('update_Data').value = "";
      document.getElementById('product_Code').value = "";
      document.getElementById('product_Name').value = "";
      document.getElementById('shipper_Code').value = "";
      document.getElementById('location_Code').value = "";
      document.getElementById('incoming_Number').value = "";
      document.getElementById('purchase_Number').value = "";
      document.getElementById('quantity').value = "";
      document.getElementById('inventory_Key1').value = "";
      document.getElementById('inventory_Key2').value = "";
      document.getElementById('inventory_Key3').value = "";
      document.getElementById('inventory_Key4').value = "";
      document.getElementById('inventory_Key5').value = "";

      //CopyOneRowAppendLast(tbData, keyValue);
      //Set grid
      //ReSetGrid();  
 
  });

}

function GetRowIndexByKey(key) {
  
  for (let i = 0; i < tbData.length; i++) {
      if(tbData[i][0]===key)
      {        
        return i;
      }
  }
  return rowData;
}


function GetRowDataByKey(key) {
  let rowData = [];
  for (let i = 0; i < tbData.length; i++) {
      if(tbData[i][0]===key)
      {
        rowData = tbData[i];
        return rowData;
      }
  }
  return rowData;
}

/**
 * @description:  Delete Data in Original DataArray By key
 * @param {*} arrParam
 * @param {*} key
 * @return {*}
 */
function DeleteOneRow(arrParam, key) {
  for (let i = 0; i < arrParam.length; i++) {
      if(arrParam[i][0]===key)
      {
        arrParam.splice(i, 1); // Delete One row
        return;
      }
  }
}

function CopyOneRowAppendLast(arrParam, key) {
  let copyRow = [];
  for (let i = 0; i < arrParam.length; i++) {
    if(arrParam[i][0]===key)
    {
      let copyRow = [...arrParam[i]];      
      copyRow[0] = copyRow[0] + "copy";       // "key" = "keycopy"
      arrParam[arrParam.length] = copyRow;
      return;
    }
  }
}
// window.addEventListener('load', InitPage);

//以下テスト用
//console.log(GetHVCols(tbSetting, 'hide'));
//console.log(GetHVCols(tbSetting, 'visible'));
//console.log(GetSortCols(tbSetting));
//console.log(GetSortItems(tbSetting));

//  let cc = DelArrayFirstRow(tbData);
//  let bb = sortMultiDimensionalArray(cc, GetSortCols(tbSetting));
//  console.log(bb);

//  let aa = GetDispTable(bb, GetHVCols(tbSetting, 'visible'));
//  console.log(aa);
