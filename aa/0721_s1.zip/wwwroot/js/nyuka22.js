/*
 * @Author: Kamikawa
 * @Date: 2023-05-15 15:43:59
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2023-05-29 14:37:22
 * @FilePath: \JS_TEST\wkp-demo-0522\nyuka22.js
 * @Description: 
 * 
 * Copyright (c) 2023 by ${git_name_email}, All Rights Reserved. 
 */


// ******************************   画面Status 定義 BEGIN   *****************************

// eg: SetFormStatus(1); 初期化設定

//     // シナリオ: 初期 / 伝票番号(新規/検索)存在しない / 伝票削除後 / クリア後
//     // ★初期
//     // 入荷伝票番号(入力)有効
//     // 新規(ボタン)有効
//     // 検索(ボタン)有効
//     // その他 -- 全部無効

//     // シナリオ: 伝票番号新規(番号空欄/番号入力された)
//     // ★伝票新規入力
//     // 入荷伝票番号(入力)無効
//     // 新規(ボタン)無効
//     // 検索(ボタン)無効
//     // 削除(ボタン)無効
//     // その他 -- 全部有効  

//     // シナリオ: 伝票番号より検索結果
//     // ★伝票検索結果表示
//     // 入荷伝票番号(入力)無効
//     // 新規(ボタン)無効
//     // 検索(ボタン)無効
//     // 削除(ボタン)有効
//     // その他 -- 全部有効
// 
function SetFormStatus(argParam){        
  //初期化
  if(argParam === 1)
  {
      document.getElementById('invoiceNumberInput').disabled = false;
      document.getElementById('arriveDetailBtn').disabled = false;
      document.getElementById('arriveSearchBtn').disabled = false;
      document.getElementById('arriveDelBtn').disabled = true;
      document.getElementById('purchaseOrderNumberInput').disabled = true;
      document.getElementById('supplierInput').disabled = true;
      document.getElementById('supplierSearchBtn').disabled = true;
      document.getElementById('arriveDateInput').disabled = true;
      document.getElementById('arriveAccordion1').disabled = true;
        document.getElementById('arriveAccordion2').disabled = true;
      // ....
       document.getElementById('newRowBtn').disabled = true;

  }

  //伝票新規入力
  if(argParam === 2)
  {
      document.getElementById('invoiceNumberInput').disabled = true;
      document.getElementById('arriveDetailBtn').disabled = true;
      document.getElementById('arriveSearchBtn').disabled = true;
      document.getElementById('arriveDelBtn').disabled = true;
      document.getElementById('purchaseOrderNumberInput').disabled = false;
      document.getElementById('supplierInput').disabled = false;
      document.getElementById('supplierSearchBtn').disabled = false;
      document.getElementById('arriveDateInput').disabled = false;
      document.getElementById('arriveAccordion1').disabled = false;
        document.getElementById('arriveAccordion2').disabled = false;
      // ....
      document.getElementById('newRowBtn').disabled = false;
      
  }

  //伝票検索結果表示
  if(argParam === 3)
  {
      document.getElementById('invoiceNumberInput').disabled = true;
      document.getElementById('arriveDetailBtn').disabled = true;
      document.getElementById('arriveSearchBtn').disabled = true;
      document.getElementById('arriveDelBtn').disabled = false;
      document.getElementById('purchaseOrderNumberInput').disabled = false;
      document.getElementById('supplierInput').disabled = false;
      document.getElementById('supplierSearchBtn').disabled = false;
      document.getElementById('arriveDateInput').disabled = false;
      document.getElementById('arriveAccordion1').disabled = false;
        document.getElementById('arriveAccordion2').disabled = false;
      // ....
      document.getElementById('tableDiv').disabled = false;
  }
}

window.addEventListener('DOMContentLoaded',function(){
  SetFormStatus(1);
});

// ******************************   画面Status 定義 END   *****************************






// ******************************   CusDataGrid利用する時 必要な外部定義 BEGIN   *****************************

const tbIdx_key = 0;
const tbIdx_customer_code = 1;
const tbIdx_logistics_code = 2;
const tbIdx_slip_no = 3;
const tbIdx_order_no = 4;
const tbIdx_datetime = 5;
const tbIdx_prod_code = 6;
const tbIdx_prod_name = 7;
const tbIdx_prod_qty = 8;
const tbIdx_extinfo1 = 9;
const tbIdx_extinfo2 = 10;
const tbIdx_extinfo3 = 11;
const tbIdx_extinfo4 = 12;
const tbIdx_extinfo5 = 13;

//const tbIdx_tb_key = 0;
//const tbIdx_order_no = 1;
//const tbIdx_supplier_code = 2;
//const tbIdx_arrival_plan_date = 3;
//const tbIdx_item_code_1 = 4;
//const tbIdx_plan_quantity_piece = 5;
//const tbIdx_allocate_kinds = 6;
//const tbIdx_recipt_pay_division = 7;
//const tbIdx_work_division = 8;
//const tbIdx_management_departm = 9;
//const tbIdx_packing_quantity = 10;
//const tbIdx_arrival_unit_price = 11;
//const tbIdx_remarks = 12;
//const tbIdx_key_character_1 = 13;
//const tbIdx_key_character_2 = 14;
//const tbIdx_key_character_3 = 15;
//const tbIdx_key_character_4 = 16;
//const tbIdx_key_character_5 = 17;
//const tbIdx_key_character_6 = 18;
//const tbIdx_key_date_1 = 19;
//const tbIdx_key_date_2 = 20;
//const tbIdx_key_number_1 = 21;
//const tbIdx_key_number_2 = 22;
//const tbIdx_item_name_1 = 23;
//const tbIdx_quantity_per_pallet = 24;
//const tbIdx_quantity_per_pack = 25;
//const tbIdx_quantity_per_case = 26;
//const tbIdx_quantity_per_carton = 27;
//const tbIdx_weight_piece = 28;
//const tbIdx_parameter_setting_1 = 29;
//const tbIdx_parameter_setting_2 = 30;
//const tbIdx_parameter_setting_3 = 31;
//const tbIdx_parameter_setting_4 = 32;

let tbData = [
["tb_key","customer_code","logistics_base_code","arrival_slip_no","order_no","regist_datetime","prod_code","prod_name","prod_qty","extinfo1","extinfo2","extinfo3","extinfo4","extinfo5"],
["tb01serti01","NNS-001","KT-63222","NK000000002","H-0010001","2023/03/23 9:12:23","A001","商品名001","11","文字1","文字2","文字3","文字4","文字5"],
["tb01serti02","NNS-001","KT-63222","NK000000002","H-0010002","2023/03/16 8:15:24","A002","商品名002","9","文字1","文字2","文字3","文字4","文字5"],
["tb01serti03","NNS-001","SE-00652","NK000000002","H-0010003","2023/03/14 11:06:25","A001","商品名001","7","文字1","文字2","文字3","文字4","文字5"],
["tb01serti04","NNS-001","SE-00652","NK000000002","H-0010001","2023/03/12 21:04:26","A001","商品名001","25","文字1","文字2","文字3","文字4","文字5"],
["tb01serti05","NNS-002","KT-63222","NK000000002","H-0010002","2023/03/23 6:11:27","A005","商品名005","4","文字1","文字2","文字3","文字4","文字5"],
["tb01serti06","NNS-002","KT-63222","NK000000002","H-0010003","2023/03/11 8:17:28","A001","商品名001","35","文字1","文字2","文字3","文字4","文字5"],
["tb01serti07","NNS-002","AB-0003","NK000000002","H-0010001","2023/03/16 7:26:29","A005","商品名005","12","文字1","文字2","文字3","文字4","文字5"],
["tb01serti08","NNS-002","AB-0003","NK000000002","H-0010002","2023/03/20 19:32:30","A005","商品名005","2","文字1","文字2","文字3","文字4","文字5"],
["tb01serti09","NNS-002","AB-0003","NK000000009","H-0010003","2023/03/22 15:22:31","A009","商品名009","3","文字1","文字2","文字3","文字4","文字5"],
["tb01serti10","NNS-003","SE-00652","NK000000009","H-0010001","2023/03/17 8:42:32","A009","商品名009","7","文字1","文字2","文字3","文字4","文字5"],
["tb01serti11","NNS-003","SE-00652","NK000000009","H-0010002","2023/03/18 15:52:33","A002","商品名002","12","文字1","文字2","文字3","文字4","文字5"],
["tb01serti12","NNS-003","SE-00652","NK000000009","H-0010003","2023/03/23 21:47:34","A009","商品名009","35","文字1","文字2","文字3","文字4","文字5"],
["tb01serti13","NNS-003","KT-63222","NK000000009","H-0010001","2023/03/19 8:58:35","A001","商品名001","10","文字1","文字2","文字3","文字4","文字5"],
["tb01serti14","NNS-003","KT-63222","NK000000009","H-0010002","2023/03/18 10:32:36","A002","商品名002","8","文字1","文字2","文字3","文字4","文字5"],
["tb01serti15","NNS-003","AB-0003","NK000000009","H-0010003","2023/03/20 15:38:37","A009","商品名009","5","文字1","文字2","文字3","文字4","文字5"]
];

const cIdx_key = 0;
const cIdx_col = 1;
const cIdx_name = 2;
const cIdx_type = 3;
const cIdx_length = 4;
const cIdx_visible = 5;
const cIdx_disporder = 6;
const cIdx_sortorder = 7;
const cIdx_sortad = 8;
  
let tbSetting =[
  ["rkey","list_column_pg_name","list_column_display_name","data_type","digits","display_kinds","display_order","sort_order","asc_desc"],
  ["sys01#cus01#test01","tb_key","table_key","varchar","12","key","0","",""],
  ["sys01#cus01#test01","customer_code","荷主_コード","varchar","12","visible","13","",""],
  ["sys01#cus01#test01","logistics_base_code","拠点_コード","varchar","12","visible","14","1","A"],
  ["sys01#cus01#test01","arrival_slip_no","入荷_伝票_番号","varchar","12","hide","0","",""],
  ["sys01#cus01#test01","order_no","発注_番号","varchar","25","hide","0","",""],
  ["sys01#cus01#test01","regist_datetime","登録_日時","timestamp","20","hide","0","",""],
  ["sys01#cus01#test01","prod_code","商品コード","varchar","50","visible","10","",""],
  ["sys01#cus01#test01","prod_name","商品名","varchar","50","visible","11","2","A"],
  ["sys01#cus01#test01","prod_qty","数量","integer","10","visible","12","3","D"],
  ["sys01#cus01#test01","extinfo1","在庫キー（文字1）","varchar","50","hide","0","",""],
  ["sys01#cus01#test01","extinfo2","在庫キー（文字2）","varchar","50","hide","0","",""],
  ["sys01#cus01#test01","extinfo3","在庫キー（文字3）","varchar","50","hide","0","",""],
  ["sys01#cus01#test01","extinfo4","在庫キー（文字4）","varchar","50","hide","0","",""],
  ["sys01#cus01#test01","extinfo5","在庫キー（文字5）","varchar","50","hide","0","",""]
  ];

  //['tb01serti15', 'red']
  //['tb01serti11', 'black']
const tbRowColorSetting =[];


const myDispList = new SelectDisplayList('delete','add','fb_list','select_list','btnMoveUp','btnMoveDown','btnMoveUpTop','btnMoveDownBot');

const mySortList = new SelectSortList('sortdrop1', 'sortdrop2', 'sortdrop3', 'sortAD1','sortAD2','sortAD3');

const myCusDataGrid = new CusDataGrid('tableDiv');



/**
 * @description: Get row Color setting From tbRowColorSetting
 *               -- Not Provide any function in CusDataGrid
 * @param {*} argKey
 * @return {*}
 */
function GetRowColor(argKey) {
  //['tb01serti15', 'red']
  //['tb01serti11', 'black']
  for (let i = 0; i < tbRowColorSetting.length; i++) {
      if(tbRowColorSetting[i][0]===argKey){
        return tbRowColorSetting[i][1];
      }
  }
  return "NoColor";
}

/**
 * @description:  Generate DataGrid HTML
 * @param {*} argTitle
 * @param {*} arglist
 * @return {*}
 */
function MakeTable(argTitle, arglist) {  

  let tableFrm = `<table id="[TABLE_ID]" class="display table-min-weight mam_dragdrop thin sortable draggable">
    <thead>
        <tr class="bg-secondary text-light">
            <td class="bg-white text-end" style="width:10px !important;"><button id="newRowBtn" class="button_custom"  data-bs-toggle="modal"
              data-bs-target="#exampleModal_edit" data-bs-whatever="@mdo" ><i class="bi bi-plus-lg"></i></button></td>
            [TH_DATA]
        </tr>
    </thead>
    <tbody>
        [TD_DATA]
    </tbody>
  </table>`;

  let tdButton = `<td class="text-center bg-white">
  <div class="dropdown-menu-static-demo">
  <div class="dropdown">
      <button class="btn btn-sm m-0 button_custom" type="button"
          id="dropdownMenuButton2" data-bs-toggle="dropdown" aria-haspopup="true"
          aria-expanded="true"><i class="bi bi-three-dots"></i></button>
      <div class="dropdown-menu table_dropmenu" aria-labelledby="dropdownMenuButton2">
          <button name = "gridrowedit" class="dropdown-item btn-sm" type="button" data-bs-toggle="modal"
              data-bs-target="#exampleModal_edit" data-bs-whatever="@mdo" [KEY_DATA]>
              <i class="bi bi-pencil"></i>&nbsp編集</button>
          <button name = "gridrowcopy" class="dropdown-item btn-sm" type="button" data-bs-toggle="modal"
              data-bs-target="#exampleModal_edit" data-bs-whatever="@mdo" [KEY_DATA]>
              <i class="bi bi-files"></i>&nbspコピー</button>
          <div class="dropdown-divider"></div>
          <button name = "gridrowdel" class="dropdown-item btn-sm" type="button" [KEY_DATA]>
              <i class="bi bi-trash-fill"></i>&nbsp削除</button>
      </div>
  </div>
  </div>
  </td>`;

  let TH_DATA = "";
  let arrVisible = [];
  let TD_DATA = "";
  let tdData = "";
  let tdTemp = "";
  let keyTemp = "";

  // th 作成
  for (let i = 0; i < argTitle.length; i++) {    
    if(argTitle[i][2]==='0')
    {
      arrVisible[i] = "key";  // したに TH_DATA 設定用
      continue;
    }
    arrVisible[i] = "data";  // したに TH_DATA 設定用
    TH_DATA += "<th scope=\"col\">" + argTitle[i][1] + "</th>";  // <th scope="col">商品コード</th>
  }

  // Loop 行
  for (let i = 0; i < arglist.length; i++) {

    keyTemp = "";
    tdData = "";
    rowColor = "";

    // Loop 列
    for (let j = 0; j < arglist[0].length; j++) {
      if(arrVisible[j] === "key"){
        // keyTemp -->  k1 = "xxxx" k2 = "xxxx"
        keyTemp += "k"+ j.toString() +" = \"" +arglist[i][j] +"\" ";
        
        let keyVal = arglist[i][j];
        rowColor = GetRowColor(keyVal);  //Get row color
      }      

      if(arrVisible[j] === "data"){
        tdData += "<td>" + arglist[i][j] + "</td>";  //<td>良品</td>
      }
    }

    tdTemp = tdButton;
    tdTemp = tdTemp.replace(/\[KEY_DATA]/g, keyTemp);

    // Set copy data background color
    
    if(rowColor === 'red')
    {
      TD_DATA += "<tr class='bg-red'>" +tdTemp + tdData + "</tr>";
    }
    else if(rowColor === 'black')
    {
      TD_DATA += "<tr class='bg-secondary'>" +tdTemp + tdData + "</tr>";
    }
    else
    {
      TD_DATA += "<tr>" +tdTemp + tdData + "</tr>";
    }    
  }
  
  tableFrm = tableFrm.replace('[TH_DATA]', TH_DATA);
  tableFrm = tableFrm.replace('[TD_DATA]', TD_DATA);  
  return tableFrm;
}

/**
 * @description:  reInit Js table control
 * @param {*} tbid
 * @return {*}
 */
function ReDrawGrid(tbid) {
  // let TB_ID = "#"+tbid;
  // $(TB_ID).DataTable();

  let TB_ID = "#"+tbid;
  $(TB_ID).DataTable({
    autowidth: false,
    columnDefs: [
       { targets: 0, width: "10px" },
       { targets: 1, width: "15%" } ]
  });
  $(TB_ID).attr('style', 'width: 100%;');
}

// 編集・コピー・削除後→送信ボタンフレッシュ
function setButtonFlash() {
  // const myBtn = document.getElementById('js-buttonflash');
  const myBtn = document.getElementById('registerButton');
  myBtn.classList.add('dataSubmitButton');
}

/**
 * @description:  Bind button click event After Generate Table HTML
 *                Called in CusDataGrid.ReSetGrid()
 * @return {*}
 */
function SetGridRowClick() {

  //  if new  --> clear all
  //  if modify --> set all
  //  if copy --> set all + clear key
  // 　OPEN window
  let rowButtons = document.getElementsByName("gridrowedit");
  rowButtons.forEach(function(rowButton) {
    rowButton.addEventListener("click", function() {

      //const attributeNames = this.getAttributeNames(); // 获取所有属性名
      // let allatt = "";
      // for (let attributeName of attributeNames) { // 遍历所有属性名
      //   const attributeValue = this.getAttribute(attributeName); // 获取属性值
      //   allatt += attributeName + ": " + attributeValue + "  "; // 输出属性名和属性值
      // } 
      // alert(allatt);

      let keyValue = this.getAttribute("k0"); // 获取属性值
      // alert(GetRowDataByKey(keyValue));

      let rowData = myCusDataGrid.GetRowDataByKey(keyValue);
      document.getElementById('check_Data').value = "edit";
      document.getElementById('identity_Key').value = rowData[tbIdx_key];
      document.getElementById('update_Data').value = rowData[tbIdx_datetime];
      document.getElementById('product_Code').value = rowData[tbIdx_prod_code];
      document.getElementById('product_Name').value = rowData[tbIdx_prod_name];
      document.getElementById('shipper_Code').value = rowData[tbIdx_customer_code];
      document.getElementById('location_Code').value = rowData[tbIdx_logistics_code];
      document.getElementById('incoming_Number').value = rowData[tbIdx_slip_no];
      document.getElementById('purchase_Number').value = rowData[tbIdx_order_no];
      document.getElementById('quantity').value = rowData[tbIdx_prod_qty];
      document.getElementById('inventory_Key1').value = rowData[tbIdx_extinfo1];
      document.getElementById('inventory_Key2').value = rowData[tbIdx_extinfo2];
      document.getElementById('inventory_Key3').value = rowData[tbIdx_extinfo3];
      document.getElementById('inventory_Key4').value = rowData[tbIdx_extinfo4];
      document.getElementById('inventory_Key5').value = rowData[tbIdx_extinfo5];

      // Set Data to popup view
    });
  });

  let rowDelButtons = document.getElementsByName("gridrowdel");
  rowDelButtons.forEach(function(rowButton) {
    rowButton.addEventListener("click", function() {
      let keyValue = this.getAttribute("k0"); // 获取属性值      

      let rowColor = [];
      rowColor[0] = keyValue;
      rowColor[1] = "black";
      tbRowColorSetting[tbRowColorSetting.length] = rowColor;

      //Set ButtonFlash
      setButtonFlash();

      //Set grid
      myCusDataGrid.ReSetGrid();  
    });
  });

  let rowCopyButtons = document.getElementsByName("gridrowcopy");
  rowCopyButtons.forEach(function(rowButton) {
    rowButton.addEventListener("click", function() {
      let keyValue = this.getAttribute("k0"); // 获取属性值
      
      let rowData = myCusDataGrid.GetRowDataByKey(keyValue);
      document.getElementById('check_Data').value = "copy";
      document.getElementById('identity_Key').value = rowData[tbIdx_key] + myCusDataGrid.GetHHmmss();
      document.getElementById('update_Data').value = rowData[tbIdx_datetime];
      document.getElementById('product_Code').value = rowData[tbIdx_prod_code];
      document.getElementById('product_Name').value = rowData[tbIdx_prod_name];
      document.getElementById('shipper_Code').value = rowData[tbIdx_customer_code];
      document.getElementById('location_Code').value = rowData[tbIdx_logistics_code];
      document.getElementById('incoming_Number').value = rowData[tbIdx_slip_no];
      document.getElementById('purchase_Number').value = rowData[tbIdx_order_no];
      document.getElementById('quantity').value = rowData[tbIdx_prod_qty];
      document.getElementById('inventory_Key1').value = rowData[tbIdx_extinfo1];
      document.getElementById('inventory_Key2').value = rowData[tbIdx_extinfo2];
      document.getElementById('inventory_Key3').value = rowData[tbIdx_extinfo3];
      document.getElementById('inventory_Key4').value = rowData[tbIdx_extinfo4];
      document.getElementById('inventory_Key5').value = rowData[tbIdx_extinfo5];
      
      // Set Data to popup view
    });
  });

  let newButton = document.getElementById("newRowBtn");
  newButton.addEventListener("click", function() {
      //let keyValue = this.getAttribute("k0"); // 获取属性值      
      //let rowData = GetRowDataByKey(keyValue);
      document.getElementById('check_Data').value = "new";
      document.getElementById('identity_Key').value = "new" + myCusDataGrid.GetHHmmss();
      document.getElementById('update_Data').value = "";
      document.getElementById('product_Code').value = "";
      document.getElementById('product_Name').value = "";
      document.getElementById('shipper_Code').value = "";
      document.getElementById('location_Code').value = "";
      document.getElementById('incoming_Number').value = "";
      document.getElementById('purchase_Number').value = "";
      document.getElementById('quantity').value = "";
      document.getElementById('inventory_Key1').value = "";
      document.getElementById('inventory_Key2').value = "";
      document.getElementById('inventory_Key3').value = "";
      document.getElementById('inventory_Key4').value = "";
      document.getElementById('inventory_Key5').value = "";
  });

}

/**
 * @description: Add Save Button Event 
 *               Called in InitPage()
 * @param {*} arrParam
 * @return {*}
 */
function AddEventToEditSaveButton() {
  const arrParam = myCusDataGrid._tbData;

  //Set modalSaveButton
  let saveButton = document.getElementById("modalSaveButton"); // in edit subform Save button
  saveButton.addEventListener("click", function() {

    let subType= document.getElementById('check_Data').value;  // in edit subform  edit/new/copy
    let dataKey= document.getElementById('identity_Key').value; // in edit subform

    //Color Setting Array
    let rowColor = [];
    rowColor[0] = dataKey;
    rowColor[1] = "red";
    // ['tb01serti15', 'red']
    tbRowColorSetting[tbRowColorSetting.length] =rowColor;  // append at the end of tbRowColorSetting

    // if new  --> append Array
    // if edit --> modify Array  
    // if copy --> append Array
    if(subType === "edit"){
        let dataIndex = myCusDataGrid.GetRowIndexByKey(dataKey);
        //元データの修正
        let editRow = arrParam[dataIndex];
        editRow[tbIdx_datetime] = document.getElementById('update_Data').value;
        editRow[tbIdx_prod_code] = document.getElementById('product_Code').value;
        editRow[tbIdx_prod_name] = document.getElementById('product_Name').value;
        editRow[tbIdx_customer_code] = document.getElementById('shipper_Code').value;
        editRow[tbIdx_logistics_code] = document.getElementById('location_Code').value;
        editRow[tbIdx_slip_no] = document.getElementById('incoming_Number').value;
        editRow[tbIdx_order_no] = document.getElementById('purchase_Number').value;
        editRow[tbIdx_prod_qty] = document.getElementById('quantity').value;
        editRow[tbIdx_extinfo1] = document.getElementById('inventory_Key1').value;
        editRow[tbIdx_extinfo2] = document.getElementById('inventory_Key2').value;
        editRow[tbIdx_extinfo3] = document.getElementById('inventory_Key3').value;
        editRow[tbIdx_extinfo4] = document.getElementById('inventory_Key4').value;
        editRow[tbIdx_extinfo5] = document.getElementById('inventory_Key5').value;
    }

    if((subType === "new")||(subType === "copy")){
        //元Arrayの最後に追加
        let newRow = [];
        newRow[tbIdx_key] = dataKey;
        newRow[tbIdx_datetime] = document.getElementById('update_Data').value;
        newRow[tbIdx_prod_code] = document.getElementById('product_Code').value;
        newRow[tbIdx_prod_name] = document.getElementById('product_Name').value;
        newRow[tbIdx_customer_code] = document.getElementById('shipper_Code').value;
        newRow[tbIdx_logistics_code] = document.getElementById('location_Code').value;
        newRow[tbIdx_slip_no] = document.getElementById('incoming_Number').value;
        newRow[tbIdx_order_no] = document.getElementById('purchase_Number').value;
        newRow[tbIdx_prod_qty] = document.getElementById('quantity').value;
        newRow[tbIdx_extinfo1] = document.getElementById('inventory_Key1').value;
        newRow[tbIdx_extinfo2] = document.getElementById('inventory_Key2').value;
        newRow[tbIdx_extinfo3] = document.getElementById('inventory_Key3').value;
        newRow[tbIdx_extinfo4] = document.getElementById('inventory_Key4').value;
        newRow[tbIdx_extinfo5] = document.getElementById('inventory_Key5').value;

        arrParam[arrParam.length] = newRow;
        // alert(arrParam.length);
    }
    
    //Set ButtonFlash
    setButtonFlash();

    //Set grid
    myCusDataGrid.ReSetGrid(); 
  });
}

// ******************************   CusDataGrid利用する時 必要な外部定義 END   *****************************




// ******************************   外部利用関数 BEGIN   *****************************
  
/**
 * @description:  When first time open the page
 * @return {*}
 */
function InitPage() {

  myCusDataGrid.InitControls(tbData, tbSetting);  

  // GetHVCols(tbSetting, 'hide')
  // [ [ 3, '入荷_伝票_番号', '0' ],
  // [ 4, '発注_番号', '0' ],
  // [ 5, '登録_日時', '0' ],
  // [ 9, '在庫キー（文字1）', '0' ],
  // [ 10, '在庫キー（文字2）', '0' ],
  // [ 11, '在庫キー（文字3）', '0' ],
  // [ 12, '在庫キー（文字4）', '0' ],
  // [ 13, '在庫キー（文字5）', '0' ] ];

  // GetHVCols(tbSetting, 'visible')
  // let bb = [ [ 0, 'table_key', '0' ],
  // [ 6, '商品コード', '10' ],
  // [ 7, '商品名', '11' ],
  // [ 8, '数量', '12' ],
  // [ 1, '荷主_コード', '13' ],
  // [ 2, '拠点_コード', '14' ] ];
  myDispList.InitControls();
  myDispList.SetAllListControl(myCusDataGrid.GetHVCols('hide'));
  myDispList.SetDispListControl(myCusDataGrid.GetHVCols('visible'));

  // GetSortItems(tbSetting)
  // [ [ 999, '-- ソート項目 --', '' ],
  // [ 1, '荷主_コード', '' ],
  // [ 2, '拠点_コード', '' ],
  // [ 3, '入荷_伝票_番号', '' ],
  // [ 4, '発注_番号', '' ],
  // [ 5, '登録_日時', '' ],
  // [ 6, '商品コード', '' ],
  // [ 7, '商品名', '' ],
  // [ 8, '数量', '' ],
  // [ 9, '在庫キー（文字1）', '' ],
  // [ 10, '在庫キー（文字2）', '' ],
  // [ 11, '在庫キー（文字3）', '' ],
  // [ 12, '在庫キー（文字4）', '' ],
  // [ 13, '在庫キー（文字5）', '' ] ];

  // GetSortCols(tbSetting)
  // let dd = [ [ 2, '拠点_コード', '1', 'A', 'varchar' ],
  // [ 7, '商品名', '2', 'A', 'varchar' ],
  // [ 8, '数量', '3', 'D', 'integer' ] ];
  mySortList.Set3Control(myCusDataGrid.GetSortItems());
  mySortList.Set3SelectedValue(myCusDataGrid.GetSortCols());

  //Set grid
  myCusDataGrid.ReSetGrid();  
  
  //Set EditForm　Save button
  AddEventToEditSaveButton();


}

/**
 * @description:  Select visible --> 適用 button click
 * @return {*}
 */
function ReSetVisibleItems(){
  let visibleItems = myDispList.GetSelectedDispColList();  
  // visibleItems
  // ['6', '商品コード', '10']
  // ['7', '商品名', '11']
  // ['8', '数量', '12']
  // ['1', '荷主_コード', '13']
  // ['2', '拠点_コード', '14']
  // ['12', '在庫キー（文字4）', '15']
  // ['13', '在庫キー（文字5）', '16']
  // console.log(visibleItems);
  myCusDataGrid.ModifyVisible(visibleItems);

  //Set grid
  myCusDataGrid.ReSetGrid();
}

/**
 * @description:  Select Sort --> 適用 button click
 * @return {*}
 */
function ReSetSortItems(){

  let sel = mySortList.Get3ColChosen();
  //console.log(sel);
  let ad = mySortList.Get3AdChosen();
  //console.log(ad);
  myCusDataGrid.ModifySort(sel, ad);  
  //Set grid
  myCusDataGrid.ReSetGrid();
}

// ******************************   外部利用関数 END   *****************************





///////////////////////////// 入荷 Master Data List Select /////////////////////////
let arriveList = [
  {col1: 'HIN000000000000111', col2: '2023/04/04' , col3: 'AAAA'},
  {col1: 'HIN000000000000222', col2: '2023/04/07' , col3: 'BBBB'},
  {col1: 'HIN000000000000333', col2: '2023/04/08' , col3: 'CCCC'},
  {col1: 'HIN000000000000444', col2: '2023/04/09' , col3: 'DDDD'},
  {col1: 'HIN000000000000555', col2: '2023/05/01' , col3: 'EEEE'},
  {col1: 'HIN000000000000666', col2: '2023/05/01' , col3: 'FFFF'},
  {col1: 'HIN000000000000777', col2: '2023/05/02' , col3: 'GGGG'},
  {col1: 'HIN000000000000888', col2: '2023/05/05' , col3: 'HHHH'}  ];
const arriveMST = new MasterSearchTable('searchDataTable','chooseBtn');  

// ******** POST Function Before/After 定義 Begin ********
const Post_Type_Info = [
  ["P001", "./WkpGetPost/DoPost", "NkYoteiSlipSearch", "P001After"],
  ["P002", "./WkpGetPost/DoPost", "NkYoteiAutoSupplier", "P002After"],
  ["P003", "./WkpGetPost/DoPost", "NkYoteiAutoSupplier", "P003After"],
  ["P004", "./WkpGetPost/DoPost", "NkYoteiDataSearch", "P004After"]
];

function P001After(rData) {                        

  let dl1Data = [];
  dl1Data = GetRespArrData(rData.dl1);  
  dl1Data.splice(0, 1);  // 去掉第一行 只保留数据行
  let dl1DataTitle = ["col1","col2","col3"];
  arriveList = GetValueList2(dl1DataTitle, dl1Data);

  arriveMST.InitControls();  
  arriveMST.SetTableData(arriveList);  
}

function P001Before(){  

  //Get 前方一致
  let selectElement = document.getElementById('selectArriveMatch');
  let selectedValue = selectElement.options[selectElement.selectedIndex].value;
  //alert(selectedValue);
  //Get Slip number
  let slipNo = document.getElementById('inputArriveMatch').value;
  //alert(slipNo);
  let arrDate1 = document.getElementById('inputArrive_date1').value.replace(/-/g, "");
  //alert(arrDate1);
  let arrDate2 = document.getElementById('inputArrive_date2').value.replace(/-/g, "");
  //alert(arrDate2);

  //Send POST to Server
  let typeName = "P001";
  // sdata.set( パラメータ名(任意) , パラメータ 値);
  let sdata = new Map();
  sdata.set('syscode', 'sys01');
  sdata.set('cuscode', 'cus01');
  sdata.set('datebegin', arrDate1);
  sdata.set('dateend', arrDate2);
  sdata.set('slipno', slipNo);
  sdata.set('liketype', selectedValue);

  //共通 Send POST Function
  SendPostReq(typeName, sdata, "L001", "D001", "T001", "S001", "ja-jp", "");
  
}
// ******** POST Function Before/After 定義 End ********

/**
 * @description: 
 * @return {*}
 */
function CreateArriveMSTinstance(){
  //実際 以下のControl 設定は P001Afterに実行する
  arriveMST.InitControls();  
  arriveMST.SetTableData(arriveList);  
}

function ArriveMstInitShow(){  
  //Get 入荷伝票番号
  let SlipNo = document.getElementById('invoiceNumberInput').value;
  //Set to Master 検索画面
  document.getElementById('inputArriveMatch').value = SlipNo;
  
  //Set Date Begin ～ End  
  let currentDate = new Date();  
  let oneMonthAgo = new Date();
  oneMonthAgo.setMonth(currentDate.getMonth() - 1);
  // 日付 to（YYYY-MM-DD）
  let formattedDate = oneMonthAgo.toISOString().split('T')[0];
  document.getElementById('inputArrive_date1').value = formattedDate;
  formattedDate = currentDate.toISOString().split('T')[0];
  document.getElementById('inputArrive_date2').value = formattedDate;
}

//検索ボタンClickすると ArriveMstInitShow()を実行する
document.getElementById('arriveSearchBtn').addEventListener('click', ArriveMstInitShow);

function SetValueBack(gridid, a,b,c){

  if(gridid==='searchDataTable')
  {
    const itemA = document.getElementById('invoiceNumberInput');  //purchaseOrderNumberInput
    // const itemB = document.getElementById('supplierInput');
    const itemC = document.getElementById('arriveDateInput');
    itemA.value = a;
    // itemB.value = b;

    let ttt = new Date(b);
    ttt.setUTCHours(ttt.getUTCHours() + 9); // 将时间设置为 GMT+9
    const dateString = ttt.toISOString().slice(0, 10);  
    itemC.value = dateString;

    SetFormStatus(3);

    // Set Data Grid
      P004Before(); // Get data via POST
      //InitPage();

  } 
  
  if(gridid==='searchDataTable2')
  {
    const itemA = document.getElementById('supplierInput');      
    itemA.value = a;
    
    SetFormStatus(3);
  } 

}

///////////////////////////// 仕入先 Master Data List Select /////////////////////////
let supplierList = [
  {col1: 'SUP000111222333', col2: '仕入先名称１', col3: '2023/04/04' },
  {col1: 'SUP000111222334', col2: '仕入先名称２', col3: '2023/04/07' },
  {col1: 'SUP000111222335', col2: '仕入先名称３', col3: '2023/04/08' },
  {col1: 'SUP000111222336', col2: '仕入先名称４', col3: '2023/04/09' },
  {col1: 'SUP000111222337', col2: '仕入先名称５', col3: '2023/05/01' },
  {col1: 'SUP000111222338', col2: '仕入先名称６', col3: '2023/05/01' },
  {col1: 'SUP000111222339', col2: '仕入先名称７', col3: '2023/05/02' },
  {col1: 'SUP000111222340', col2: '仕入先名称８', col3: '2023/05/05' },
  {col1: 'SUP000111222341', col2: '仕入先名称９', col3: '2023/05/02' },
  {col1: 'SUP000111222342', col2: '仕入先名称０', col3: '2023/05/05' }];
const supplierMST = new MasterSearchTable('searchDataTable2','chooseBtn2');  

// ******** POST Function Before/After 定義 Begin ********

function P002After(rData) {                        

  let dl1Data = [];
  dl1Data = GetRespArrData(rData.dl1);  
  dl1Data.splice(0, 1);  // 去掉第一行 只保留数据行
  let dl1DataTitle = ["col1","col2","col3"];
  supplierList = GetValueList2(dl1DataTitle, dl1Data);

  supplierMST.InitControls();  
  supplierMST.SetTableData(supplierList);
}

function P002Before(){  

  //Send POST to Server
  let typeName = "P002";
  // sdata.set( パラメータ名(任意) , パラメータ 値);  
  let sdata = new Map();
  sdata.set('syscode', 'sys01');
  sdata.set('cuscode', 'cus01');
  sdata.set('suppliercode', '');
  sdata.set('searchtype', 'getmaster');

  //共通 Send POST Function
  SendPostReq(typeName, sdata, "L001", "D001", "T001", "S001", "ja-jp", "");  
}
// ******** POST Function Before/After 定義 End ********

function CreateSupplierMSTinstance(){  
  //実際 以下のControl 設定は P002Afterに実行する
  supplierMST.InitControls();  
  supplierMST.SetTableData(supplierList);
}

//検索ボタンClickすると P002Before()を実行する
document.getElementById('supplierSearchBtn').addEventListener('click', P002Before);

//入力Checkは formcheck.jsに設定する
document.getElementById('supplierInput').addEventListener('blur', SupplierInputBlur);

function SupplierInputBlur(){
  alert("Get 仕入先名 From 仕入先Code");
  P003Before();
}


// ******** POST Function Before/After 定義 Begin ********

function P003After(rData) {  
    
    const supplierError = document.getElementById('supplierError');

    if (rData.dl1.length === 0)
    {
        supplierError.textContent = '仕入先が存在しない';
        supplierError.style.color = 'red';
        return;
    }

    let dl1Data = [];
    dl1Data = GetRespArrData(rData.dl1);  
  // dl1":[
  //   {"c":["supplier_name"]},
  //   {"c":["仕入先名称12345"]} ]

    dl1Data.splice(0, 1);  // 去掉第一行 只保留数据行
    let supplier_name = dl1Data[0];
    supplierError.textContent = supplier_name;
    supplierError.style.color = 'black';

}

function P003Before(){  

  //Get supplier code
  let supplierCode = document.getElementById('supplierInput').value;

  //Send POST to Server
  let typeName = "P003";
  // sdata.set( パラメータ名(任意) , パラメータ 値);  
  let sdata = new Map();
  sdata.set('syscode', 'sys01');
  sdata.set('cuscode', 'cus01');
  sdata.set('suppliercode', supplierCode);
  sdata.set('searchtype', 'getonename');

  //共通 Send POST Function
  SendPostReq(typeName, sdata, "L001", "D001", "T001", "S001", "ja-jp", "");  
}
// ******** POST Function Before/After 定義 End ********



// ******** POST Function Before/After 定義 Begin ********

function P004After(rData) {

    let dl1Data = [];
    dl1Data = GetRespArrData(rData.dl1);
    tbData = dl1Data;

    console.log(tbData);

    let dl2Data = [];
    dl2Data = GetRespArrData(rData.dl2);
    tbSetting = dl2Data;

    console.log(tbSetting);

    InitPage();
}

function P004Before() {

    //Get 入荷伝票番号
    let slip_no = document.getElementById('invoiceNumberInput').value;
    alert(slip_no);

    //Send POST to Server
    let typeName = "P004";
    // sdata.set( パラメータ名(任意) , パラメータ 値);
    let sdata = new Map();
    sdata.set('syscode', 'sys01');
    sdata.set('cuscode', 'cus01');
    sdata.set('logistics', 'log01');
    sdata.set('slipno', 'slipno2');
    sdata.set('programid', 'yotei1');

    //共通 Send POST Function
    SendPostReq(typeName, sdata, "L001", "D001", "T001", "S001", "ja-jp", "");
}

// ******** POST Function Before/After 定義 End ********
