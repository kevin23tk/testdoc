// POST Function Before/After 定義
const Post_Type_Info = [
    ["P100", "/WkpGetPost/DoPost", "Yotei01", "P100After"],
    ["P200", "/WkpGetPost/DoPost", "Yotei02", "P200After"],
];


function P100Before() {

    let typeName = "P100";
    let pp = document.getElementById('syscode').value;

    // sdata.set( パラメータ名(任意) , パラメータ 値);
    let sdata = new Map();
    //sdata.set('syscode_max', 'syscode22');
    sdata.set('syscode_max', pp);

    //共通 Send POST Function
    SendPostReq(typeName, sdata, "L001", "D001", "T001", "S001", "ja-jp", "");
}

function P100After(rData) {

    //console.log(JSON.stringify(rData, null, 4));
    //document.getElementById('rejson').value = JSON.stringify(rData, null, 4);

    //let jsonStr = JSON.stringify(rData);
    //jsonStr = jsonStr.replace(/\\"/g, '"');

    //let output = document.getElementById('msg');
    //output.innerHTML = jsonStr;

    let arrC = GetRespArrData(rData.dl1);
    let output = document.getElementById('dttable');
    output.innerHTML = addTable(arrC);
}


function P200Before() {

    let typeName = "P200";
    //let pp = document.getElementById('syscode').value;

    // sdata.set( パラメータ名(任意) , パラメータ 値);
    let sdata = new Map();
    sdata.set('shipcode', 'shipcode12');
    sdata.set('sitecode', 'sitecode12');

    //共通 Send POST Function
    SendPostReq(typeName, sdata, "L001", "D001", "T001", "S001", "ja-jp", "");
}

function P200After(rData) {

    //console.log(JSON.stringify(rData, null, 4));
    //document.getElementById('rejson').value = JSON.stringify(rData, null, 4);

    //let jsonStr = JSON.stringify(rData);
    //jsonStr = jsonStr.replace(/\\"/g, '"');

    //let output = document.getElementById('msg');
    //output.innerHTML = jsonStr;

    let arrC = GetRespArrData(rData.dl1);
    let output = document.getElementById('dttable');
    output.innerHTML = addTable(arrC);
}



function addTable(arglist) {

    let aa = arglist;
    let reStr = "";
    let tbheadStr = "";
    for (let j = 0; j < aa[0].length; j++) {

        tbheadStr += "<th scope=\"col\">" + aa[0][j] + "</th>";
    }
    tbheadStr = "<thead><tr class=\"bg-secondary text-light\">" + tbheadStr + "</tr></thead>";

    //let htmlRow = "";
    for (let i = 1; i < aa.length; i++) {

        for (let j = 0; j < aa[0].length; j++) {

            reStr += "<td>" + aa[i][j] + "</td>";
        }
        reStr = "<tr>" + reStr + "</tr>";
    }

    reStr = "<table class=\"mt-3 table table-bordered table-striped table-hover py-4 px-4 text-nowrap\">" + tbheadStr + "<tbody>" + reStr + "</tbody></table>";

    return reStr;
}


//<table class="mt-3 table table-bordered table-striped table-hover py-4 px-4 text-nowrap">
//    <thead>
//        <tr class="bg-secondary text-light">
//            <th scope="col">ロケーション</th>
//            <th scope="col">ケース数</th>
//            <th scope="col">入庫数</th>
//            <th scope="col">品質名</th>
//            <th scope="col">管理部門名</th>
//            <th scope="col">ラベル枚数</th>
//        </tr>
//    </thead>
//    <tbody>
//        <tr>
//            <th scope="form-row">S1-A1-0001</th>
//            <td>10</td>
//            <td>250</td>
//            <td>良品</td>
//            <td>無し</td>
//            <td>1</td>
//        </tr>
//    </tbody>
//</table>