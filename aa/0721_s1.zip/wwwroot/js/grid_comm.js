/*
 * @Author: Kamikawa
 * @Date: 2023-05-15 15:43:59
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2023-05-25 16:06:07
 * @FilePath: \JS_TEST\wkp-demo-0522\grid_comm.js
 * @Description: 
 * 
 * Copyright (c) 2023 by ${git_name_email}, All Rights Reserved. 
 */

///////////////////////////// JS Common Functions START /////////////////////////

/**
 * @description: Copy a Array Do not Change the Original Array
 * @param {*} array
 * @return {*}
 */
function copy2DArray(array) {
  return array.map(row => row.slice());
}

/**
 * @description: GetValueList1
 *  2dimension Array Data Convert to object{key value}
 *  param - dataList --> title & data
 * @param {*} dataList
 * @return {*}
 */
function GetValueList1(dataList)
{
  // Copy 数组不影响数据源
  const dtList = copy2DArray(dataList);  
  const listTitle = dtList[0]; // Get FirstRow title
  dtList.splice(0, 1);  // 去掉第一行 只保留数据行
  return GetValueList2(listTitle, dtList);
}

/**
 * @description: GetValueList2
 *  2dimension Array Data Convert to object{key value}
 * @param {*} dtTitle
 * @param {*} dtData
 * @return {*}
 */
function GetValueList2(dtTitle, dtData)
{
  const List3 = [];
  for (let i = 0; i < dtData.length; i++) {
    const element2 = dtData[i];
    const element3 = {};

    for (let j = 0; j < dtTitle.length; j++) {
      const key = dtTitle[j];
      const value = element2[j];
      element3[key] = value;
    }

    List3.push(element3);
  }
  return List3;
}

// let list1 = [
//   ['col1','col2','col3'],
//   ['HIN000000000000111','2023/04/04','AAAA'],
//   ['HIN000000000000222','2023/04/07','BBBB'],
//   ['HIN000000000000333','2023/04/08','CCCC'],
//   ['HIN000000000000444','2023/04/09','DDDD'],
//   ['HIN000000000000555','2023/05/01','EEEE'],
//   ['HIN000000000000666','2023/05/01','FFFF'],
//   ['HIN000000000000777','2023/05/02','GGGG'],
//   ['HIN000000000000888','2023/05/05','HHHH']];

// let list1a = GetValueList1(list1);
// console.log(list1a);

// list1.splice(0, 1);  // 去掉第一行 只保留数据行
// let list2Title = ["col1","col2","col3"];
// let list2a = GetValueList2(list2Title, list1);
// console.log(list2a);

///////////////////////////// JS Common Functions END //////////////////////////


///////////////////////////// JS Common Class START /////////////////////////

// 表示項目選択
class SelectDisplayList {
  
  constructor(toLeftBtnID,toRightBtnID,AllListID,DispListID,btnMoveUpID,btnMoveDownID,btnMoveUpTopID,btnMoveDownBotID) 
  {
    this._toLeftBtn = document.getElementById(toLeftBtnID);
    this._toRightBtn = document.getElementById(toRightBtnID);
    this._AllList = document.getElementById(AllListID);
    this._DispList = document.getElementById(DispListID);
    this._btnMoveUp = document.getElementById(btnMoveUpID);
    this._btnMoveDown = document.getElementById(btnMoveDownID);
    this._btnMoveUpTop = document.getElementById(btnMoveUpTopID);
    this._btnMoveDownBot = document.getElementById(btnMoveDownBotID);
  }

  InitControls() {

    const allList = this._AllList;
    const dispList = this._DispList;
    
    this._toRightBtn.addEventListener("click", function() {        
      const selectedOptions = allList.querySelectorAll("option:checked");
      if (selectedOptions.length > 0) {
        selectedOptions.forEach(function(option) {
          const newOption = document.createElement("option");
          newOption.value = option.value;
          newOption.textContent = option.textContent;
          dispList.appendChild(newOption);
          option.remove();
        });
      }
    });
    
    this._toLeftBtn.addEventListener("click", function() {
      const selectedOptions = dispList.querySelectorAll("option:checked");
      if (selectedOptions.length > 0) {
        selectedOptions.forEach(function(option) {
          const newOption = document.createElement("option");
          newOption.value = option.value;
          newOption.textContent = option.textContent;
          allList.appendChild(newOption);
          option.remove();
        });
      }
    });

    this._btnMoveUp.addEventListener("click", function() {
      const selectedOption = dispList.querySelector('option:checked');
      if (!selectedOption) return;
      const options = Array.from(dispList.querySelectorAll('option'));
      const selectedIndex = options.indexOf(selectedOption);
      if (selectedIndex > 0) {
        options[selectedIndex - 1].before(selectedOption);        
      }
    });

    this._btnMoveDown.addEventListener("click", function() {
      const selectedOption = dispList.querySelector('option:checked');
      if (!selectedOption) return;
      const options = Array.from(dispList.querySelectorAll('option'));
      const selectedIndex = options.indexOf(selectedOption);
      if (selectedIndex < options.length - 1) {
        options[selectedIndex + 1].after(selectedOption);
      }
    });


    this._btnMoveUpTop.addEventListener("click", function() {
      const selectedOption = dispList.querySelector('option:checked');
      if (!selectedOption) return;
      const options = Array.from(dispList.querySelectorAll('option'));
      const selectedIndex = options.indexOf(selectedOption);
      if (selectedIndex > 0) {
        options[0].before(selectedOption);
      }
    });

    this._btnMoveDownBot.addEventListener("click", function() {
      const selectedOption = dispList.querySelector('option:checked');
      if (!selectedOption) return;
      const options = Array.from(dispList.querySelectorAll('option'));
      const selectedIndex = options.indexOf(selectedOption);
      if (selectedIndex < options.length - 1) {
        dispList.appendChild(selectedOption);
      }
    });
    
    document.addEventListener('keydown', function(evt) {
      if (!evt.altKey) return;
      const k = evt.which;
      if (k === 38) {
        this._btnMoveUp.click();
        evt.preventDefault();
      } else if (k === 40) {
        this._btnMoveDown.click();
        evt.preventDefault();
      }
    });
  }

  // [ [ 3, '入荷_伝票_番号', '0' ],
  //   [ 4, '発注_番号', '0' ],
  //   [ 5, '登録_日時', '0' ],
  //   [ 9, '在庫キー（文字1）', '0' ],
  //   [ 10, '在庫キー（文字2）', '0' ],
  //   [ 11, '在庫キー（文字3）', '0' ],
  //   [ 12, '在庫キー（文字4）', '0' ],
  //   [ 13, '在庫キー（文字5）', '0' ] ]
  SetAllListControl(arrParam) {
    this._AllList.innerHTML = "";
    for (let i = 0; i < arrParam.length; i++) {
      let option = document.createElement("option");
      option.value = arrParam[i][0];
      option.text = arrParam[i][1];
      this._AllList.add(option);
    }
  }

  // [ [ 0, 'table_key', '0' ],
  // [ 6, '商品コード', '10' ],
  // [ 7, '商品名', '11' ],
  // [ 8, '数量', '12' ],
  // [ 1, '荷主_コード', '13' ],
  // [ 2, '拠点_コード', '14' ] ]
  SetDispListControl(arrParam) {      
    this._DispList.innerHTML = "";
    for (let i = 0; i < arrParam.length; i++) {
      // when set visible select control skip the key column (arrParam[i][2] === "0")        
      if(arrParam[i][2] === "0"){continue;}
      let option = document.createElement("option");
      option.value = arrParam[i][0];
      option.text = arrParam[i][1];
      this._DispList.add(option);
    }
  }

  // GetSelectedDispColList('select_list')
  // ['6', '商品コード', '10']
  // ['7', '商品名', '11']
  // ['8', '数量', '12']
  // ['1', '荷主_コード', '13']
  // ['2', '拠点_コード', '14']
  // ['12', '在庫キー（文字4）', '15']
  // ['13', '在庫キー（文字5）', '16']
  /**
   * @description: 
   * @param {*} controlId
   * @return {*}
   */
  GetSelectedDispColList() {
    // let selectElement = document.getElementById(controlId);
    let selectElement = this._DispList;
    let options = selectElement.options;
    
    let arrOut = [];
    let seq = 10;
    for (let i = 0; i < options.length; i++) {
      arrOut[i] = [];
      let option = options[i];
      arrOut[i][0] = option.value;
      arrOut[i][1] = option.text;
      arrOut[i][2] = seq.toString();
      seq++;
      }
    // console.log(arrOut);
    return arrOut;
  }

}

// ソート項目選択
class SelectSortList {

  constructor(sortdrop1, sortdrop2, sortdrop3, dropAD1, dropAD2, dropAD3) 
  {
    this._sortdrop = [];
    this._sortdrop[0] = document.getElementById(sortdrop1);
    this._sortdrop[1] = document.getElementById(sortdrop2);
    this._sortdrop[2] = document.getElementById(sortdrop3);

    this._dropAD = [];
    this._dropAD[0] = document.getElementById(dropAD1);
    this._dropAD[1] = document.getElementById(dropAD2);
    this._dropAD[2] = document.getElementById(dropAD3);

    // this.Get3ColChosen = this.Get3ColChosen.bind(this); // 绑定上下文
    // this.Get3AdChosen = this.Get3AdChosen.bind(this); // 绑定上下文
  }

  Set3Control(arrParam) {
    this.SetSelectControl1(this._sortdrop[0], arrParam);
    this.SetSelectControl1(this._sortdrop[1], arrParam);
    this.SetSelectControl1(this._sortdrop[2], arrParam);
  }

  SetSelectControl1(selectElement, arrParam) {      
    selectElement.innerHTML = "";
    for (let i = 0; i < arrParam.length; i++) {
      let option = document.createElement("option");
      option.value = arrParam[i][0];
      option.text = arrParam[i][1];
      selectElement.add(option);
    }
  }

  Set3SelectedValue(arrParam) {
    // [ [ 2, '拠点_コード', '1', 'A', 'varchar' ],
    //   [ 7, '商品名', '2', 'A', 'varchar' ],
    //   [ 8, '数量', '3', 'D', 'integer' ] ]
    let sortdata = arrParam;
    for (let i = 0; i < sortdata.length; i++) {
        let colVal = sortdata[i][0];    // 5 || 3 || 8 
        // let control1 = 'sortdrop'+ sortdata[i][2];   // sortdrop1  sortdrop2  sortdrop3
        // let control2 = 'sortAD'+ sortdata[i][2] ;  // sortAD1  sortAD2  sortAD3
        let AorD = sortdata[i][3];  // A || D
        // <option value="A">昇順</option>
        // <option value="D">降順</option>
        // if(AorD === 'A'){AorD = '1';}
        // if(AorD === 'D'){AorD = '2';}
        this.SetSelectedValue(this._sortdrop[i], colVal);
        this.SetSelectedValue(this._dropAD[i] , AorD);
    }
  }

  SetSelectedValue(selectElement, selVal) {      
    for(var i=0; i<selectElement.options.length; i++){
        if(selectElement.options[i].value === selVal.toString()){
            selectElement.options[i].selected = true;
            break;
        }
    }
  }
  
  /**
   * @description:  Get Dropdown current selected
   * @param {*} control
   * @return {*}
   */
  GetSelectChosen(selectElement) {
    // let selectElement = document.getElementById(controlId);
    // 获取选中的选项的值
    let selectedValue = selectElement.options[selectElement.selectedIndex].value;
    let selectedText = selectElement.options[selectElement.selectedIndex].text;   
    let selrow = [];
    selrow[0] = selectedValue;
    selrow[1] = selectedText;
    return selrow;
  }
  
  Get3ColChosen() {
    // ['999', '-- ソート項目 --']
    // ['3', '商品名A']
    // ['8', '数量'] 
    let sel = [];
    sel[0] = this.GetSelectChosen(this._sortdrop[0]);
    sel[1] = this.GetSelectChosen(this._sortdrop[1]);
    sel[2] = this.GetSelectChosen(this._sortdrop[2]);
    // console.log(sel);
    return sel;
  }

  Get3AdChosen() {
    // ['A', '昇順']
    // ['0', '-- 並び順 --']
    // ['D', '降順']
    let ad = [];
    ad[0] = this.GetSelectChosen(this._dropAD[0]);
    ad[1] = this.GetSelectChosen(this._dropAD[1]);
    ad[2] = this.GetSelectChosen(this._dropAD[2]);
    // console.log(ad);
    return ad;
  }


}

// DataGrid Class
class CusDataGrid {
  
  constructor(gridDivID) 
  {
    this._gridDiv = document.getElementById(gridDivID);
  }

  zeroFill(i) {
    if (i >= 0 && i <= 9) {
        return "0" + i;
    } else {
        return i;
    }
  }

  GetHHmmss(){
    let date = new Date();//CurrentTime
    let hour = this.zeroFill(date.getHours()).toString();//時
    let minute = this.zeroFill(date.getMinutes()).toString();//分
    let second = this.zeroFill(date.getSeconds()).toString();//秒
    return (hour + minute + second);
  }

  // grid 类只能对数据打包 关联外部 HTML 和按钮事件 要接入外部函数处理
  InitControls(listData, settingData) {     
    this._tbData = listData;          // Reference to const tbData(same object)
    this._tbSetting = settingData;    // Reference to const tbSetting(same object)

    //['datarow-key1', 'red']   --- Modify Copy Edit
    //['datarow-key2', 'black'] --- Delete
    this._tbRowColorSetting =[];
    //
  }

  // GetHVCols(tbSetting, 'hide') --> Get hide Data Array
  // [ [ 3, '入荷_伝票_番号', '0' ],
  //   [ 4, '発注_番号', '0' ],
  //   [ 5, '登録_日時', '0' ],
  //   [ 9, '在庫キー（文字1）', '0' ],
  //   [ 10, '在庫キー（文字2）', '0' ],
  //   [ 11, '在庫キー（文字3）', '0' ],
  //   [ 12, '在庫キー（文字4）', '0' ],
  //   [ 13, '在庫キー（文字5）', '0' ] ]

  // GetHVCols(tbSetting, 'visible') --> Get visible Data Array
  // [ [ 0, 'table_key', '0' ],
  //   [ 6, '商品コード', '10' ],
  //   [ 7, '商品名', '11' ],
  //   [ 8, '数量', '12' ],
  //   [ 1, '荷主_コード', '13' ],
  //   [ 2, '拠点_コード', '14' ] ]
  /**
   * @description: 
   * GetHVCols(tbSetting, 'hide') --> Get hide Data Array
   * GetHVCols(tbSetting, 'visible') --> Get visible Data Array
   * @param {*} arrParam
   * @param {*} hideOrVisible
   * @return {*}
   */    
  GetHVCols(hideOrVisible) {
    
    const arrParam = this._tbSetting;
    const arrV = [];
    let k=0;
    
    for (let i = 1; i < arrParam.length; i++) {

        let khv = arrParam[i][cIdx_visible];
        if(khv === 'key'){khv ='visible';}
        //hideOrVisible = hide || visible
        if (khv===hideOrVisible)
        {
            arrV[k] = [];        
            arrV[k][0] = i - 1;
            arrV[k][1] = arrParam[i][cIdx_name];
            arrV[k][2] = arrParam[i][cIdx_disporder];    
            k++;
        }        
    }

    let sortedArr = [...arrV].sort((a, b) => a[2] - b[2]);
    //console.log(sortedArr);
    return sortedArr;    
  }

  // GetSortItems(tbSetting)
  // [ [ 999, '-- ソート項目 --', '' ],
  // [ 1, '荷主_コード', '' ],
  // [ 2, '拠点_コード', '' ],
  // [ 3, '入荷_伝票_番号', '' ],
  // [ 4, '発注_番号', '' ],
  // [ 5, '登録_日時', '' ],
  // [ 6, '商品コード', '' ],
  // [ 7, '商品名', '' ],
  // [ 8, '数量', '' ],
  // [ 9, '在庫キー（文字1）', '' ],
  // [ 10, '在庫キー（文字2）', '' ],
  // [ 11, '在庫キー（文字3）', '' ],
  // [ 12, '在庫キー（文字4）', '' ],
  // [ 13, '在庫キー（文字5）', '' ] ]
  /**
   * @description: 
   *  GetSortItems(tbSetting) --> Get Sort List Items (except key)
   * @param {*} arrParam
   * @return {*}
   */  
  GetSortItems() {

    const arrParam = this._tbSetting;
    let arrS = [];    
    let k=0;

    arrS[k] = [999, '-- ソート項目 --', ''];
    k++; 
    // col01 -- col14
    for (let i = 1; i < arrParam.length; i++) {
      
      if (arrParam[i][cIdx_visible] === 'key') {continue;}
        arrS[k] = [];        
        arrS[k][0] = i - 1;
        arrS[k][1] = arrParam[i][cIdx_name];
        arrS[k][2] = '';        
        k++; 
    }
    //console.log(arrS);
    return arrS;    
  }
  
  // GetSortCols(tbSetting) --> Get Sort Data Array  
  // [ [ 2, '拠点_コード', '1', 'A', 'varchar' ],
  // [ 7, '商品名', '2', 'A', 'varchar' ],
  // [ 8, '数量', '3', 'D', 'integer' ] ]
  /**
   * @description: 
   *  GetSortCols(tbSetting) --> Get Sort Data Array
   * @param {*} arrParam
   * @return {*}
   */  
  GetSortCols() {

    const arrParam = this._tbSetting;
    let arrS = [];
    let k=0;

    for (let i = 1; i < arrParam.length; i++) {

        if (arrParam[i][cIdx_sortorder].trim().length === 0) {continue;}        
        arrS[k] = [];        
        arrS[k][0] = i - 1;
        arrS[k][1] = arrParam[i][cIdx_name];
        arrS[k][2] = arrParam[i][cIdx_sortorder];
        arrS[k][3] = arrParam[i][cIdx_sortad];
        arrS[k][4] = arrParam[i][cIdx_type]; 
        k++; 
    }

    let sortedArr = [...arrS].sort(function(a, b) {
        return a[2].localeCompare(b[2], 'ja') // 'zh' 表示中文，可以根据需要替换成其他语言编码
    });
    //console.log(sortedArr);
    return sortedArr;    
  }  

  /**
   * @description: 
   *  Delete first Row in Array -- Title
   *  Not change the original array
   * @param {*} arrParam
   * @return {*}
   */  
  DelArrayFirstRow(arrParam) {
    // slice will not change the original array
    let newArr = arrParam.slice(1); 
    return newArr;
  }

  //　arrSortSet = GetSortCols(tbSetting)
  // [ [ 5, '拠点_コード', '1', 'A', 'varchar' ],
  //   [ 3, '商品名', '2', 'D', 'varchar' ],
  //   [ 8, '数量', '3', 'D', 'integer' ] ]
  /**
   * @description: 
   *  sortMultiDimensionalArray(tbData, GetSortCols(tbSetting))  --> Sort the original data
   * @param {*} arrParam
   * @param {*} arrSortSet
   * @return {*}
   */  
  sortMultiDimensionalArray(arrParam, arrSortSet) {   
    let sortedArr = [...arrParam].sort(function(a, b) {        
      for (let i = 0; i < arrSortSet.length; i++) {
        let col = arrSortSet[i][0];
        let direction = 'asc';
        if(arrSortSet[i][3]==='A'){direction = 'asc';}
        if(arrSortSet[i][3]==='D'){direction = 'desc';}

        if (arrSortSet[i][4] === 'integer') {
            // integer sort
            if (parseFloat(a[col]) > parseFloat(b[col])) {
                return direction === 'asc' ? 1 : -1;
            } else if (parseFloat(a[col]) < parseFloat(b[col])) {
                return direction === 'asc' ? -1 : 1;
            }else{}
        } else {
            // string sort
            if (a[col] > b[col]) {
                return direction === 'asc' ? 1 : -1;
            } else if (a[col] < b[col]) {
                return direction === 'asc' ? -1 : 1;
            }else{}
        }
        
      }
      return 0;
    });

    // for (let i = 0; i < sortedArr.length; i++) {
    //   console.log(sortedArr[i][0]); // 打印每行的第一个元素
    // }
    return sortedArr;
  }

  /**
   * @description: 
   *  GetDispTable(tbData, GetHVCols(tbSetting, 'visible')) --> Get all key and visible Data Array
   * @param {*} arrParam
   * @param {*} arrOrder
   * @return {*}
   */  
  GetDispTable(arrParam, arrOrder) {    
    const vorderArr = [];
    for (let i = 0; i < arrParam.length; i++) {
      let row = [];  
      for (let j = 0; j < arrOrder.length; j++) {
        row.push(arrParam[i][arrOrder[j][0]]);
      }  
      vorderArr.push(row);
    }  
    return vorderArr;
  }
   
  /**
   * @description: 
   *  Reset Grid Data by Sort and  Visible options
   * @return {*}
   */
  ReSetGrid() {

    this._gridDiv.innerHTML = "";

    let colVisibleSetting = this.GetHVCols('visible');
    let dataWithoutFirstRow = this.DelArrayFirstRow(this._tbData);
    let sortedDataList = this.sortMultiDimensionalArray(dataWithoutFirstRow, this.GetSortCols());
    let dataListToDisplay = this.GetDispTable(sortedDataList, colVisibleSetting);
    let tableHtml = MakeTable(colVisibleSetting, dataListToDisplay); 
    
    let tbid = "myTable" + this.GetHHmmss();
    tableHtml = tableHtml.replace('[TABLE_ID]', tbid);
    
    this._gridDiv.innerHTML = tableHtml;
    
    SetGridRowClick();  // set button click event
    ReDrawGrid(tbid);   // reset 4 controls with the datagrid
  }

  
  /**
   * @description: 
   *  let visibleItems = GetSelectControl('select_list');
   *  Modify the tbSetting
   * @param {*} arrParam
   * @param {*} arrReSet
   * @return {*}
   */
  ModifyVisible(arrReSet) {

    const arrParam = this._tbSetting;
    let arrS = [];      
    let k=0;

    // Set all visible --> hide
    for (let i = 1; i < arrParam.length; i++) {    
      if (arrParam[i][cIdx_visible] === 'key') {continue;}
        arrParam[i][cIdx_visible] = 'hide';
        arrParam[i][cIdx_disporder] = '';
    }

    // ['13', '在庫キー（文字5）', '10']
    // ['2', '商品コードA', '11']
    // ['3', '商品名A', '12']
    for (let i = 0; i < arrReSet.length; i++) {        
      arrParam[parseInt(arrReSet[i][0])+1][cIdx_visible] = 'visible';
      arrParam[parseInt(arrReSet[i][0])+1][cIdx_disporder] = arrReSet[i][2];
    }
    //console.log(arrParam);
  }

  /**
   * @description: Modify tbSetting By current sort info
   * 
   * @param {*} sel3col
   * @param {*} sel3ad
   * @return {*}
   */  
  ModifySort(sel3col, sel3ad){

    const arrParam = this._tbSetting;

    //sel3col
    // ['999', '-- ソート項目 --']
    // ['3', '商品名A']
    // ['8', '数量'] 
    let sel = sel3col;
    
    //sel3ad
    // ['A', '昇順']
    // ['0', '-- 並び順 --']
    // ['D', '降順']
    let ad = sel3ad; 
    
    // Clear all Sort
    for (let i = 1; i < arrParam.length; i++) {    
      arrParam[i][cIdx_sortorder] = '';
      arrParam[i][cIdx_sortad] = '';
    }

    // Set Modified Sort
    for (let i = 0; i < 3; i++) {
      if(sel[i][0] === '999'){continue;}  // SKIP  -- ソート項目 --  
      if(ad[i][0] === '0'){continue;}     // SKIP  -- 並び順 --
      let m = i.toString() + ad[i][0];
      arrParam[parseInt(sel[i][0])+1][cIdx_sortorder] = (i+1).toString();
      arrParam[parseInt(sel[i][0])+1][cIdx_sortad] = ad[i][0];
    }
    //console.log(arrParam);
  }

  /**
   * @description: Get DataRow Index from datakey
   * @param {*} key
   * @return {*}
   */  
  GetRowIndexByKey(key) {    
    for (let i = 0; i < this._tbData.length; i++) {
        if(this._tbData[i][0]===key)
        {        
          return i;
        }
    }
    return -1;
  }

  /**
   * @description: Get One DataRow from datakey
   * @param {*} key
   * @return {*}
   */  
  GetRowDataByKey(key) {
    let rowData = [];
    for (let i = 0; i < this._tbData.length; i++) {
        if(this._tbData[i][0]===key)
        {
          rowData = this._tbData[i];
          return rowData;
        }
    }
    return rowData;
  }

  /**
   * @description:  
   *   Delete Data in Original DataArray By key -- Not Used
   *   splice will change the Original DataArray
   * @param {*} arrParam
   * @param {*} key
   * @return {*}
   */
  DeleteOneRow(arrParam, key) {
    for (let i = 0; i < arrParam.length; i++) {
        if(arrParam[i][0]===key)
        {
          arrParam.splice(i, 1); // Delete One row
          return;
        }
    }
  }
  
  /**
   * @description:  Copy one row and Append datarow to Last
   * @param {*} key
   * @return {*}
   */  
  CopyOneRowAppendLast(key) {
    const arrParam = this._tbData;
    let copyRow = [];
    for (let i = 0; i < arrParam.length; i++) {
      if(arrParam[i][0]===key)
      {
        let copyRow = [...arrParam[i]];      
        copyRow[0] = copyRow[0] + "copy";       // "key" = "keycopy"
        arrParam[arrParam.length] = copyRow;
        return;
      }
    }
  }

}

// マスタ検索リスト
class MasterSearchTable {

  constructor(gridTbID,chooseBtnID)
  {
    this._gridTableID = gridTbID;
    this._gridTable = document.getElementById(gridTbID);      
    this._chooseBtn = document.getElementById(chooseBtnID);
    this.GetSelData = this.GetSelData.bind(this); // 绑定上下文
  }

  InitControls() {      
    this._chooseBtn.addEventListener('click', this.GetSelData);
  }

  //テーブルのTRを選択後、背景色変更・矢印追加
  RenderTableSelect() {
    //const table = document.getElementById('searchDataTable');
    const table = this._gridTable;
    const rows = [...table.getElementsByTagName('tr')];
    const renderArrow = (dom) => {
      // Add selection to current row
      dom.classList.add('selected');
        
      // Add arrow to current row's first cell
      const arrow = document.createElement('div');
      arrow.classList.add('arrow');
      dom.querySelector('td:first-child').appendChild(arrow);
    }
    
    for (let i = 0; i < rows.length; i++) {
      const row = rows[i];
      row.addEventListener('click', function() {
        // Remove selection from other rows
        for (let j = 0; j < rows.length; j++) {
          rows[j].classList.remove('selected');
          rows[j].querySelector('.arrow')?.remove();
        }
        renderArrow(row)
      });
    }
    renderArrow(rows[1])
  }    

  //dtObjList
  //[{col1: '00111', col2: '商品名00111' , col3: 'NUM111'},
  // {col1: '00222', col2: '商品名00222' , col3: 'NUM222'},
  // {col1: '00333', col2: '商品名00333' , col3: 'NUM333'}]
  SetTableData(dtObjList) {
    
    this._dataList = dtObjList;  //保存为内部属性

    const renderNode = (data, index) => {
      return `
        <tr class='${index ? '' : 'selected'}'>
        <td></td>
        <td>${data.col1}</td>
        <td>${data.col2}</td>          
      </tr>`
    }

    let aa = dtObjList;
    let bb = aa.reduce((target, item, index) => {
      target += renderNode(item, index);
      return target;
    }, '');

    let qStr = "#" + this._gridTableID + " tbody"
    const tableBody = document.querySelector(qStr);
    tableBody.innerHTML = bb;
    this.RenderTableSelect();
  } 

  GetSelData(){
    const table = this._gridTable;
    const rows = [...table.getElementsByTagName('tr')];
    let rr = rows.findIndex(item => item.className === 'selected');
    const currentItem = this._dataList[rr-1];
    SetValueBack(this._gridTableID, currentItem.col1, currentItem.col2, currentItem.col3);
  }
}

///////////////////////////// JS Common Class END //////////////////////////

  
