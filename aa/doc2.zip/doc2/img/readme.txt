
https://www.freepik.com/free-photos-vectors/server-icon

https://www.webiconset.com/category/free-icons/

