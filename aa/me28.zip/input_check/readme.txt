https://jqueryvalidation.org/
https://dabohaze.site/validate-js-how-to/
