class bb {
    constructor(a, b, customFunction) {
      this._a = a;
      this._b = b;
      this._callBackFunction = customFunction;
    }
  
    doJob() {
      this.doProc();
    }
  
    doProc(){
      this._callBackFunction(this._a);
    }  
  }
  
  function fx01(data){
      console.log("This is function fx01 " + data);
  } 
  const p5 = new bb('aaa','bbb', fx01);
  p5.doJob();
  
  