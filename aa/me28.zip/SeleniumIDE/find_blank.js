/*
 * @Author: Kamikawa
 * @Date: 2023-03-02 10:43:05
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2023-03-03 17:15:14
 * @FilePath: \ct4d:\SeleniumIDE\find_blank.js
 * @Description: 
 * 
 * Copyright (c) 2023 by ${git_name_email}, All Rights Reserved. 
 */

// document.getElementByXPath = function (sValue) {
//   var a = this.evaluate(
//     sValue,
//     this,
//     null,
//     XPathResult.ORDERED_NODE_SNAPSHOT_TYPE,
//     null
//   );
//   if (a.snapshotLength > 0) {
//     return a.snapshotItem(0);
//   }
// };
// document.getElementsByXPath = function (sValue) {
//   var aResult = new Array();
//   var a = this.evaluate(
//     sValue,
//     this,
//     null,
//     XPathResult.ORDERED_NODE_SNAPSHOT_TYPE,
//     null
//   );
//   for (var i = 0; i < a.snapshotLength; i++) {
//     aResult.push(a.snapshotItem(i));
//   }
//   return aResult;
// };
// document.removeElementsByXPath = function (sValue) {
//   var a = this.evaluate(
//     sValue,
//     this,
//     null,
//     XPathResult.UNORDERED_NODE_SNAPSHOT_TYPE,
//     null
//   );
//   for (var i = 0; i < a.snapshotLength; i++) {
//     a.snapshotItem(i).parentNode.removeChild(a.snapshotItem(i));
//   }
// };

// css=tr:nth-child(2055) > td:nth-child(2) > input
// xpath=(//input[@name='txtDWorkYMD'])[2]
// xpath=//tr[3]/td[2]/input
// var elements = document.getElementsByXPath("//input[@name='txtDWorkYMD']");
// alert(elements);

// var elements = document.getElementsByName('txtDWorkYMD');
// for (let i = 0 ; i < elements.length ; i++){
//   if(elements[i].value === "")
//   {    
//     return i;
//     break;
//   }
//   else
//   {
//     alert(i + "--"+elements[i].value);
//   }
//   }
  
  function aa()
  {

    let el1 = document.getElementsByName('txtDWorkYMD');
    let el2 = document.getElementsByName('txtBusCd');
    let el3 = document.getElementsByName('txtBusSq');
    let el4 = document.getElementsByName('cmbWorkCd');
    let el5 = document.getElementsByName('txtFromHM');
    let el6 = document.getElementsByName('txtToHM');

for (let i = 0 ; i < el1.length ; i++){
  if(el1[i].value === "")
  {    
    el1[i].value = new Date().getDate().toString().padStart(2,'0');
    el2[i].value = "KMTNW0";
    el3[i].value = "01";
    el4[i].value = "- ";
    el5[i].value = "09:00";
    el6[i].value = "18:00";
    break;
  }
  }


    // let el1 = document.getElementsByName('cmbWorkCd');
    // el1[2].value = "- ";

    let dd= new Date().getDate().toString().padStart(2,'0');
    console.log(dd);

  }
  aa();


  // elements[i].value = '22';
    // alert(i);

//     xpath=(//input[@name='txtDWorkYMD'])[2]
//     01

//     xpath=(//input[@name='txtBusCd'])[2]
//     KMTNW0

//     xpath=(//input[@name='txtBusSq'])[2]
//     01

//     xpath=(//input[@name='txtFromHM'])[2]
//     09:00

// select
// css=tr:nth-child(2055) select
// label=その他


// xpath=(//input[@name='txtToHM'])[2]
// 18:00


/* <select name="cmbWorkCd"> */
				
  

// <select name="cmbWorkCd">
// 				<option value="">
// 						</option><option value="- " selected="">その他
// 						</option><option value="PM">プロジェクト管理
// 						</option><option value="SA">要件定義
// 						</option><option value="UI">ﾕｰｻﾞｰI/F設計
// 						</option><option value="SS">ｼｽﾃﾑ構造設計
// 						</option><option value="PS">ﾌﾟﾛｸﾞﾗﾑ構造設計
// 						</option><option value="PG">プログラム開発
// 						</option><option value="IT">結合テスト
// 						</option><option value="ST">システムテスト
// 						</option><option value="OQ">運用テスト
// 						</option><option value="OT">導入支援・保守
// 						</option><option value="DI">データ移行
// 				</option></select>


