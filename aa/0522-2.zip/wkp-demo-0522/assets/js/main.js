'use strict';

  /**   
  *ドロップダウンリストのオプションを動的に作成する。        
  *データベースからデータを読み込んで動的に作成することができる。        
  */
  //let response = []
  // document.addEventListener("DOMContentLoaded", function() {
  //   const addButton = document.querySelector("#add");
  //   const deleteButton = document.querySelector("#delete");
  //   const fbList = document.querySelector("#fb_list");
  //   const selectList = document.querySelector("#select_list");
    
  //   addButton.addEventListener("click", function() {
  //     const selectedOptions = fbList.querySelectorAll("option:checked");
  //     if (selectedOptions.length > 0) {
  //       selectedOptions.forEach(function(option) {
  //         const newOption = document.createElement("option");
  //         newOption.value = option.value;
  //         newOption.textContent = option.textContent;
  //         selectList.appendChild(newOption);
  //         option.remove();
  //       });
  //     }
  //   });
    
  //   deleteButton.addEventListener("click", function() {
  //     const selectedOptions = selectList.querySelectorAll("option:checked");
  //     if (selectedOptions.length > 0) {
  //       selectedOptions.forEach(function(option) {
  //         const newOption = document.createElement("option");
  //         newOption.value = option.value;
  //         newOption.textContent = option.textContent;
  //         fbList.appendChild(newOption);
  //         option.remove();
  //       });
  //     }
  //   });
  // });
  

  // document.addEventListener("DOMContentLoaded", function() {
  //   const addButton = document.querySelector("#add");
  //   const deleteButton = document.querySelector("#delete");
  //   const fbList = document.querySelector("#fb_list");
  //   const selectList = document.querySelector("#select_list");
    
  //   addButton.addEventListener("click", function() {
  //     const selectedOptions = fbList.querySelectorAll("option:checked");
  //     if (selectedOptions.length > 0) {
  //       selectedOptions.forEach(function(option) {
  //         const newOption = document.createElement("option");
  //         newOption.value = option.value;
  //         newOption.textContent = option.textContent;
  //         selectList.appendChild(newOption);
  //         option.remove();
  //       });
  //     }
  //   });
    
  //   deleteButton.addEventListener("click", function() {
  //     const selectedOptions = selectList.querySelectorAll("option:checked");
  //     if (selectedOptions.length > 0) {
  //       selectedOptions.forEach(function(option) {
  //         const newOption = document.createElement("option");
  //         newOption.value = option.value;
  //         newOption.textContent = option.textContent;
  //         fbList.appendChild(newOption);
  //         option.remove();
  //       });
  //     }
  //   });
  // });
  
  
  // const selectList = document.querySelector('#select_list');

  // document.querySelector('#add').addEventListener('click', function() {
  //   const selectedOptions = selectList.querySelectorAll('option:checked');
  //   if (selectedOptions.length > 0) {
  //     selectedOptions.forEach(function(option) {
  //       option.remove();
  //       document.querySelector('#fb_list').appendChild(option);
  //     });
  //   }
  // });
  
  // document.querySelector('#delete').addEventListener('click', function() {
  //   const selectedOptions = selectList.querySelectorAll('option:checked');
  //   if (selectedOptions.length > 0) {
  //     const optionsToAdd = [];
  //     selectedOptions.forEach(function(option) {
  //       option.remove();
  //       optionsToAdd.push(option);
  //     });
  //     optionsToAdd.forEach(function(option) {
  //       selectList.appendChild(option);
  //     });
  //   }
  // });
  
  // document.querySelector('#btnMoveUp, #btnMoveDown').addEventListener('click', function() {
  //   const selectedOption = selectList.querySelector('option:checked');
  //   if (!selectedOption) return;
  //   const options = Array.from(selectList.querySelectorAll('option'));
  //   const selectedIndex = options.indexOf(selectedOption);
  //   if (this.id === 'btnMoveUp' && selectedIndex > 0) {
  //     options[selectedIndex - 1].before(selectedOption);
  //   } else if (this.id === 'btnMoveDown' && selectedIndex < options.length - 1) {
  //     options[selectedIndex + 1].after(selectedOption);
  //   }
  // });
  
  // document.querySelector('#btnMoveUpTop, #btnMoveDownBot').addEventListener('click', function() {
  //   const selectedOption = selectList.querySelector('option:checked');
  //   if (!selectedOption) return;
  //   const options = Array.from(selectList.querySelectorAll('option'));
  //   const selectedIndex = options.indexOf(selectedOption);
  //   if (this.id === 'btnMoveUpTop' && selectedIndex > 0) {
  //     options[0].before(selectedOption);
  //   } else if (this.id === 'btnMoveDownBot' && selectedIndex < options.length - 1) {
  //     selectList.appendChild(selectedOption);
  //   }
  // });
  
  // document.addEventListener('keydown', function(evt) {
  //   if (!evt.altKey) return;
  //   const k = evt.which;
  //   if (k === 38) {
  //     document.querySelector('#btnMoveUp').click();
  //     evt.preventDefault();
  //   } else if (k === 40) {
  //     document.querySelector('#btnMoveDown').click();
  //     evt.preventDefault();
  //   }
  // });
  
  

  function toggleActiveClass(button) {
    button.classList.toggle("active");
  }
  
  function onRightHugButtonClicked() {
    const rightHugButton = document.getElementById("rightHugBtn");
    toggleActiveClass(rightHugButton);
  }
  
  function onLeftHugButtonClicked() {
    const leftHugButton = document.getElementById("leftHugBtn");
    toggleActiveClass(leftHugButton);
  }
  
  // function onWindowResized() {
  //   const delay = 500;
  
  //   let timeoutID = 0;
  //   window.addEventListener("resize", () => {
  //     clearTimeout(timeoutID);
  //     timeoutID = setTimeout(() => {
  //       const navbarNav = document.getElementById("js-navbarNav");
  //       const container = document.getElementById("container");
        
  //       if (window.matchMedia("(max-width: 992px)").matches) {
  //         navbarNav.classList.add("show");
  //       } else {
  //         navbarNav.classList.remove("show");
  //         container.classList.remove("back-blur");
  //       }
  //     }, delay);
  //   }, false);
  // }
  
  // onWindowResized();
  // const rightHugButton = document.getElementById("rightHugBtn");
  // rightHugButton.addEventListener("click", onRightHugButtonClicked);
  
  // const leftHugButton = document.getElementById("leftHugBtn");
  // leftHugButton.addEventListener("click", onLeftHugButtonClicked);
  
  
  //サイドメニュー　ドロップダウン
  
  function Accordion(el, multiple) {
    this.el = el || {};
    this.multiple = multiple || false;
  
    // Variables privadas
    var links = this.el.querySelectorAll(".link");
    // Evento
    for (var i = 0; i < links.length; i++) {
      links[i].addEventListener("click", this.dropdown.bind(this, links[i]));
    }
  }
  
  Accordion.prototype.dropdown = function (link, e) {
    var $el = this.el;
    var $this = link;
    var $next = $this.nextElementSibling;
  
    $next.classList.toggle("show");
    $this.parentElement.classList.toggle("open");
  
    if (!this.multiple) {
      var siblings = Array.from($el.querySelectorAll(".submenu")).filter(function (submenu) {
        return submenu !== $next;
      });
      siblings.forEach(function (submenu) {
        submenu.classList.remove("show");
        submenu.parentElement.classList.remove("open");
      });
    }
  };
  
  var accordion = new Accordion(document.querySelector("#accordion"), false);
  
  


/////////////////////////////　　テーブルの行をクリックしたら、背景色を変更する START //////////////////////////
// function getTable() {
//   return document.querySelector('#searchDataTable');
// }

// function renderTableSelect() {
// const table = getTable();
// const rows = [...table.getElementsByTagName('tr')];
// const renderArrow = (dom) => {
//   // Add selection to current row
//   dom.classList.add('selected');
    
//   // Add arrow to current row's first cell
//   const arrow = document.createElement('div');
//   arrow.classList.add('arrow');
//   dom.querySelector('td:first-child').appendChild(arrow);
// }

// for (let i = 0; i < rows.length; i++) {
//   const row = rows[i];
//   row.addEventListener('click', function() {
//     // Remove selection from other rows
//     for (let j = 0; j < rows.length; j++) {
//       rows[j].classList.remove('selected');
//       rows[j].querySelector('.arrow')?.remove();
//     }
//     renderArrow(row)
    
//   });
// }
// renderArrow(rows[1])
// }


/////////////////////////////　　　テーブルの行をクリックしたら、背景色を変更する END //////////////////////////


  
///////////////////////////// 　　 虫眼鏡　検索ボタンでデータ反映　START //////////////////////////
// function magnifyingGlass() {
//   const searchBtn = $('#supplierSearchBtn');
//   const label = $('label[for="searchLabelName"]');
//   const input = $('#supplierInput');
//   const result = $('#result');
//   const labelText = label.text().substring(0,3);

//   searchBtn.on('click', function() {
//     const inputValue = input.val();
//     result.text(labelText + inputValue);
//   });
// };

/////////////////////////////　　　検索ボタンでデータ反映　END //////////////////////////



// const arriveDetailBtn = document.getElementById('arriveDetailBtn');  
// arriveDetailBtn.addEventListener('click', function() { 
//     SetFormStatus(2);
// });

// const arriveSearchBtn = document.getElementById('arriveSearchBtn');
// arriveSearchBtn.addEventListener('click', function() {
//   SetFormStatus(3);
//   const renderNode = (data, index) => {
//     return `
//       <tr class='${index ? '' : 'selected'}'>
//       <td></td>
//       <td>${data.num}</td>
//       <td>${data.time}</td>
//     </tr>`
//   }
//   const mockList = [
//     {num: 'HIN000000000000111', time: '2023/04/04' , Supplier: 'AAAA'},
//     {num: 'HIN000000000000222', time: '2023/04/07' , Supplier: 'BBBB'},
//     {num: 'HIN000000000000333', time: '2023/04/08' , Supplier: 'CCCC'},
//     {num: 'HIN000000000000444', time: '2023/04/09' , Supplier: 'DDDD'},
//     {num: 'HIN000000000000555', time: '2023/05/01' , Supplier: 'EEEE'},
//     {num: 'HIN000000000000666', time: '2023/05/01' , Supplier: 'FFFF'},
//     {num: 'HIN000000000000777', time: '2023/05/02' , Supplier: 'GGGG'},
//     {num: 'HIN000000000000888', time: '2023/05/05' , Supplier: 'HHHH'},
//   ];
//   response = mockList;
//   const tableBody = document.querySelector('#arrive_search tbody');
//   tableBody.innerHTML = mockList.reduce((target, item, index) => {
//     target += renderNode(item, index);
//     return target;
//   }, '');
//   renderTableSelect();
// });

// const chooseBtn = document.getElementById('chooseBtn');
// chooseBtn.addEventListener('click', () => {
//   const table = document.querySelector('#searchDataTable');
//   const rows = [...table.getElementsByTagName('tr')];
//   const currentItem = response[rows.findIndex(item => item.className === 'selected')-1];
//   const invoiceNumberTwo = document.getElementById('purchaseOrderNumberInput');
//   //const date1 = document.getElementById('arriveDateInput');
//   const inputSupplier = document.getElementById('supplierInput');
//   invoiceNumberTwo.value = currentItem.num;
  
//   let ttt = new Date(currentItem.time);
//   ttt.setUTCHours(ttt.getUTCHours() + 9); // 将时间设置为 GMT+9
//   const dateString = ttt.toISOString().slice(0, 10);  
//   document.getElementById('arriveDateInput').value = dateString;

//   inputSupplier.value = currentItem.Supplier;
//   const arriveSearch = document.getElementById('arrive_search');
//   arriveSearch.classList.remove('show');
// });



// const supplierSearchBtn = document.getElementById('supplierSearchBtn');
// supplierSearchBtn.addEventListener('click', function() {
//   //SetFormStatus(3);
//   const renderNode = (data, index) => {
//     return `
//       <tr class='${index ? '' : 'selected'}'>
//       <td></td>
//       <td>${data.num}</td>
//       <td>${data.Supplier}</td>
//     </tr>`
//   }
//   const mockList2 = [
//     {num: 'SUP000111222333', time: '2023/04/04' , Supplier: '仕入先名称１'},
//     {num: 'SUP000111222334', time: '2023/04/07' , Supplier: '仕入先名称２'},
//     {num: 'SUP000111222335', time: '2023/04/08' , Supplier: '仕入先名称３'},
//     {num: 'SUP000111222336', time: '2023/04/09' , Supplier: '仕入先名称４'},
//     {num: 'SUP000111222337', time: '2023/05/01' , Supplier: '仕入先名称５'},
//     {num: 'SUP000111222338', time: '2023/05/01' , Supplier: '仕入先名称６'},
//     {num: 'SUP000111222339', time: '2023/05/02' , Supplier: '仕入先名称７'},
//     {num: 'SUP000111222340', time: '2023/05/05' , Supplier: '仕入先名称８'},
//     {num: 'SUP000111222341', time: '2023/05/02' , Supplier: '仕入先名称９'},
//     {num: 'SUP000111222342', time: '2023/05/05' , Supplier: '仕入先名称１０'},
//   ];
//   response = mockList2;
//   const tableBody = document.querySelector('#supplier_search tbody');
//   tableBody.innerHTML = mockList2.reduce((target, item, index) => {
//     target += renderNode(item, index);
//     return target;
//   }, '');
//   renderTableSelect();
// });





///////////////////////////// 　　 新規ボタン　END //////////////////////////


///////////////////////////// 　　 入荷伝票番号　検索ページ　前方一致、　後方一致、 部分一致、完全一致/////////////////////////
// const data = ['aaa', 'bbb', 'ccc', 'ddd', 'eee', 'fff'];

// const searchInput = document.getElementById('inputArriveMatch');
// const searchBtn = document.getElementById('selectArriveMatch');
// const resultsDiv = document.getElementById('searchResults');

// // 前方一致で検索
// searchBtn.addEventListener('click', () => {
//   const searchText = searchInput.value.toLowerCase();
//   const results = data.filter(item => item.toLowerCase().startsWith(searchText));
//   displayResults(results);
// });

// // 後方一致で検索
// searchBtn.addEventListener('click', () => {
//   const searchText = searchInput.value.toLowerCase();
//   const results = data.filter(item => item.toLowerCase().endsWith(searchText));
//   displayResults(results);
// });

// // 部分一致で検索
// searchBtn.addEventListener('click', () => {
//   const searchText = searchInput.value.toLowerCase();
//   const results = data.filter(item => item.toLowerCase().includes(searchText));
//   displayResults(results);
// });

// // 完全一致で検索
// searchBtn.addEventListener('click', () => {
//   const searchText = searchInput.value.toLowerCase();
//   const results = data.filter(item => item.toLowerCase() === searchText);
//   displayResults(results);
// });

// function displayResults(results) {
//   resultsDiv.innerHTML = '';
//   if (results.length === 0) {
//     resultsDiv.innerHTML = '<p>No results found.</p>';
//     return;
//   }
//   const ul = document.createElement('ul');
//   results.forEach(result => {
//     const li = document.createElement('li');
//     li.innerText = result;
//     ul.appendChild(li);
//   });
//   resultsDiv.appendChild(ul);
// }


// // 日時表示
  // // timerID = setInterval('clock()',1000); //0.5秒毎にclock()を実行
  // document.getElementById("view_today").innerHTML = getToday();
  // function getToday() {
  //     var now = new Date();
  //     var year = now.getFullYear();
  //     var mon = now.getMonth()+1; //１を足すこと
  //     var day = now.getDate();
  //     var you = now.getDay(); //曜日(0～6=日～土)
  
  //     //曜日の選択肢
  //     var youbi = new Array("日","月","火","水","木","金","土");
  //     //出力用
  //     var s = year + "年" + mon + "月" + day + "日(" + youbi[you] + ") ";
  //     return s;
  // }
  
  
  // document.getElementById("view_time").innerHTML = getNow();
  // function getNow() {
  //     var now = new Date();
  //     var hour = now.getHours();
  //     var min = now.getMinutes();
	//   var sec = now.getSeconds();

	// //出力用
	// var s =  hour + ":" + min + ":" + sec; 
	// return s;
  // }

