/*
 * @Author: Kamikawa
 * @Date: 2023-05-22 11:17:13
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2023-05-30 10:07:41
 * @FilePath: \JS_TEST\wkp-demo-0522\assets\js\formcheck.js
 * @Description: 
 * 
 * Copyright (c) 2023 by ${git_name_email}, All Rights Reserved. 
 */
'use strict';


// 必須項目
const inputElement = document.getElementById("purchaseOrderNumberInput");
function validateInput() {
    if (inputElement.value.trim() === '') {
        inputElement.style.backgroundColor = 'pink';
        inputElement.placeholder = '必須項目';
    } else if (inputElement.value.trim() !== ''){
        inputElement.style.backgroundColor = '';
    }
}
inputElement.addEventListener('blur', validateInput);


const arriveDateInput = document.getElementById("arriveDateInput");
function checkInput() {
    if (arriveDateInput.value.trim() === '') {
        arriveDateInput.style.backgroundColor = 'pink';
        arriveDateInput.placeholder = '必須項目';
    } else if (arriveDateInput.value.trim() !== ''){
        arriveDateInput.style.backgroundColor = '';
    }
}
arriveDateInput.addEventListener('blur', checkInput);





// 全角数字を半角数字に変換

function toHalfWidth(str) {

    return str.replace(/[０-９]/g, function (match) {
        return String.fromCharCode(match.charCodeAt(0) - 0xFEE0);
    });
}


// const supplierInput = document.getElementById('supplierInput');
// const supplierError = document.getElementById('supplierError');

// supplierInput.addEventListener('input', function (event) {
//     const value = event.target.value;
//     event.target.value = toHalfWidth(value);
//     const regex = /^\d+$/; // 数字のみの正規表現パターン

//     if (!regex.test(value)) {
//         supplierError.textContent = '数字のみ入力してください';
//         supplierError.style.color = 'red';
//     } else {        
//         supplierError.textContent  = '仕入れ ' + value;
//         supplierError.style.color = 'black';
//     }
// });

