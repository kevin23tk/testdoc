const form = document.querySelector('form');
  const usernameInput = document.getElementById('username');
  const emailInput = document.getElementById('email');
  const passwordInput = document.getElementById('password');
  const registerButton = document.getElementById('register-btn');

  registerButton.addEventListener('click', (event) => {
    event.preventDefault(); // submitイベントをキャンセル
    let errorMessage = '';

    // ユーザー名が3文字未満の場合
    if (usernameInput.value.length < 3) {
      errorMessage += 'ユーザー名は3文字以上で入力してください。\n';
    }

    // メールアドレスが正しい形式でない場合
    if (!isValidEmail(emailInput.value)) {
      errorMessage += '正しいメールアドレスを入力してください。\n';
    }

    // パスワードが8文字未満の場合
    if (passwordInput.value.length < 8) {
      errorMessage += 'パスワードは8文字以上で入力してください。\n';
    }

    // エラーメッセージがある場合は表示
    if (errorMessage) {
      alert(errorMessage);
    } else {
      form.submit(); // 登録処理を実行
    }
  });

  function isValidEmail(email) {
    // 正規表現でメールアドレスの形式を検証
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailPattern.test(email);
  }