

  /**   
  *ドロップダウンリストのオプションを動的に作成する。        
  *データベースからデータを読み込んで動的に作成することができる。        
  */
  let response = []
$(document).ready(function() {
  $("#add").click(function() {
    if ($("#fb_list option:selected").length > 0) {
      $("#fb_list option:selected").each(function() {
        $("#select_list").append("<option value='" + $(this).val() + "'>" + $(this).text() + "</option>");
        $(this).remove();
      });
    }
  });
  
  $("#delete").click(function() {
    if ($("#select_list option:selected").length > 0) {
      $("#select_list option:selected").each(function() {
        $("#fb_list").append("<option value='" + $(this).val() + "'>" + $(this).text() + "</option>");
        $(this).remove();
      });
    }
  });

  function sel() {
    var obj = document.getElementById('fb_list');
    var str = "";
    for (var i = 0; i < obj.options.length; i++) {
      if (str.length > 0) str = str + "," + obj.options[i].value;
      else str = obj.options[i].value;
    }
    alert(str);
  }
  
  $("#btnMoveUp, #btnMoveDown").click(function() {
    var $opt = $("#select_list option:selected:first");
    if (!$opt.length) return;
    if (this.id == "btnMoveUp") $opt.prev().before($opt);
    else $opt.next().after($opt);
  });
  
  $("#btnMoveUpTop, #btnMoveDownBot").click(function() {
    var $opt = $("#select_list option:selected:first");
    if (!$opt.length) return;
    if (this.id == "btnMoveUpTop") $("#select_list option:nth-child(2)").prev().before($opt);
    else $opt.appendTo("#select_list");
  });

  $("#select_list").keydown(function(evt) {
    if (!evt.altKey) return;
    var k = evt.which;
    if (k == 38) {
      $("#btnMoveUp").click();
      return false;
    } else if (k == 40) {
      $("#btnMoveDown").click();
      return false;
    }
  });
  
});


//　右上のハンバーガーメニュー
const rightHugButton = document.getElementById("rightHugBtn");
const contContainer = document.getElementById("container");
  rightHugButton.addEventListener("click", function() {
    if (this.classList.contains("active")) {
      this.classList.remove("active");
      } else {
      this.classList.add("active");
      }
  });
//    contContainer.toggleClass('back-blur');

 //　左上のハンバーガーメニュー 
 const leftHugButton = document.getElementById("leftHugBtn");
leftHugButton.addEventListener("click", function() {
    //ボタンがクリックされたら
    if (this.classList.contains("active")) {
      this.classList.remove("active");
      } else {
      this.classList.add("active");
      }
  });
 

  
  //画面リサイズの後サイドバーメニューの表示設置
  
  const resize = ()=>{
   
    let timeoutID = 0;
    let delay = 500;
  
    window.addEventListener("resize", ()=>{
        clearTimeout(timeoutID);
        timeoutID = setTimeout(()=>{
  
            //ここにリサイズした後に実行したい処理を記述
        if (window.matchMedia('(max-width: 992px)').matches) {
        // $('#js-navbarNav').addClass('show');
        // } else {
        $('#js-navbarNav').removeClass('show');
        $('#container').removeClass('back-blur');
        }
  
        }, delay);
    }, false);
  };
  resize();
  
  
  
  //サイドメニュー　ドロップダウン
  
  $(function () {
    var Accordion = function (el, multiple) {
      this.el = el || {};
      this.multiple = multiple || false;
  
      // Variables privadas
      var links = this.el.find(".link");
      // Evento
      links.on("click", { el: this.el, multiple: this.multiple }, this.dropdown);
    };
  
    Accordion.prototype.dropdown = function (e) {
      var $el = e.data.el;
      ($this = $(this)), ($next = $this.next());
  
      $next.slideToggle();
      $this.parent().toggleClass("open");
  
      if (!e.data.multiple) {
        $el.find(".submenu").not($next).slideUp().parent().removeClass("open");
      }
    };
  
    var accordion = new Accordion($("#accordion"), false);
  });
  


/////////////////////////////　　テーブルの行をクリックしたら、背景色を変更する START //////////////////////////
function getTable() {
  return document.querySelector('#searchDataTable');
}

function renderTableSelect() {
const table = getTable();
const rows = [...table.getElementsByTagName('tr')];

const renderArrow = (dom) => {
  // Add selection to current row
  dom.classList.add('selected');
    
  // Add arrow to current row's first cell
  const arrow = document.createElement('div');
  arrow.classList.add('arrow');
  dom.querySelector('td:first-child').appendChild(arrow);
}

for (let i = 0; i < rows.length; i++) {
  const row = rows[i];
  row.addEventListener('click', function() {
    // Remove selection from other rows
    for (let j = 0; j < rows.length; j++) {
      rows[j].classList.remove('selected');
      rows[j].querySelector('.arrow')?.remove();
    }
    renderArrow(row)
    
  });
}
renderArrow(rows[1])
}


/////////////////////////////　　　テーブルの行をクリックしたら、背景色を変更する END //////////////////////////


  
///////////////////////////// 　　 初期化設定　START //////////////////////////

// function disableAllInputsExcept() {
// const targetInputs = document.querySelectorAll('#inputOrderNumber,#inputSupplier,#date');
// targetInputs.forEach(function(input) {
//     input.disabled = true;
// });

// }

///////////////////////////// 　　 初期化設定　END //////////////////////////


///////////////////////////// 　　 検索ボタンでデータ反映　START //////////////////////////
const searchBtn = document.getElementById('searchSupplierBtn');
const label = document.querySelector('label[for="searchLabelName"]');
const input = document.getElementById('inputSupplier');
const result = document.getElementById('result');    
const labelText = label.textContent.substring(0,3);

searchBtn.addEventListener('click', function () {
      const inputValue = input.value;
      result.textContent = labelText + inputValue;
});

/////////////////////////////　　　検索ボタンでデータ反映　END //////////////////////////



///////////////////////////// 　　 新規ボタン　START //////////////////////////

const arriveDetailBtn = document.getElementById('arrive_detail_btn');
arriveDetailBtn.addEventListener("click", function() {
  const invoiceNumbers= document.getElementById('invoice-number');
  const invoiceNumber = $(invoiceNumbers)[0].value;
  if(invoiceNumber === 'A0001' ){
    // let arriveDetail = document.getElementById('arrive_detail');
    $('#arrive_detail').modal('hide'); 
     alert("入荷伝票番号あり");
     return;
    }else {    
    $('#arrive_detail').modal('show');
      
    }
})

$('#arrive_search_btn').click(function() {

  const renderNode = (data, index) => {
    return `
      <tr class='${index ? '' : 'selected'}'>
      <td></td>
      <td>${data.num}</td>
      <td>${data.time}</td>
    </tr>`
  }
  const mockList = [
    {num: 'HIN000000000000111', time: '2023/04/04' , Supplier: 'AAAA'},
    {num: 'HIN000000000000222', time: '2023/04/07' , Supplier: 'BBBB'},
    {num: 'HIN000000000000333', time: '2023/04/08' , Supplier: 'CCCC'},
    {num: 'HIN000000000000444', time: '2023/04/09' , Supplier: 'DDDD'},
    {num: 'HIN000000000000555', time: '2023/05/01' , Supplier: 'EEEE'},
    {num: 'HIN000000000000666', time: '2023/05/01' , Supplier: 'FFFF'},
    {num: 'HIN000000000000777', time: '2023/05/02' , Supplier: 'GGGG'},
    {num: 'HIN000000000000888', time: '2023/05/05' , Supplier: 'HHHH'},
    ]
  response = mockList
  $('#arrive_search tbody')[0].innerHTML = mockList.reduce((target, item, index) => {
    target += renderNode(item, index);
    return target;
  }, '')
  renderTableSelect();
})

// $('#modalSaveButton').click(() => {
//   $('#arrive_detail').modal('hide');
// })

$('#chooseBtn').click(() => {
  const table = document.querySelector('#searchDataTable');
  const rows = [...table.getElementsByTagName('tr')];
  const currentItem = response[rows.findIndex(item => item.className === 'selected')-1];
  // console.log(currentItem);
  $('#nvoice-number-two')[0].value = currentItem.num;
  $('#date')[0].value = currentItem.time;
  $('#inputSupplier')[0].value = currentItem.Supplier;

  $('#arrive_search').modal('hide');
}) ;

///////////////////////////// 　　 新規ボタン　END //////////////////////////

  // // 日時表示
  // // timerID = setInterval('clock()',1000); //0.5秒毎にclock()を実行
  // document.getElementById("view_today").innerHTML = getToday();
  // function getToday() {
  //     var now = new Date();
  //     var year = now.getFullYear();
  //     var mon = now.getMonth()+1; //１を足すこと
  //     var day = now.getDate();
  //     var you = now.getDay(); //曜日(0～6=日～土)
  
  //     //曜日の選択肢
  //     var youbi = new Array("日","月","火","水","木","金","土");
  //     //出力用
  //     var s = year + "年" + mon + "月" + day + "日(" + youbi[you] + ") ";
  //     return s;
  // }
  
  
  // document.getElementById("view_time").innerHTML = getNow();
  // function getNow() {
  //     var now = new Date();
  //     var hour = now.getHours();
  //     var min = now.getMinutes();
	//   var sec = now.getSeconds();

	// //出力用
	// var s =  hour + ":" + min + ":" + sec; 
	// return s;
  // }


