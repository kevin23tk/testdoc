/*
 * @Author: Kamikawa
 * @Date: 2023-03-16 16:27:54
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2023-06-13 15:26:12
 * @FilePath: \JS_TEST\wkp-demo-0522\comclient2.js
 * @Description: 
 * 
 * Copyright (c) 2023 by ${git_name_email}, All Rights Reserved. 
 */


/**
 * Json 定義
 * { 
 *   "datetime": "2023-02-20 11:28:01", 
 *   "loginid": "L001", 
 *   "devid": "D001", 
 *   "tkid": "T001", 
 *   "snid": "S001", 
 *   "model": "A001", 
 *   "lang": "ja-jp", 
 *   "option": "showheaders|showrequest",
 *   "dl1max": "1",
 *   "dl2max": "",
 *   "dl3max": "",
 *   "dl1": [ 
 *      { "c": [ "name","gender","age"] }, 
 *      { "c": [ "EEEE", "mmmm", "35"] } 
 *          ],
 *   "dl2": [],
 *   "dl3": []
 * } 
 */
class jdatain {
    constructor(datetime, loginid, devid, tkid, snid, module, lang, option) {
        this.datetime = datetime;
        this.loginid = loginid;
        this.devid = devid;
        this.tkid = tkid;
        this.snid = snid;
        this.module = module;
        this.lang = lang;
        this.option = option;
        this.dl1max = "";
        this.dl2max = "";
        this.dl3max = "";
        this.dl1 = [];
        this.dl2 = [];
        this.dl3 = [];
    }
    setdataList(id, value) {
        if (id === 1) { this.dl1 = value; }
        if (id === 2) { this.dl2 = value; }
        if (id === 3) { this.dl3 = value; }        
    }
    getdataList(id) {
        if (id === 1) { return this.dl1; }
        if (id === 2) { return this.dl2; }
        if (id === 3) { return this.dl3; }
    }

    setlistMax(id, value) {
        if (id === 1) { this.dl1max = value; }
        if (id === 2) { this.dl2max = value; }
        if (id === 3) { this.dl3max = value; }
    }
    getlistMax(id) {
        if (id === 1) { return this.dl1max; }
        if (id === 2) { return this.dl2max; }
        if (id === 3) { return this.dl3max; }
    }
}

/**
 * Json 定義 dl 部分
 * *  "dl": [ 
 *      { "c": [ "name","gender","age"] }, 
 *      { "c": [ "EEEE", "mmmm", "35"] } 
 *  ] 
 * } 
 */
class jdatainrow {
    constructor() {
        this.c = [];
    }
    set dataRow(value) {
        this.c = value;
    }
    get dataRow() {
        return this.c;
    }
}

/**
 * @description: Client POST Class for Communication
 * @return {*}
 */
class ClientPost {

    constructor(modUrl, modName, callBack) {
        this._modUrl = modUrl;
        this._modName = modName;
        this._callBackFunction = callBack;
    }

    // CurrentTime ：yyyy-MM-dd HH:MM:SS
    GetyyyyMMddHHmmss(){
        const currentDate = new Date();
        const year = currentDate.getFullYear();
        const month = String(currentDate.getMonth()).padStart(2, '0');
        const day = String(currentDate.getDate()).padStart(2, '0');

        const hour = String(date.getHours()).padStart(2, '0');//時
        const minute = String(date.getMinutes()).padStart(2, '0');//分
        const second = String(date.getSeconds()).padStart(2, '0');//秒
        return (year + "-" + month + "-" + day + " " + hour + ":" + minute + ":" + second);
    }

    // sModule use Blank
    InitDataClass(sLoginid, sDevid, sTkid, sSnid, sModule, sLang, sOption) {
        if (sLang == '') { sLang = 'ja-jp'; }
        // datetime, loginid, devid, tkid, snid, model, lang, option
        this._jobj = new jdatain(this.GetyyyyMMddHHmmss(), sLoginid, sDevid, sTkid, sSnid, this._modName, sLang, sOption);
    }

    //* Map data convert to jdatainrow
    //* Set dl1 -- only one row data for pass condition or property
    //* dl1max = '1'
    SetParamTable1(argMap){
        // let keys = keys = [...sdata.keys()];
        // let vals = [...sdata.values()];
        let keys = Array.from(argMap.keys());
        let vals = Array.from(argMap.values());

        let mylist = [];
        mylist[0] = new jdatainrow();
        mylist[1] = new jdatainrow();
        //console.log(keys.length);
        for (let i = 0; i < keys.length; i++) {
            mylist[0].c[i] = keys[i];
            mylist[1].c[i] = vals[i];
        }
        this._jobj.setdataList(1, mylist);
        this._jobj.setlistMax(1, "1");
    }

    SetParamTable2(argArr){
        let mylist = [];
        for (let i = 0; i < argArr.length; i++) {
            mylist[i] = new jdatainrow();
            mylist[i].c = argArr[i];            
        }
        let rMax = argArr.length - 1;
        this._jobj.setdataList(2, mylist);
        this._jobj.setlistMax(2, rMax.toString());
    }

    SetParamTable3(argArr){
        let mylist = [];
        for (let i = 0; i < argArr.length; i++) {
            mylist[i] = new jdatainrow();
            mylist[i].c = argArr[i];            
        }
        let rMax = argArr.length - 1;
        this._jobj.setdataList(3, mylist);
        this._jobj.setlistMax(3, rMax.toString());
    }

    DoPost(){
        alert(JSON.stringify(this._jobj));
        //Call axios post
        this.AxiosPost(this._modUrl, this._jobj);
    }

    
    /**
     * @description: Call POST
     * @param {*} fName
     * @param {*} sUrl
     * @param {*} jClsData
     * @return {*}
     */
    AxiosPost(sUrl, jClsData) {
    
        axios({
            method: 'post',
            url: sUrl,  //'./GetPostTest/TestPost2',
            data: JSON.stringify(jClsData),
            //timeout: 0
        })
            .then(function (response) {
                //console.log(response);
                
                //let jsonStr = JSON.stringify(response.data);
                //console.log(JSON.stringify(response.data, null, 4));
                //jsonStr = jsonStr.replace(/\\"/g, '"');
                //GetPostResponse(fName, jsonStr);

                this._callBackFunction(response.data);
                //GetPostResponse(fName, response.data);
            })
            .catch(function (error) {
                if (error.response) {
                    // The request was made and the server responded with a status code
                    // that falls out of the range of 2xx
                    console.log(error.response.data);
                    console.log(error.response.status);
                    console.log(error.response.statusText);
                    //console.log(error.response.headers);
                    console.log(JSON.stringify(error.response.headers, null, 4));
                } else if (error.request) {
                    // The request was made but no response was received
                    // `error.request` is an instance of XMLHttpRequest in the browser and an instance of
                    // http.ClientRequest in node.js
                    console.log(error.request);
                } else {
                    // Something happened in setting up the request that triggered an Error
                    console.log('Error', error.message);
                }
                //console.log(error.config);
            })
            .finally(function () {
                // always executed
            });
    }
}





function DoP005(){
    const post5 = new ClientPost('./WkpGetPost/DoPost','NkYoteiDataSearch', P005After);
    
    let sdata = new Map();
    sdata.set('syscode', 'sys01');
    sdata.set('cuscode', 'cus01');
    sdata.set('logistics', 'log01');
    sdata.set('slipno', 'slipno2');
    sdata.set('programid', 'yotei1');

    post5.InitDataClass("L001", "D001", "T001", "S001", "", "ja-jp", "");
    post5.SetParamTable1(sdata);
    post5.DoPost();
}

function P005After(rData) {

    let jsonStr = JSON.stringify(rData);
    jsonStr = jsonStr.replace(/\\"/g, '"');

    let output = document.getElementById('msg');
    output.innerHTML = jsonStr;

    let debugStr = rData.msgd;
    debugStr = debugStr.replace(/\\"/g, '"');
    if (debugStr != "" && debugStr != null && debugStr != undefined) {
        document.getElementById('debug_msg').value = debugStr;
        rData.msgd = "Show below";
    }

    document.getElementById('rejson').value = JSON.stringify(rData, null, 4);
}


//public class JobjOut {
//    public string datetime = "";
//    public string code = "";
//    public string msg = "";
//    public string msgd = "";        // debug + Exception Msg
//    public string lang = "";
//    public string dl1max = "";
//    public string dl2max = "";
//    public string dl3max = "";
//    public string dl4max = "";
//    public string dl5max = "";
//    public Data_dl[] dl1 = new Data_dl[0];
//    public Data_dl[] dl2 = new Data_dl[0];
//    public Data_dl[] dl3 = new Data_dl[0];
//    public Data_dl[] dl4 = new Data_dl[0];
//    public Data_dl[] dl5 = new Data_dl[0];
//}
//public class Data_dl {
//    public string[] c;
//}

/**
 * @description: Get Response Data
 * @param {*} response.data.dl1......dl5
 * @return {*}
 */
function GetRespArrData(responsedata) {

    //responsedata = response.data.dln  n=1-5
    //let r = responsedata.length;
    //let c = responsedata[0].c.length;

    let arrC = new Array();
    for (let i = 0; i < responsedata.length; i++) {

        arrC[i] = new Array();

        for (let j = 0; j < responsedata[i].c.length; j++) {
            arrC[i][j] = responsedata[i].c[j];
        }
    }
    return arrC;
}



// const testReJsonData = '{"datetime":"20230613145152","code":"0","msg":"","msgd":"","lang":"ja-jp","dl1max":"2","dl2max":"36","dl3max":"","dl4max":"","dl5max":"","dl1":[{"c":["tb_key","arrival_slip_header_key","arrival_slip_detail_key","arrival_slip_detail_stockkey_key","order_no","supplier_code","arrival_plan_date","item_code_1","arrival_plan_quantity_piece","allocate_kinds","recipt_pay_division","work_division","management_department","packing_quantity","arrival_unit_price","remarks","t_asds_stock_key_character_1","t_asds_stock_key_character_2","t_asds_stock_key_character_3","t_asds_stock_key_character_4","t_asds_stock_key_character_5","t_asds_stock_key_character_6","t_asds_stock_key_date_1","t_asds_stock_key_date_2","t_asds_stock_key_number_1","t_asds_stock_key_number_2","item_name_1","quantity_per_pallet","quantity_per_pack","quantity_per_case","quantity_per_carton","weight_piece","parameter_setting_1","parameter_setting_2","parameter_setting_3","parameter_setting_4"]},{"c":["ash_key2#asd_key3#asds_key2","ash_key2","asd_key3","asds_key2","order2","sup01","2023/04/20 0:00:00","item1","100.000","01","01","01","01","3","100.00","備考３","A","B","","","","","2023/05/01 0:00:00","","2.000","2.000","商品名称１","1","1","1","1","1.000","A部門","受払区分A","引当種別A","作業区分A"]},{"c":["ash_key2#asd_key4#","ash_key2","asd_key4","","order2","sup01","2023/04/20 0:00:00","item2","100.000","01","01","01","01","3","100.00","備考４","","","","","","","","","","","商品名称２","2","2","2","2","2.000","A部門","受払区分A","引当種別A","作業区分A"]}],"dl2":[{"c":["rkey","list_column_pg_name","list_column_display_name","data_type","digits","display_kinds","display_order","sort_order","asc_desc"]},{"c":["sys01#cus01#yotei1","tb_key","table_key","varchar","100","key","0","",""]},{"c":["sys01#cus01#yotei1","arrival_slip_header_key","header_key","varchar","15","key","0","",""]},{"c":["sys01#cus01#yotei1","arrival_slip_detail_key","detail_key","varchar","15","key","0","",""]},{"c":["sys01#cus01#yotei1","arrival_slip_detail_stockkey_key","detail_stockkey_key","varchar","15","key","0","",""]},{"c":["sys01#cus01#yotei1","order_no","発注_番号","varchar","25","visible","10","",""]},{"c":["sys01#cus01#yotei1","supplier_code","仕入先_コード","varchar","12","visible","11","1","A"]},{"c":["sys01#cus01#yotei1","arrival_plan_date","入荷_予定_日付","Date","20","visible","12","",""]},{"c":["sys01#cus01#yotei1","item_code_1","商品_コード_1","varchar","25","visible","13","2","A"]},{"c":["sys01#cus01#yotei1","arrival_plan_quantity_piece","入荷_予定_数量_バラ","numeric","16","visible","14","3","D"]},{"c":["sys01#cus01#yotei1","allocate_kinds","引当_種別","varchar","40","visible","15","",""]},{"c":["sys01#cus01#yotei1","recipt_pay_division","受払_区分","varchar","40","visible","16","",""]},{"c":["sys01#cus01#yotei1","work_division","作業_区分","varchar","40","visible","17","",""]},{"c":["sys01#cus01#yotei1","management_departm","管理_部門","varchar","40","visible","18","",""]},{"c":["sys01#cus01#yotei1","packing_quantity","荷姿_数量","numeric","9","visible","19","",""]},{"c":["sys01#cus01#yotei1","arrival_unit_price","入荷_単価","numeric","13","visible","20","",""]},{"c":["sys01#cus01#yotei1","remarks","備考","varchar","100","hide","0","",""]},{"c":["sys01#cus01#yotei1","t_asds_stock_key_character_1","在庫_キー_文字列_1","varchar","25","hide","0","",""]},{"c":["sys01#cus01#yotei1","t_asds_stock_key_character_2","在庫_キー_文字列_2","varchar","25","hide","0","",""]},{"c":["sys01#cus01#yotei1","t_asds_stock_key_character_3","在庫_キー_文字列_3","varchar","25","hide","0","",""]},{"c":["sys01#cus01#yotei1","t_asds_stock_key_character_4","在庫_キー_文字列_4","varchar","25","hide","0","",""]},{"c":["sys01#cus01#yotei1","t_asds_stock_key_character_5","在庫_キー_文字列_5","varchar","25","hide","0","",""]},{"c":["sys01#cus01#yotei1","t_asds_stock_key_character_6","在庫_キー_文字列_6","varchar","25","hide","0","",""]},{"c":["sys01#cus01#yotei1","t_asds_stock_key_date_1","在庫_キー_数値_1","Date","20","hide","0","",""]},{"c":["sys01#cus01#yotei1","t_asds_stock_key_date_2","在庫_キー_数値_2","Date","20","hide","0","",""]},{"c":["sys01#cus01#yotei1","t_asds_stock_key_number_1","在庫_キー_日付_1","numeric","15","hide","0","",""]},{"c":["sys01#cus01#yotei1","t_asds_stock_key_number_2","在庫_キー_日付_2","numeric","15","hide","0","",""]},{"c":["sys01#cus01#yotei1","item_name_1","商品_名称_1","varchar","100","hide","0","",""]},{"c":["sys01#cus01#yotei1","quantity_per_pallet","入り数_パレット","numeric","9","hide","0","",""]},{"c":["sys01#cus01#yotei1","quantity_per_pack","入り数_梱","numeric","9","hide","0","",""]},{"c":["sys01#cus01#yotei1","quantity_per_case","入り数_ケース","numeric","9","hide","0","",""]},{"c":["sys01#cus01#yotei1","quantity_per_carton","入り数_ボール","numeric","9","hide","0","",""]},{"c":["sys01#cus01#yotei1","weight_piece","重量_バラ","numeric","14","hide","0","",""]},{"c":["sys01#cus01#yotei1","parameter_setting_1","パラメータ_設定値1","varchar","40","hide","0","",""]},{"c":["sys01#cus01#yotei1","parameter_setting_2","パラメータ_設定値2","varchar","40","hide","0","",""]},{"c":["sys01#cus01#yotei1","parameter_setting_3","パラメータ_設定値3","varchar","40","hide","0","",""]},{"c":["sys01#cus01#yotei1","parameter_setting_4","パラメータ_設定値4","varchar","40","hide","0","",""]}],"dl3":[],"dl4":[],"dl5":[]}';
// const obj1 = JSON.parse(testReJsonData);
// //console.log(obj1);

// let dl1Data = [];
// dl1Data = GetRespArrData(obj1.dl1);
// console.log(dl1Data);
