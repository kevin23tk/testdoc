/*
 * @Author: kevin
 * @Date: 2023-06-13 10:49:26
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2023-06-22 16:26:54
 * @FilePath: \template_style.js
 * @Description: 
 * 
 * Copyright (c) 2023 by ${git_name_email}, All Rights Reserved. 
 */

//Head set

//Menu bar set
// 获取目标 <div> 元素的引用
const MenuHtmlDiv = `<ul id="accordion" class="accordion overflow-90 ps-4">
<li id="sidemenu1">
  <div class="link text-start">
    <i class="bi bi-receipt"></i><span class="mx-4">001 検査申込　　　</span>
  </div>
  <ul class="submenu">
    <li><a href="useriinput.html">101 ユーザー情報登録</a></li>
    <li><a href="apply.html">102 ユーザー検査申込</a></li>
    <li><a href="result1.html">103 検査結果検索</a></li>
    <li><a href="#">104 請求書発行</a></li>
    <li><a href="#">105 入金確認</a></li>
  </ul>
</li>
<li id="sidemenu2">
  <div class="link">
    <i class="bi bi-incognito"></i><span class="mx-4">002 検査予防情報</span>
  </div>
  <ul class="submenu">
    <li><a href="#">201 MCBI検査について</a></li>
    <li><a href="#">202 専門家のコメント動画</a></li>
    <li><a href="#">203 脳トレコンテンツ</a></li>
  </ul>
</li>
<li id="sidemenu3">
  <div class="link">
    <i class="bi bi-building"></i><span class="mx-4">003 医療機関管理</span>
  </div>
  <ul class="submenu">
    <li><a href="#">301 医療機関マスタ管理</a></li>
    <li><a href="#">302 検査会社マスタ管理</a></li>
    <li><a href="#">303 検査予約情報</a></li>
  </ul>
</li>
<li id="sidemenu4">
  <div class="link">
    <i class="bi bi-gear-fill"></i><span class="mx-4">004 各データ導入</span>
  </div>
  <ul class="submenu">
    <li><a href="#">401 APOE CSVデータ</a></li>
    <li><a href="#">402 MCI CSVデータ</a></li>
    <li><a href="#">403 DBS CSVデータ</a></li>
    <li><a href="#">404 Salesforce データ</a></li>
  </ul>
</li>
<li id="sidemenu5">
  <div class="link">
    <i class="bi bi-receipt"></i><span class="ms-4">005 各種レポート</span></div>
    <ul class="submenu">
      <li><a href="#">501 各種レポート</a></li>
    </ul>
</li>
<li id="sidemenu6">
    <div class="link">
      <i class="bi bi-flag-fill"></i><span class="ms-4">006 診断支援・海外向け</span></div>
      <ul class="submenu">
        <li><a href="#">601 診断支援・海外向け</a></li>
      </ul>
 </li>
</ul>`;
document.getElementById('js-navbarNav').innerHTML = MenuHtmlDiv;




 
$(".openbtn4").click(function () {
  $(this).toggleClass("active");
  $('#container').toggleClass('back-blur');
});

$(".openbtn1").click(function () {
  //ボタンがクリックされたら
  $(this).toggleClass("active"); //ボタン自身に activeクラスを付与し
});



//画面リサイズの後サイドバーメニューの表示設置

const resize = ()=>{
 
  let timeoutID = 0;
  let delay = 500;

  window.addEventListener("resize", ()=>{
      clearTimeout(timeoutID);
      timeoutID = setTimeout(()=>{

          //ここにリサイズした後に実行したい処理を記述
          $(function () {
            if (window.matchMedia('(min-width: 992px)').matches) {
              $('#js-navbarNav').addClass("show");
            }
            else{
              $('#js-navbarNav').removeClass("show");
              $('#container').removeClass('back-blur');
            }   
          });
          console.log("resize");

      }, delay);
  }, false);
};
resize();

//sidebar dropdown js

$(function () {
  var Accordion = function (el, multiple) {
    this.el = el || {};
    this.multiple = multiple || false;

    // Variables privadas
    var links = this.el.find(".link");
    // Evento
    links.on("click", { el: this.el, multiple: this.multiple }, this.dropdown);
  };

  Accordion.prototype.dropdown = function (e) {
    var $el = e.data.el;
    ($this = $(this)), ($next = $this.next());

    $next.slideToggle();
    $this.parent().toggleClass("open");

    if (!e.data.multiple) {
      $el.find(".submenu").not($next).slideUp().parent().removeClass("open");
    }
  };

  var accordion = new Accordion($("#accordion"), false);
});