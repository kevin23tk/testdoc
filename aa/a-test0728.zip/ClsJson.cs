﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using static System.Net.WebRequestMethods;
using System.Windows.Forms;
using System.Data;
using System.Collections;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace Asist
{
    public class ClsJson
    {


        //http://surferonwww.info/BlogEngine/post/2021/02/08/parse-jsonelement-object-deserialized-by-deserialize-method-in-system-text-json.aspx

        /// <summary>
        /// Enumerate JsonElement Object 
        /// 
        /// </summary>
        /// <param name="padding"></param>
        /// <param name="jelem"></param>
        public void Parse(int padding, JsonElement jelem)
        {
            //useage:
            //using (StreamReader r = new StreamReader(@"C:\Users\mtnadmin\Desktop\mydoc\BookMark1\MyBookMark\Bookmarks_mi.txt"))
            //{
            //    string json = r.ReadToEnd();

            //    var jelem = JsonSerializer.Deserialize<JsonElement>(json);
            //    Parse(0, jelem);
            //}


            // JsonElement.ValueKind プロパティを使って JsonValueKind 列挙型
            // のどれに該当するかを調べて処理を分ける
            if (jelem.ValueKind == JsonValueKind.False ||
                jelem.ValueKind == JsonValueKind.Null ||
                jelem.ValueKind == JsonValueKind.Number ||
                jelem.ValueKind == JsonValueKind.String ||
                jelem.ValueKind == JsonValueKind.True)
            {
                string str = $"value = {jelem}";
                Console.WriteLine(str.PadLeft(str.Length + padding));
            }
            else if (jelem.ValueKind == JsonValueKind.Object)
            {
                // Object の場合は EnumerateObject() で列挙子を取得し、以下の
                // ように foreach ループで JsonProperty を取得できる。
                // JsonProperty というのは単一の {"name":"value"} オブジェクト
                // と思えばよさそう
                foreach (JsonProperty jprop in jelem.EnumerateObject())
                {
                    if (jprop.Value.ValueKind == JsonValueKind.False ||
                        jprop.Value.ValueKind == JsonValueKind.Null ||
                        jprop.Value.ValueKind == JsonValueKind.Number ||
                        jprop.Value.ValueKind == JsonValueKind.String ||
                        jprop.Value.ValueKind == JsonValueKind.True)
                    {
                        string str = $"name = {jprop.Name}, value = {jprop.Value}";
                        Console.WriteLine(str.PadLeft(str.Length + padding));
                    }
                    else if (jprop.Value.ValueKind == JsonValueKind.Object)
                    {
                        string str = $"name = {jprop.Name}";
                        Console.WriteLine(str.PadLeft(str.Length + padding));
                        Parse(padding + 2, jprop.Value);
                    }
                    else if (jprop.Value.ValueKind == JsonValueKind.Array)
                    {
                        string str = $"name = {jprop.Name}";
                        Console.WriteLine(str.PadLeft(str.Length + padding));
                        int index = 1;
                        // Array の場合は EnumerateArray() で列挙子を取得し、以下のよう
                        // に foreach ループで配列内の各要素 (JsonElement) を取得できる
                        foreach (JsonElement jelemInArray in jprop.Value.EnumerateArray())
                        {
                            string idx = $"array index {index}";
                            Console.WriteLine(idx.PadLeft(idx.Length + padding + 1));
                            Parse(padding + 2, jelemInArray);
                            index++;
                        }
                    }
                    else
                    {
                        // JsonValueKind.Undefined 以外はここに来ない（はず）
                        Console.WriteLine(jelem.ToString());
                    }
                }
            }
            else if (jelem.ValueKind == JsonValueKind.Array)
            {
                int index = 1;
                // Array の場合 EnumerateArray() で列挙子を取得し、以下のよう
                // に foreach ループで配列内の各要素 (JsonElement) を取得できる
                foreach (JsonElement jelemInArray in jelem.EnumerateArray())
                {
                    string idx = $"array index {index}";
                    Console.WriteLine(idx.PadLeft(idx.Length + padding + 1));
                    Parse(padding + 2, jelemInArray);
                    index++;
                }
            }
            else
            {
                // JsonValueKind.Undefined 以外はここに来ない（はず）
                Console.WriteLine(jelem.ToString());
            }
        }

        //Input Json File

        //C:\Users\mtnadmin\Desktop\mydoc\BookMark1\MyBookMark\Bookmarks_mi.txt

        //{
        //   "checksum": "fb61b4009ca6e5c0b925c03e39e0562a",
        //   "roots": {
        //      "bookmark_bar": {
        //         "children": [ {
        //            "date_added": "13320138127313403",
        //            "date_last_used": "13320726260433248",
        //            "guid": "7e4f206d-4961-48ce-9c48-0bd05fe9d3f8",
        //            "id": "5",
        //            "meta_info": {
        //               "power_bookmark_meta": ""
        //            },
        //            "name": "翻訳 英語 - Google 検索",
        //            "type": "url",
        //            "url": "https://www.google.com/search?q=%E7%BF%BB%E8%A8%B3+%E8%8B%B1%E8%AA%9E&ei=gpvgY9O4LJqlhwOGqaCYAw&oq=&gs_lcp=Cgxnd3Mtd2l6LXNlcnAQAxgEMhYIABDqAhC0AhCKAxC3AxDUAxDlAhgBMhYIABDqAhC0AhCKAxC3AxDUAxDlAhgBMhYIABDqAhC0AhCKAxC3AxDUAxDlAhgBMhYIABDqAhC0AhCKAxC3AxDUAxDlAhgBMhYIABDqAhC0AhCKAxC3AxDUAxDlAhgBMhYIABDqAhC0AhCKAxC3AxDUAxDlAhgBMhYIABDqAhC0AhCKAxC3AxDUAxDlAhgBMhYIABDqAhC0AhCKAxC3AxDUAxDlAhgBMhYIABDqAhC0AhCKAxC3AxDUAxDlAhgBMhYIABDqAhC0AhCKAxC3AxDUAxDlAhgBMg0IABCPARDqAhC0AhgCMg0IABCPARDqAhC0AhgCMg0IABCPARDqAhC0AhgCMg0IABCPARDqAhC0AhgCMg0IABCPARDqAhC0AhgCMg0IABCPARDqAhC0AhgCMg0IABCPARDqAhC0AhgCMg0IABCPARDqAhC0AhgCMg0IABCPARDqAhC0AhgCMg0IABCPARDqAhC0AhgCOgoIABBHENYEELADSgQIQRgASgQIRhgBUN8SWN8SYOEvaANwAXgAgAEAiAEAkgEAmAEAoAEBsAEUyAEKwAEB2gEECAEYB9oBBggCEAEYCg&sclient=gws-wiz-serp"
        //         }, {
        //    "date_added": "13320223020086220",
        //            "date_last_used": "0",
        //            "guid": "158e5926-385f-410f-978b-adec364d3e1c",
        //            "id": "7",
        //            "meta_info": {
        //        "power_bookmark_meta": ""
        //            },
        //            "name": "AntiForgery クラス (System.Web.Helpers) | Microsoft Learn",
        //            "type": "url",
        //            "url": "https://learn.microsoft.com/ja-jp/dotnet/api/system.web.helpers.antiforgery?view=aspnet-webpages-3.2"
        //         }, {
        //    "children": [ {
        //        "date_added": "13320728862682100",
        //               "date_last_used": "0",
        //               "guid": "65d7baa2-ab5c-4354-99f8-89f6295b80c7",
        //               "id": "11",
        //               "meta_info": {
        //            "power_bookmark_meta": ""
        //               },
        //               "name": "Free Control Panel Website Templates (12) | Free CSS",
        //               "type": "url",
        //               "url": "https://www.free-css.com/template-categories/control-panel"
        //            } ],
        //            "date_added": "13320728852285360",
        //            "date_last_used": "0",
        //            "date_modified": "13320728862682113",
        //            "guid": "b6a3b3b8-3023-4578-810c-eb30a8355356",
        //            "id": "10",
        //            "name": "web",
        //            "type": "folder"
        //         } ],
        //         "date_added": "13320138067769376",
        //         "date_last_used": "0",
        //         "date_modified": "13320728852286305",
        //         "guid": "0bc5d13f-2cba-5d74-951f-3f233fe6c908",
        //         "id": "1",
        //         "name": "ブックマーク バー",
        //         "type": "folder"
        //      },
        //      "other": {
        //    "children": [  ],
        //         "date_added": "13320138067769381",
        //         "date_last_used": "0",
        //         "date_modified": "0",
        //         "guid": "82b081ec-3dd3-529c-8475-ab6c344590dd",
        //         "id": "2",
        //         "name": "その他のブックマーク",
        //         "type": "folder"
        //      },
        //      "synced": {
        //    "children": [  ],
        //         "date_added": "13320138067769384",
        //         "date_last_used": "0",
        //         "date_modified": "0",
        //         "guid": "4cf2e351-0e85-532b-bb37-df045d8f8d0f",
        //         "id": "3",
        //         "name": "モバイルのブックマーク",
        //         "type": "folder"
        //      }
        //   },
        //   "version": 1
        //}


        //Out put of Parse(0, jelem);

        //name = checksum, value = fb61b4009ca6e5c0b925c03e39e0562a
        //name = roots
        //  name = bookmark_bar
        //    name = children
        //     array index 1
        //      name = date_added, value = 13320138127313403
        //      name = date_last_used, value = 13320726260433248
        //      name = guid, value = 7e4f206d-4961-48ce-9c48-0bd05fe9d3f8
        //      name = id, value = 5
        //      name = meta_info
        //        name = power_bookmark_meta, value =
        //        name = name, value = 翻訳 英語 - Google 検索
        //      name = type, value = url
        //        name = url, value = https://www.google.com/search?q=%E7%BF%BB%E8%A8%B3+%E8%8B%B1%E8%AA%9E&ei=gpvgY9O4LJqlhwOGqaCYAw&oq=&gs_lcp=Cgxnd3Mtd2l6LXNlcnAQAxgEMhYIABDqAhC0AhCKAxC3AxDUAxDlAhgBMhYIABDqAhC0AhCKAxC3AxDUAxDlAhgBMhYIABDqAhC0AhCKAxC3AxDUAxDlAhgBMhYIABDqAhC0AhCKAxC3AxDUAxDlAhgBMhYIABDqAhC0AhCKAxC3AxDUAxDlAhgBMhYIABDqAhC0AhCKAxC3AxDUAxDlAhgBMhYIABDqAhC0AhCKAxC3AxDUAxDlAhgBMhYIABDqAhC0AhCKAxC3AxDUAxDlAhgBMhYIABDqAhC0AhCKAxC3AxDUAxDlAhgBMhYIABDqAhC0AhCKAxC3AxDUAxDlAhgBMg0IABCPARDqAhC0AhgCMg0IABCPARDqAhC0AhgCMg0IABCPARDqAhC0AhgCMg0IABCPARDqAhC0AhgCMg0IABCPARDqAhC0AhgCMg0IABCPARDqAhC0AhgCMg0IABCPARDqAhC0AhgCMg0IABCPARDqAhC0AhgCMg0IABCPARDqAhC0AhgCMg0IABCPARDqAhC0AhgCOgoIABBHENYEELADSgQIQRgASgQIRhgBUN8SWN8SYOEvaANwAXgAgAEAiAEAkgEAmAEAoAEBsAEUyAEKwAEB2gEECAEYB9oBBggCEAEYCg&sclient=gws-wiz-serp
        //     array index 2
        //      name = date_added, value = 13320223020086220
        //      name = date_last_used, value = 0
        //      name = guid, value = 158e5926-385f-410f-978b-adec364d3e1c
        //        name = id, value = 7
        //      name = meta_info
        //        name = power_bookmark_meta, value =
        //        name = name, value = AntiForgery クラス(System.Web.Helpers) | Microsoft Learn
        //      name = type, value = url
        //        name = url, value = https://learn.microsoft.com/ja-jp/dotnet/api/system.web.helpers.antiforgery?view=aspnet-webpages-3.2
        //     array index 3
        //      name = children
        //       array index 1
        //        name = date_added, value = 13320728862682100
        //        name = date_last_used, value = 0
        //        name = guid, value = 65d7baa2-ab5c-4354-99f8-89f6295b80c7
        //        name = id, value = 11
        //        name = meta_info
        //          name = power_bookmark_meta, value =
        //        name = name, value = Free Control Panel Website Templates(12) | Free CSS
        //        name = type, value = url
        //        name = url, value = https://www.free-css.com/template-categories/control-panel
        //      name = date_added, value = 13320728852285360
        //      name = date_last_used, value = 0
        //      name = date_modified, value = 13320728862682113
        //      name = guid, value = b6a3b3b8-3023-4578-810c-eb30a8355356
        //      name = id, value = 10
        //      name = name, value = web
        //      name = type, value = folder
        //    name = date_added, value = 13320138067769376
        //    name = date_last_used, value = 0
        //    name = date_modified, value = 13320728852286305
        //    name = guid, value = 0bc5d13f-2cba-5d74-951f-3f233fe6c908
        //    name = id, value = 1
        //    name = name, value = ブックマーク バー
        //    name = type, value = folder
        //  name = other
        //    name = children
        //    name = date_added, value = 13320138067769381
        //    name = date_last_used, value = 0
        //    name = date_modified, value = 0
        //    name = guid, value = 82b081ec-3dd3-529c-8475-ab6c344590dd
        //    name = id, value = 2
        //    name = name, value = その他のブックマーク
        //    name = type, value = folder
        //  name = synced
        //    name = children
        //    name = date_added, value = 13320138067769384
        //    name = date_last_used, value = 0
        //    name = date_modified, value = 0
        //    name = guid, value = 4cf2e351-0e85-532b-bb37-df045d8f8d0f
        //    name = id, value = 3
        //    name = name, value = モバイルのブックマーク
        //    name = type, value = folder
        //name = version, value = 1




        /// <summary>
        /// Enumerate JsonElement Object 
        /// 
        /// </summary>
        /// <param name="layer"></param>
        /// <param name="jelem"></param>
        public void ParseAndPickData(int layer, JsonElement jelem)
        {
            //useage:
            //using (StreamReader r = new StreamReader(@"C:\Users\mtnadmin\Desktop\mydoc\BookMark1\MyBookMark\Bookmarks_mi.txt"))
            //{
            //    string json = r.ReadToEnd();

            //    var jelem = JsonSerializer.Deserialize<JsonElement>(json);
            //    Parse(0, jelem);
            //}


            // JsonElement.ValueKind プロパティを使って JsonValueKind 列挙型
            // のどれに該当するかを調べて処理を分ける
            if (jelem.ValueKind == JsonValueKind.False ||
                jelem.ValueKind == JsonValueKind.Null ||
                jelem.ValueKind == JsonValueKind.Number ||
                jelem.ValueKind == JsonValueKind.String ||
                jelem.ValueKind == JsonValueKind.True)
            {
                string str = $"value = {jelem}";
                Console.WriteLine(str.PadLeft(str.Length + layer));
            }
            else if (jelem.ValueKind == JsonValueKind.Object)
            {
                // Object の場合は EnumerateObject() で列挙子を取得し、以下の
                // ように foreach ループで JsonProperty を取得できる。
                // JsonProperty というのは単一の {"name":"value"} オブジェクト
                // と思えばよさそう
                foreach (JsonProperty jprop in jelem.EnumerateObject())
                {
                    if (jprop.Value.ValueKind == JsonValueKind.False ||
                        jprop.Value.ValueKind == JsonValueKind.Null ||
                        jprop.Value.ValueKind == JsonValueKind.Number ||
                        jprop.Value.ValueKind == JsonValueKind.String ||
                        jprop.Value.ValueKind == JsonValueKind.True)
                    {
                        string str = $"ly= {layer}, name = {jprop.Name}, value = {jprop.Value}";
                        Console.WriteLine(str.PadLeft(str.Length + layer));
                    }
                    else if (jprop.Value.ValueKind == JsonValueKind.Object)
                    {
                        string str = $"ly= {layer}, name = {jprop.Name}";
                        Console.WriteLine(str.PadLeft(str.Length + layer));
                        ParseAndPickData(layer + 2, jprop.Value);
                    }
                    else if (jprop.Value.ValueKind == JsonValueKind.Array)
                    {
                        string str = $"ly= {layer}, name = {jprop.Name}";
                        Console.WriteLine(str.PadLeft(str.Length + layer));
                        int index = 1;
                        // Array の場合は EnumerateArray() で列挙子を取得し、以下のよう
                        // に foreach ループで配列内の各要素 (JsonElement) を取得できる
                        foreach (JsonElement jelemInArray in jprop.Value.EnumerateArray())
                        {
                            string idx = $"array index {index}";
                            Console.WriteLine(idx.PadLeft(idx.Length + layer + 1));
                            ParseAndPickData(layer + 2, jelemInArray);
                            index++;
                        }
                    }
                    else
                    {
                        // JsonValueKind.Undefined 以外はここに来ない（はず）
                        Console.WriteLine(jelem.ToString());
                    }
                }
            }
            else if (jelem.ValueKind == JsonValueKind.Array)
            {
                int index = 1;
                // Array の場合 EnumerateArray() で列挙子を取得し、以下のよう
                // に foreach ループで配列内の各要素 (JsonElement) を取得できる
                foreach (JsonElement jelemInArray in jelem.EnumerateArray())
                {
                    string idx = $"array index {index}";
                    Console.WriteLine(idx.PadLeft(idx.Length + layer + 1));
                    ParseAndPickData(layer + 2, jelemInArray);
                    index++;
                }
            }
            else
            {
                // JsonValueKind.Undefined 以外はここに来ない（はず）
                Console.WriteLine(jelem.ToString());
            }
        }



        List<MyBookMarkUrl> _tempUl = null;
        public void SendToList(string argName, string argVal)
        {
            // when "name" create a new row
            if("name".Equals(argName)) 
            {
                if (_tempUl == null) 
                {
                    _tempUl = new List<MyBookMarkUrl>();
                }

                var mbku1 = new MyBookMarkUrl();
                mbku1.name = argVal;
                _tempUl.Add(mbku1);  // 末尾に追加
                return;
            }

            // when "url" modify url to last row
            if ("url".Equals(argName))
            {
                var mbku3 = _tempUl.Last();
                mbku3.url = argVal;
                return;
            }

            // when type = folder  Add rows to DT
            if ("type".Equals(argName))
            {
                //This is the URL folder, so Insert all data to DT
                if("folder".Equals(argVal)) 
                {
                    var mbku2 = _tempUl.Last();
                    SetRows(_tempUl, mbku2.name);
                    _tempUl = null; // clear list
                    return;
                }                
            }            
        }


        DataTable _DtBookMarkUrl = null;
        public void SetRows(List<MyBookMarkUrl> argList, string folderName)
        {
            if(_DtBookMarkUrl == null) 
            {
                _DtBookMarkUrl = new DataTable();
                // カラム名の追加
                _DtBookMarkUrl.Columns.Add("folder");
                _DtBookMarkUrl.Columns.Add("name");
                _DtBookMarkUrl.Columns.Add("url");
            }            

            foreach (var al in argList)
            {
                if(string.IsNullOrEmpty(al.url)== false) 
                {
                    _DtBookMarkUrl.Rows.Add(folderName, al.name, al.url);
                }
            }


            //DataRow dr = table.NewRow();
            //dr["folder"] = "11111";
            //dr["name"] = "2222";
            //dr["url"] = "33333";
            //table.Rows.Add(dr);

            //table.Rows.Add("a111", "a222", "a333");
            //table.Rows.Add("b111", "b222", "b333");
        }


    }




    //sample with StreamReader/StreamWriter.
    class sample_aaa
    {
        static void tMain(string[] args)
        {
            List<Person> source = new List<Person>();

            using (StreamReader r = new StreamReader("data.json"))
            {
                string json = r.ReadToEnd();
                source = JsonSerializer.Deserialize<List<Person>>(json);
            }

            List<DataReadyPerson> destination = source.Select(d => new DataReadyPerson
            {
                CityOfResidence = d.City,
                fname = d.Firstname,
                lname = d.Lastname,
                DataReadPersonId = d.Id
            }).ToList();


            string jsonString = JsonSerializer.Serialize(destination, new JsonSerializerOptions() { WriteIndented = true });
            using (StreamWriter outputFile = new StreamWriter("dataReady.json"))
            {
                outputFile.WriteLine(jsonString);
            }
        }
    }

    public class Person
    {
        public int Id { get; set; }
        public string Firstname { get; set; }
        public string Lastname { get; set; }
        public string City { get; set; }
    }
    public class DataReadyPerson
    {
        public int DataReadPersonId { get; set; }
        public string fname { get; set; }
        public string lname { get; set; }
        public string CityOfResidence { get; set; }
    }



}
