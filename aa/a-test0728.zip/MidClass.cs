﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Asist
{
    public class MidClass
    {

        public int _ClsCode = 0;




    }
}
