﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Asist
{
    public class ClsCode
    {
        // int 2,147,483,648 ～ 2,147,483,647


        public static int GetClassIdCode(object obj)
        {

            //MidClass m = new MidClass();
            //ClsCode.GetClassIdCode(m);

            string clsname = obj.GetType().Name;
            Console.WriteLine(obj.GetType().Name);      // MidClass
            Console.WriteLine(obj.GetType().FullName);  // Asist.MidClass
            Console.WriteLine(obj.GetType().Namespace); // Asist




            // Type.GetField -- 获得 Class 中对象的值
            //https://learn.microsoft.com/ja-jp/dotnet/api/system.type.getfield?view=net-7.0 
            FieldInfo myFieldInfo = typeof(ClsCode).GetField(clsname, BindingFlags.Public | BindingFlags.Static);
            //ClsCode cc = new ClsCode();
            //myFieldInfo.GetValue(ClsCode) 语法错误 所以这里必须要设置一个实例 所以上面必须定义一个实例
            Console.WriteLine(myFieldInfo.GetValue(null));    // 12345


            // Type.GetMember -- 获得 Class 中的属性/对象  但是得不到 Value 设计的时候 是啥意图 不明白
            //https://learn.microsoft.com/ja-jp/dotnet/api/system.type.getmember?view=net-7.0
            Type Tc = typeof(ClsCode);
            MemberInfo[] myMembers = Tc.GetMember(clsname, BindingFlags.Public | BindingFlags.Static);
            if (myMembers.Length == 1)
            {
                Console.WriteLine(myMembers[0].ToString()); //Int32 MidClass
            }
            else
            {
                string aa = "Error.";
            }

            return 0;
        }


        // folder 999 + class/file 999 + msg 999

        // folder=20  class/file = 2  msg 000-999
        public static int MidClass = 20002000;





    }
}
