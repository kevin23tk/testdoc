﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Asist
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            TreeViewInit();
        }

        private void TreeViewInit()
        {
            // TreeNode(String, Int32, Int32)
            // https://learn.microsoft.com/zh-cn/dotnet/api/system.windows.forms.treenode.-ctor?view=windowsdesktop-7.0#system-windows-forms-treenode-ctor(system-string-system-int32-system-int32)
            // Add image list with icons
            ImageList imageList = new ImageList();
            imageList.Images.Add(SystemIcons.Shield);
            imageList.Images.Add(SystemIcons.Application);
            treeView1.ImageList = imageList;

            // toolTip1 在 vs2022 无法使用
            // Enable node tooltips for the treeview
            //treeView1.ShowNodeToolTips = true;
            // Set the tooltip control to use for the treeview
            // https://developercommunity.visualstudio.com/t/tooltips-not-working-in-vs2022/1684511
            //toolTip1.SetToolTip(treeView1, "aaaaa");

            string path = "D:\\worksp";
            TreeNode rootNode = new TreeNode("worksp", 0, 0);
            treeView1.Nodes.Add(rootNode);
            TraverseFolders(path, rootNode);
        }




        private void TraverseFolders(string path, TreeNode parentNode)
        {
            try
            {
                string[] subFolders = Directory.GetDirectories(path);
                foreach (string folder in subFolders)
                {
                    string folderName = new DirectoryInfo(folder).Name;
                    TreeNode folderNode = new TreeNode(folderName, 0, 0);
                    folderNode.Tag = folder;
                    parentNode.Nodes.Add(folderNode);
                    TraverseFolders(folder, folderNode);
                }

                string[] files = Directory.GetFiles(path);
                foreach (string file in files)
                {
                    string fileName = new FileInfo(file).Name;
                    TreeNode fileNode = new TreeNode(fileName, 1, 1);
                    fileNode.Tag = file;
                    parentNode.Nodes.Add(fileNode);
                }
            }
            catch (UnauthorizedAccessException)
            {
                // Ignore unauthorized access errors
            }
        }


        private void treeView1_NodeMouseDoubleClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            // Get the clicked node
            TreeNode clickedNode = e.Node;

            // Get the full path of the clicked node
            string fullPath = clickedNode.FullPath;

            MessageBox.Show(fullPath);

            // If the clicked node represents a file, open it
            //if (File.Exists(fullPath))
            //{
            //    Process.Start(fullPath);
            //}
            //// If the clicked node represents a folder, open it in Windows Explorer
            //else if (Directory.Exists(fullPath))
            //{
            //    Process.Start("explorer.exe", fullPath);
            //}
        }

        private void treeView1_NodeMouseHover(object sender, TreeNodeMouseHoverEventArgs e)
        {
            try
            {
                // Get the tooltip text for the node
                string tooltipText = e.Node.Tag.ToString();

                toolStripStatusLabel1.Text = tooltipText;

                // Set the tooltip text for the treeview
                //toolTip1.SetToolTip(treeView1, tooltipText);
            }
            catch (Exception)
            {
                //throw;
            }
            

            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            GenChart();
        }


        private void GenChart()
        {
            // 设置 Chart 控件的标题和图例
            chart1.Titles.Add("Stock Price");
            chart1.Legends.Add("Legend");


            //var series1 = chart1.Series.Add("Open");
            //var series2 = chart1.Series.Add("Close");
            //var series3 = chart1.Series.Add("High");
            //var series4 = chart1.Series.Add("Low");

            //series1.ChartType = SeriesChartType.Candlestick;
            //series1["OpenCloseStyle"] = "Triangle";
            //series1["ShowOpenClose"] = "Both";
            //series1["PointWidth"] = "0.6";

            //series2.ChartType = SeriesChartType.Candlestick;
            //series2["OpenCloseStyle"] = "Triangle";
            //series2["ShowOpenClose"] = "Both";
            //series2["PointWidth"] = "0.6";

            //series3.ChartType = SeriesChartType.Candlestick;
            //series3["PriceUpColor"] = "Green";
            //series3["PriceDownColor"] = "Red";
            //series3["PointWidth"] = "0.6";

            //series4.ChartType = SeriesChartType.Candlestick;
            //series4["PriceUpColor"] = "Green";
            //series4["PriceDownColor"] = "Red";
            //series4["PointWidth"] = "0.6";

            //// Add data points
            //DateTime date1 = new DateTime(2022, 1, 1);
            //DateTime date2 = new DateTime(2022, 1, 2);
            //DateTime date3 = new DateTime(2022, 1, 3);
            //DateTime date4 = new DateTime(2022, 1, 4);

            //series1.Points.AddXY(date1, 10);
            //series1.Points.AddXY(date2, 12);
            //series1.Points.AddXY(date3, 11);
            //series1.Points.AddXY(date4, 13);

            //series2.Points.AddXY(date1, 15);
            //series2.Points.AddXY(date2, 14);
            //series2.Points.AddXY(date3, 16);
            //series2.Points.AddXY(date4, 18);

            //series3.Points.AddXY(date1, 8);
            //series3.Points.AddXY(date2, 9);
            //series3.Points.AddXY(date3, 10);
            //series3.Points.AddXY(date4, 12);

            //series4.Points.AddXY(date1, 12);
            //series4.Points.AddXY(date2, 11);
            //series4.Points.AddXY(date3, 13);
            //series4.Points.AddXY(date4, 15);



            // 创建一个 Series 对象，并设置其属性
            var series = new Series();
            series.ChartType = SeriesChartType.Candlestick;
            series.Color = Color.Black;
            series["OpenCloseStyle"] = "Triangle";
            series["ShowOpenClose"] = "Both";
            series["PriceUpColor"] = "Green";
            series["PriceDownColor"] = "Red";

            // 添加数据点到 Series 对象中
            series.Points.AddXY(new DateTime(2022, 1, 1), new double[4] { 10, 15, 8, 12 });
            series.Points.AddXY(new DateTime(2022, 1, 2), new double[4] { 12, 14, 9, 11 });
            series.Points.AddXY(new DateTime(2022, 1, 3), new double[4] { 11, 16, 10, 13 });
            series.Points.AddXY(new DateTime(2022, 1, 4), new double[4] { 13, 18, 12, 15 });

            //series.Points.AddXY("2022-01-01", 10, 15, 8, 12);
            //series.Points.AddXY("2022-01-02", 12, 14, 9, 11);
            //series.Points.AddXY("2022-01-03", 11, 16, 10, 13);
            //series.Points.AddXY("2022-01-04", 13, 18, 12, 15);

            // 将 Series 对象添加到 Chart 控件中
            chart1.Series.Add(series);
        }


    }



}
