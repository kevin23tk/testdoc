﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Asist
{
    internal class ClsJparam
    {
    }


    public class JobjIn
    {
        public string datetime = "";
        public string loginid = "";
        public string devid = "";
        public string model = "";
        public string lang = "";
        public string option = "";      // showheaders | showrequest | 
        public string dl1max = "";
        public string dl2max = "";
        public string dl3max = "";
        public Data_dl[] dl1 = new Data_dl[0];
        public Data_dl[] dl2 = new Data_dl[0];
        public Data_dl[] dl3 = new Data_dl[0];
    }


    public class Data_dl
    {
        public string[] c;

        public Data_dl()
        {
            c = Array.Empty<string>();  // new string[0]
        }
        public Data_dl(int colMax)
        {
            c = new string[colMax];
        }
    }



}
