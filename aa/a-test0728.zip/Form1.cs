﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows.Forms;

namespace Asist
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ReadJsonText();
        }

        private void ReadJsonText()
        {
            //List<GhromeBookMarkMain> source = new List<GhromeBookMarkMain>();

            GhromeBookMarkMain cc = new GhromeBookMarkMain();


            using (StreamReader r = new StreamReader(@"C:\Users\mtnadmin\Desktop\mydoc\BookMark1\MyBookMark\Bookmarks_mi.txt"))
            {
                string json = r.ReadToEnd();

                var jelem = JsonSerializer.Deserialize<JsonElement>(json);
                ClsJson cj = new ClsJson();
                cj.ParseAndPickData(0, jelem);
                //cc = JsonSerializer.Deserialize<GhromeBookMarkMain>(json);
            }

            //List<DataReadyPerson> destination = source.Select(d => new DataReadyPerson
            //{
            //    CityOfResidence = d.City,
            //    fname = d.Firstname,
            //    lname = d.Lastname,
            //    DataReadPersonId = d.Id
            //}).ToList();


            //using (StreamReader r = new StreamReader(@"C:\Users\mtnadmin\Desktop\mydoc\BookMark1\MyBookMark\Bookmarks_mi.txt"))
            //{
            //    string json = r.ReadToEnd();

            //    string jsonString = JsonSerializer.Serialize(json, new JsonSerializerOptions() { WriteIndented = true });
            //    using (StreamWriter outputFile = new StreamWriter("dataReady.json"))
            //    {
            //        outputFile.WriteLine(jsonString);
            //    }
            //}


    }

        private void button2_Click(object sender, EventArgs e)
        {

            MidClass m = new MidClass();
            ClsCode.GetClassIdCode(m);


            //JobjIn aa = new JobjIn();
            //aa.datetime = DateTime.Now.ToString("yyyyMMddHHmmss");
            //aa.loginid = "lll";
            //aa.devid = "ddd";
            //aa.model = "mmm";
            //aa.lang = "jjj";
            //aa.option = "ooo";
            //aa.dl1max = "0";

            //System.Web.Script.Serialization.JavaScriptSerializer jj = new JavaScriptSerializer();
            //string aas = jj.Serialize(aa);
            //Trace.WriteLine(aas);


            //string bbb = "{\"datetime\":\"2023-03-08 17:38:34\",\"loginid\":\"L001\",\"devid\":\"D001\",\"model\":\"Yotei01\",\"lang\":\"ja-jp\",\"option\":\"\",\"dl1max\":\"1\",\"dl2max\":\"\",\"dl3max\":\"\",\"dl1\":[{\"c\":[\"name\",\"gender\",\"age\"]},{\"c\":[\"田中\",\"男\",\"35\"]}],\"dl2\":[],\"dl3\":[]}";

            //JobjIn bb = jj.Deserialize<JobjIn>(bbb);
            //Trace.WriteLine("111");

        }




    }
}
