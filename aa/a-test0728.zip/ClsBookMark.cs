﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace Asist
{
    public class ClsBookMark
    {


    }

    public class GhromeBookMarkMain
    {
        public string checksum { get; set; }
        public GhromeBookMarkRoot roots { get; set; }
        public string version { get; set; }
    }

    public class GhromeBookMarkRoot
    {
        public GhromeBookMarkFolder bookmark_bar { get; set; }
        public GhromeBookMarkFolder other { get; set; }
        public GhromeBookMarkFolder synced { get; set; }
    }

    public class GhromeBookMarkUrl
    {        
        public string date_added { get; set; }
        public string date_last_used { get; set; }
        public string guid { get; set; }
        public string id { get; set; }
        public string meta_info { get; set; }
        public string name { get; set; }
        public string type { get; set; }
        public string url { get; set; }
    }

    public class GhromeBookMarkFolder
    {        
        public GhromeBookMarkUrl[] children { get; set; }
        public string date_added { get; set; }
        public string date_last_used { get; set; }
        public string date_modified { get; set; }
        public string guid { get; set; }
        public string id { get; set; }
        public string name { get; set; }
        public string type { get; set; }
    }




    public class MyBookMarkUrl
    {
        public string folder { get; set; }
        public string name { get; set; }
        public string type { get; set; }
        public string url { get; set; }
    }




}
