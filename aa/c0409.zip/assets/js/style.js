$(function () {
  $("#myTable").DataTable({
    "language": {
      "url": "//cdn.datatables.net/plug-ins/1.10.22/i18n/Japanese.json"
    }
  });
});

$('#main-navmenu').hover(
		function() {
			$(this).addClass('hovered');
		},
		function() {
			$(this).removeClass('hovered');
			$(this).find('.menu-list li').removeClass('selected');
			$(this).find('.side-menu-list').removeClass('selected');
		}
	);

	$('#main-navmenu .menu-list li').hover(
		function() {
			var ttl = $(this).children('a').text();
			$(this).addClass('selected');
			$(this).siblings().removeClass('selected');

			var current;
			switch(ttl) {
				case "新着情報":
					current = $('.side-menu-list.sub01');
					$(current).addClass('selected');
					break;
				case "入 荷":
					current = $('.side-menu-list.sub02');
					$(current).addClass('selected');
					break;
				case "出 荷":
					current = $('.side-menu-list.sub03');
					$(current).addClass('selected');
					break;
          case "検 索":
					current = $('.side-menu-list.sub04');
					$(current).addClass('selected');
					break;
				case "加 工":
					current = $('.side-menu-list.sub05');
					$(current).addClass('selected');
					break;
				case "マスタ管理":
					current = $('.side-menu-list.sub06');
					$(current).addClass('selected');
					break;
				default:
					current = $('.side-menu-list');
					break;
			}
			$(current).siblings().removeClass('selected');
		},
		function() {
			//マウスカーソルが離れた時の処理
		}
	);


