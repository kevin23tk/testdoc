Cookie localStorage sessionStorage の違い
https://hapicode.com/javascript/cookie-webstorage.html#cookie


★技術点
localStorage、sessionStorageを使う
Cookieを使わない

同じBrowser中に複数TABで独立機能ページの操作は可能です。

TAB1「入荷処理」、TAB2「出荷処理」...など同時に操作OK。
TAB1「入荷処理」、TAB2「入荷処理」...など同じ処理でも同時に操作OK。
TAB1、TAB2...などLogin有効・無効のロカール連動設定OK。


違うBrowser中にLogin有効・無効のロカール連動はできません。
eg: Chrome TAB1「入荷処理」、Edge TAB1「出荷処理」の場合
　　その場合はLogin有効・無効の判断はサーバー側に処理。


★Login有効・無効のサーバー側管理モジュル
Token管理必要があります。
Login成功後、Tokenを発行してBrowser側に保存する。
Tokenの有効期間はサーバー側設定・管理する。
Login画面開く時にTokenの有効性チェックを自動的行う。


★複数TAB同時操作のDB問題
1. Select Data 問題なし。
2. Update Data 二重更新可能性がある(最後の更新日付チェック改善強化)
3. Insert Data 問題ある。★★★
4. Delete Data 問題なし。(すでに削除されたDataを再削除失敗)