/*
 * @Author: Kamikawa
 * @Date: 2023-02-21 09:31:48
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2023-03-27 10:25:55
 * @FilePath: \JS_TEST\tabopenclose\tab.js
 * @Description:
 *
 * Copyright (c) 2023 by ${git_name_email}, All Rights Reserved.
 */

function openNewTab(url) {
  window.open(url, '_blank');
}


function openNewTab2(url) {
  // iterate over all open windows
  alert(win.location.href);
  
  alert(window.opener.window.length);
  for (var i = 0; i < window.opener.window.length; i++) {
      var win = window.opener.window[i];

      alert(win.location.href);
      // Check if windows have the same URL
      if (win.location.href === url) {
      // If the same URL is found, switch focus to that tab
      win.focus();
      return;
      }
  }
  // Opens a new tab if no tab with the same URL is found
  window.open(url, '_blank');

  }

  function openNewTab3(url) {

    // 获取当前窗口的域名
    const currentDomain = window.location.hostname;

    // 获取所有已打开的选项卡
    const tabs = Array.from(window.top.document.querySelectorAll('iframe'));

    // 关闭包含相同域名的选项卡
    tabs.forEach(tab => {
      const tabDomain = tab.contentWindow.location.hostname;
      alert(tabDomain);
      // if (tabDomain === currentDomain) {
      //   tab.remove();
      // }
    });

    window.open(url, '_blank');

  }