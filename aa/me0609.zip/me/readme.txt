吉岡 常務
上西 輝 <a-uenishi@mtn.co.jp>; 木谷 哲也<t-kidani@mtn.co.jp>; 伊藤 亜美 <a-itou@mtn.co.jp>
斎藤 純一 <j-saito@mtn.co.jp>; 佐々木 美駒<mi-sasaki@mtn.co.jp>;
鳥居　ジュアン <nlj-torii@mtn.jp>
ohashi@newland.co.jp   yujie@newland.co.jp
--------------------------------------------------------------------------------------
C:\Users\mtnadmin\AppData\Local\Temp\iisexpress
Clear web browser cache
-------------------------------------------
SS1Agent 多分基盤チームがインストールされたもの
Logなど　監視ツッルと思います
C:\Program Files (x86)\D.O.S\SS1Agent
https://www.dos-osaka.co.jp/ss1/lp/ss1am_2022/index.html
-------------------------------------------

\\172.17.73.1\w-keeper\VSS
\\172.17.73.1\w-keeper\WKEEPER\01.業務
\\172.17.73.1\w-keeper\WKEEPER\02.標準

\\172.17.73.1\w-keeper\WKEEPER\02.標準\資料\31勉強会
\\172.17.73.1\w-keeper\WKEEPER\02.標準\資料\21標準化資料\02DB設計

-------------------------------------------------
TK-SV-V233WKP01\nlj-kamikawa
フォルダアクセスのパスワードリセットしてもらいました。
下記、ご確認お願いします。
１）パスワードの再設定
パスワード：20230313
２）資格情報の変更
下記のプログラムでWindows資格情報が設定されているので
該当サーバのパスワードを再設定してください。
コントロールパネル　＞　ユーザアカウント　＞　資格情報マネージャー
Windows資格情報
-------------------------------------------------
\\172.17.73.1\w-keeper\WKEEPER\ ---> \\172.17.73.20\w-keeper\WKEEPER\
nlj-kamikawa / 20230410

-------------------------------------------------
http://mrwgn1/syasys/Cm/CmLogin.asp

ID ：9384
PW：9384
業務コード：KMTNW0-01

作業日報入力はいま「照会のみ」になりました。入力できない状態です。

-------------------------------------------------
Teams
nlj-kamikawa@mtn.jp
Tm#kmkw3
Tm#kmkw6
-------------------------------------------------
Visual Studio Professional 2022 LTSC (version 17.4)
T79NY-3CX6K-J4TJ9-XW79P-JB8WX 
-------------------------------------------------
pgAmin
master pwd
kamikawa
-------------------------------------------------
PostgreSQL

https://www.postgresql.org/ftp/pgadmin/pgadmin4/v6.19/windows/

BS-SV-V221WEB01
5432
postgres
postgres

kepdemo
kepdemo
-------------------------------------------------
Redmine
*	ログインID: nlj-kamikawa@mtn.jp
*	パスワード: nlj-kamikawa@mtn.jp

ログイン: http://mrppma/redmine/login
-------------------------------------------------

グループ：MTN
プロジェクト名：KWMNW
GitLabプロジェクトURL：https://172.17.73.38/mtn/kmtnw
クローン時URL：https://<ユーザー名>@172.17.73.38/mtn/kmtnw
例）佐野の場合→「https://slt-sano@172.17.73.38/mtn/kmtnw」

Lab#2023
Token: glpat-4K7qXgcf9dpqfjVrV8Hq

https://oauth:glpat-4K7qXgcf9dpqfjVrV8Hq@BS-SV-VLX6WEB01/mtn/kmtnw.git

git 关闭 HTTPS
>git config --global http.sslVerify false

Vs 開発フォルダ中 gitignoreの作成
D:\worksp\demo1>dotnet new gitignore

-------------------------------------------------
Visual Studioは.gitignoreファイルの生成
Visual Studioは.gitignoreファイルを自動的に生成する機能を提供しています。以下の手順で生成することができます。
1.ソリューションエクスプローラーで、ソリューションフォルダーを右クリックし、「追加」->「新しいアイテム」を選択します。
2.左側のテンプレートから「.gitignoreファイル」を選択し、ファイル名を指定して「追加」をクリックします。
3.生成された.gitignoreファイルがソリューションエクスプローラーに表示されます。
また、GitHubが提供する.gitignoreテンプレートを利用することもできます。具体的には、GitHubの公式ウェブサイトから、利用する言語やフレームワークに合わせた.gitignoreテンプレートを取得して、プロジェクトフォルダー内に保存することができます。

dotnet new gitignore
-------------------------------------------------

部分的なディレクトリのチェックアウトについて、方法が解りましたのでご連絡します。
お時間ある時にお試しください。
【部分的なチェックアウト方法】
①チェックアウトをせずにクローン
git clone --no-checkout <repository path>
②部分チェックアウト機能を有効化
git sparse-checkout init
③チェックアウトしたいディレクトリを指定
git sparse-checkout add <directry name>
④チェックアウト実施
git checkout
-------------------------------------------------
git 增加 Message模板
>git config --local commit.template .message
※在 .gitignore 文件的相同目录下 会生成一个 .message 文件
内容如下:
[<ブランチ名>] #<イシュー#> <イシュータイトル>

[内容]
<作業内容>
-------------------------------------------------
D:\gitworksp>git config --global http.sslVerify false
D:\gitworksp>git clone https://oauth:glpat-4K7qXgcf9dpqfjVrV8Hq@BS-SV-VLX6WEB01/mtn/kmtnw.git
Cloning into 'kmtnw'...
warning: ----------------- SECURITY WARNING ----------------
warning: | TLS certificate verification has been disabled! |
warning: ---------------------------------------------------
warning: HTTPS connections may not be secure. See https://aka.ms/gcm/tlsverify for more information.
warning: ----------------- SECURITY WARNING ----------------
warning: | TLS certificate verification has been disabled! |
warning: ---------------------------------------------------
warning: HTTPS connections may not be secure. See https://aka.ms/gcm/tlsverify for more information.
remote: Enumerating objects: 3, done.
remote: Total 3 (delta 0), reused 0 (delta 0), pack-reused 3
Receiving objects: 100% (3/3), done.
-------------------------------------------------

WEB Printer -- Label / Barcode Print
https://www.sato.co.jp/products/printertool/v5-webengine/

-------------------------------------------------

記号	意味
なし	"1"を表します。
P	1以上を表します。
Z	0または1を表します。
n	定数nを表します。
n-m	範囲指定をした定数を表しています。（例：1-10）


荷主コード
冗長

ROOM

-------------------------------------------------
写文档可以抄的内容

URL router
https://learn.microsoft.com/ja-jp/aspnet/core/mvc/controllers/routing?view=aspnetcore-7.0

Windows で利用可能な言語
https://learn.microsoft.com/ja-jp/windows-hardware/manufacture/desktop/available-language-packs-for-windows?view=windows-11

microsoft 使用缩写 ja-jp
https://learn.microsoft.com/ja-jp/windows/apps/publish/publish-your-app/supported-languages?source=recommendations&pivots=store-installer-msix
mozilla 使用缩写 ja
https://developer.mozilla.org/ja/docs/Web/API/Window
-------------------------------------------------


中国語 繁体字 中華人民
中国语 简体字 中华人民
善良な人
本当に善良な人の15の特性
人の命を救う
命を救いました
陰陽
-------------------------------------------------

[appwiz.cpl] を起動する。
[Windowsの機能の有効化または無効化] 
[インターネット インフォメーション サービス] にチェックを入れ


-------------------------------------------------

Git Server

比較
https://docs.gitea.io/en-us/comparison/

紹介
https://ja.wikipedia.org/wiki/Gitea
https://www.gitlab.jp/devops-tools/gitea-vs-gitlab.html

インストール参照
https://sakuya712.github.io/post/gitea/
https://celtislab.net/archives/20200205/gitea-windows/

giteaメリットは
Low RAM/ CPU usage
Multiple OS support
機能は github と大体同じです

-------------------------------------------------

一番有名のCIツッルはJenkins
https://www.jenkins.io/
GiteaとJenkinsによるCI/CDの実例サンプル（Python / PHP / Perl でテストとデプロイを自動化する）
https://qiita.com/bashaway/items/16ef713fdbd30ecbcab8

Jenkinsに代わるGo製OSS CIツールDrone
https://engineering.linecorp.com/ja/blog/go-oss-ci-tool-drone-replaces-jenkins/

Gitea用のDroneサーバをインストールする方法について説明します。
https://docs.drone.digitalstacks.net/l/ja/provider/gitea

Gitea is working on a built-in CI/CD tool called Gitea Actions
https://blog.gitea.io/2022/12/feature-preview-gitea-actions/

-------------------------------------------------

Return String
http://localhost:52827/test1/hello

return Json
http://localhost:52827/Test1/GetTime

Get + Parameter
http://localhost:52827/Test1/Add?arg1=2&arg2=4

多言語
http://localhost:52827/Test1/HelloAct

Getid
http://localhost:52827/zh-tw/Test1/getid/33
http://localhost:52827/zh-tw/Test1/getid?id=44

Show 
ViewData
ViewBag
Module
判断 GET/POST
/ja-jp/Test1/Page1/8

template無し
/ja-jp/Test1/Page2

データベース
/ja-jp/Test1/Page3

Page 定義無し Error
Index

-------------------------------------------------

普通 FROM
formpost.html

Dropdownlist
testget.html

POST -- Show Error Code
testpost.html

自動多言語対応
http://localhost:52827/ja-jp/Nyuka/index

--------------------------------------------------------------------------------------------------
当涉及到JavaScript表单验证时，有许多优秀的类库可供选择。以下是一些常用的JavaScript输入检查类库：
Validator.js: 一个轻量级的 JavaScript 表单验证库，支持异步校验和自定义校验规则。
jQuery Validation Plugin: 这是一个 jQuery 插件，它使表单验证变得非常简单，并具有可定制的错误消息和样式。
Parsley.js: 一个轻量级的JavaScript表单验证库，提供内置的验证规则和自定义验证规则的支持。
FormValidation: 一个全功能的JavaScript表单验证库，支持Bootstrap、Foundation、Material Design等UI框架，并提供各种类型的表单验证规则。
Yup: 一种用于 JavaScript 对象的模式验证器和解析器。它可以用于验证表单数据以及其他 JavaScript 对象。
以上这些库都有自己的特点和使用方法，您可以根据自己的需求来选择适合您的库。
--------------------------------------------------------------------------------------------------
let、var、constの違い
https://techplay.jp/column/1619
-------------------------------------------------
https://datatables.net/
-------------------------------------------------
https://nodejs.org/ja/download
-------------------------------------------------
bootstrap 提供免费的图标
https://icons.getbootstrap.jp/
-------------------------------------------------
ハンバーガーメニューのURLです。よろしくお願いします。
https://coco-factory.jp/ugokuweb/move01-cat/humbugermenu/

-------------------------------------------------
日文字体  以下3种引用方式
Hachi Maru Pop


https://fonts.google.com/specimen/Hachi+Maru+Pop?subset=japanese&noto.script=Jpan

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Hachi+Maru+Pop&display=swap" rel="stylesheet">


<style>
  @import url('https://fonts.googleapis.com/css2?family=Hachi+Maru+Pop&display=swap');
</style>


font-family: 'Hachi Maru Pop', cursive;

-------------------------------------------------
中文字体  以下3种引用方式
Zhi Mang Xing

https://fonts.google.com/specimen/Zhi+Mang+Xing?subset=chinese-simplified&noto.script=Hans

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Zhi+Mang+Xing&display=swap" rel="stylesheet">

<style>
  @import url('https://fonts.googleapis.com/css2?family=Zhi+Mang+Xing&display=swap');
</style>

font-family: 'Zhi Mang Xing', cursive;
-------------------------------------------------

可以使用以下查询来列出当前数据库中定义的所有函数：
SELECT proname FROM pg_proc;

如果要列出特定模式中定义的函数，可以使用以下查询：
SELECT proname FROM pg_proc WHERE pronamespace = 'your_schema_name'::regnamespace;

如果您想查看特定函数的定义，请使用以下查询：
SELECT pg_get_functiondef('your_function_name'::regproc);

-------------------------------------------------
9384　9387
3/3, 3/7, 3/9, 3/15, 3/17, 3/20, 3/22, 3/28, 3/30
5/2, 5/10, 5/12, 5/15, 5/17, 5/23, 5/26, 5/31
6.1 6.6 6.9 6.12 6.14 6.22 6.23 6.27 6.30
-------------------------------------------------











