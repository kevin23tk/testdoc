﻿namespace demo1.CodeMsg
{

    /// <summary>
    /// Author: Kamikawa
    /// Date: 2023-03
    /// LastEditTime: 
    /// Description: 
    /// 
    /// </summary>
    public class Msg_enus
    {


        /// <summary>
        ///  Web Page 表示用 文字データ  string[,]
        ///  
        /// </summary>
        public static Dictionary<int, string[,]> MsgArr = new Dictionary<int, string[,]>()
        {
            { ClassCode.WkpGetPostController + 2,
                new string[,]{
                    { "col1", "disp1"},
                    { "col2", "disp2"},
                    { "col3", "disp3"},
                    { "col4", "disp4"},
                    { "col5", "disp5"},
                }
            },

            { ClassCode.NyukaController + 3,
                new string[,]{
                    { "disp_title01", "Receipt/receipt registration"},
                    { "disp_label01", "Consignor"},
                    { "disp_label02", "Point"},
                    { "disp_label03", "Staff"},
                }
            },

        };



        /// <summary>
        ///  独立Code -- 表示用Msg
        /// </summary>
        public static Dictionary<int, string> MsgData = new Dictionary<int, string>()
        {
            { ClassCode.WkpGetPostController + 10, "Error 10." },
            { ClassCode.WkpGetPostController + 20, "Error 20." },
            { ClassCode.WkpGetPostController + 30, "Error 30." },
            { ClassCode.WkpGetPostController + 40, "Error 40." },
            { ClassCode.WkpGetPostController + 50, "Error 50." },
            { ClassCode.WkpGetPostController + 60, "Error 60." },
            { ClassCode.WkpGetPostController + 70, "Error 70." },
        };



    }
}
