﻿namespace demo1.CodeMsg
{

    /// <summary>
    /// Author: Kamikawa
    /// Date: 2023-03
    /// LastEditTime: 
    /// Description: 
    /// 
    /// </summary>
    public class Msg_zhcn
    {


        /// <summary>
        ///  Web Page 表示用 文字データ  string[,]
        ///  
        /// </summary>
        public static Dictionary<int, string[,]> MsgArr = new Dictionary<int, string[,]>()
        {
            { ClassCode.WkpGetPostController + 2,
                new string[,]{
                    { "col1", "显示1"},
                    { "col2", "显示2"},
                    { "col3", "显示3"},
                    { "col4", "显示4"},
                    { "col5", "显示5"},
                }
            },

            { ClassCode.NyukaController + 3,
                new string[,]{
                    { "disp_title01", "收货・入库"},
                    { "disp_label01", "货主"},
                    { "disp_label02", "仓库"},
                    { "disp_label03", "操作人"},
                }
            },

        };


        /// <summary>
        ///  独立Code -- 表示用Msg
        /// </summary>
        public static Dictionary<int, string> MsgData = new Dictionary<int, string>()
        {
            { ClassCode.WkpGetPostController + 10, "错误 10." },
            { ClassCode.WkpGetPostController + 20, "错误 20." },
            { ClassCode.WkpGetPostController + 30, "错误 30." },
            { ClassCode.WkpGetPostController + 40, "错误 40." },
            { ClassCode.WkpGetPostController + 50, "错误 50." },
            { ClassCode.WkpGetPostController + 60, "错误 60." },
            { ClassCode.WkpGetPostController + 70, "错误 70." },
        };




    }
}
