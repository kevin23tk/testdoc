﻿using System.Reflection;

namespace demo1
{
    /// <summary>
    /// Author: Kamikawa
    /// Date: 2023-03
    /// LastEditTime: 
    /// Description: 
    /// 
    /// </summary>
    public class ClassCode
    {

        // int -2,147,483,648 ～ 2,147,483,647
        // folder 999 + class/file 999 + msg 999
        


        /// <summary>
        /// usage: 
        ///   public static int _ClassID = ClassCode.GetClassId(typeof(Test1Controller));       
        ///   int _ClassID  --> 110004000
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public static int GetClassId(Type classType)
        {
            string clsname = classType.Name;
            //Trace.WriteLine(classType.Name);      // Test1Controller
            //Trace.WriteLine(classType.FullName);  // demo1.Controllers.Test1Controller
            //Trace.WriteLine(classType.Namespace); // demo1.Controllers

            //Console.WriteLine(obj.GetType().Name);      // MidClass
            //Console.WriteLine(obj.GetType().FullName);  // Asist.MidClass
            //Console.WriteLine(obj.GetType().Namespace); // Asist

            // Type.GetField -- Class 中にField对象の值を取得する
            //https://learn.microsoft.com/ja-jp/dotnet/api/system.type.getfield?view=net-7.0 
            FieldInfo? myFieldInfo = typeof(ClassCode).GetField(clsname, BindingFlags.Public | BindingFlags.Static);
            if (myFieldInfo != null) 
            {
                object? objval = myFieldInfo.GetValue(null);
                if (objval != null) 
                {
                    bool success = int.TryParse(objval.ToString(), out int number);
                    if (success)
                    {
                        return number;
                    }
                }
            }

            // If not Found above, Anyway return 0
            return 0;
        }

        // ------------------------------------------------------------------
        // folder 001 ～ 100 Framework使用
        // ------------------------------------------------------------------

        // Common - folder 20 + xxx + xxx
        public static int DbMethod = 20010000;  // class/file 10
        public static int EnvConst = 20011000;  // class/file 11
        public static int InstClassFunc = 20012000;  // class/file 12
        public static int JsonFunc = 20013000;  // class/file 13
        public static int JsonParam = 20014000;  // class/file 14
        public static int PostCaseCls = 20015000;  // class/file 15
        public static int UtilityFunc = 20016000;  // class/file 16
        public static int UtilityReturn = 20017000;  // class/file 17

        // ------------------------------------------------------------------
        // folder 001 ～ 100 Framework使用
        // folder 999 + class/file 999 + msg 999
        // ------------------------------------------------------------------

        // Controllers - folder 110
        public static int NyukaController = 110003000;  // class/file 3
        public static int Test1Controller = 110004000;  // class/file 4
        public static int WkpGetPostController = 110005000;  // class/file 5


        // Models - folder 150
        public static int ModCopySample = 150001000;  // class/file 1    


        // TestModels - folder 151
        public static int DbTestModel = 151001000;  // class/file 1        
        public static int GetDbData = 151002000;  // class/file 2
        public static int GetddlData = 151003000;  // class/file 3
        public static int WebGridModel = 151004000;  // class/file 4

        public static int LockTestSelect = 151005000;  // class/file 5
        public static int LockTestUpdate = 151006000;  // class/file 6



        // Nyuka - folder 152
        public static int Yotei01 = 152001000;  // class/file 1        
        public static int Yotei02 = 152002000;  // class/file 2
        public static int Yotei03 = 152003000;  // class/file 3

        public static int NkYoteiInsertCheck = 152010000;  // class/file 10      
        public static int NkYoteiDataSearch = 152011000;  // class/file 11
        public static int NkYoteiAutoSupplier = 152012000;  // class/file 12
        public static int NkYoteiDataUpdate = 152013000;  // class/file 13
        public static int NkYoteiSlipSearch = 152014000;  // class/file 14
        public static int NkYoteiDataDelete = 152015000;  // class/file 15

    }

}
