﻿using System.Collections.Generic;

namespace demo1.CodeMsg
{

    /// <summary>
    /// Author: Kamikawa
    /// Date: 2023-03
    /// LastEditTime: 
    /// Description: 
    /// 
    /// </summary>
    public partial class Msg_jajp
    {

        //public static string[,] GetMsgArr(int argInt) { return MsgArr[argInt]; }
        //public static string GetMsgData(int argInt) { return MsgData[argInt]; }



        /// <summary>
        ///  Web Page 表示用 文字データ  string[,]
        ///  
        /// </summary>
        public static Dictionary<int, string[,]> MsgArr = new Dictionary<int, string[,]>()
        {
            { ClassCode.WkpGetPostController + 2,  
                new string[,]{
                    { "col1", "表示1"},
                    { "col2", "表示2"},
                    { "col3", "表示3"},
                    { "col4", "表示4"},
                    { "col5", "表示5"},
                }
            },


            { ClassCode.NyukaController + 3,
                new string[,]{
                    { "disp_title01", "入荷・入庫登録"},
                    { "disp_label01", "荷主"},
                    { "disp_label02", "拠点"},
                    { "disp_label03", "担当者"},
                }
            },


        };


        /// <summary>
        ///  独立Code -- 表示用Msg
        /// </summary>
        public static Dictionary<int, string> MsgData = new Dictionary<int, string>()
        {
            { ClassCode.WkpGetPostController + 10, "エラー 10." },
            { ClassCode.WkpGetPostController + 20, "エラー 20." },
            { ClassCode.WkpGetPostController + 30, "エラー 30." },
            { ClassCode.WkpGetPostController + 40, "エラー 40." },
            { ClassCode.WkpGetPostController + 50, "エラー 50." },
            { ClassCode.WkpGetPostController + 60, "エラー 60." },
            { ClassCode.GetDbData + 31, "システムis BUSY. Please try later." },

        };





    }
}
