﻿namespace demo1.CodeMsg
{
    /// <summary>
    /// Author: Kamikawa
    /// Date: 2023-03
    /// LastEditTime: 
    /// Description: 
    /// 
    /// </summary>
    public class UtilityMsg
    {

        /// <summary>
        ///  Return Code 用
        /// </summary>
        /// <param name="lang"></param>
        /// <param name="argInt"></param>
        /// <returns></returns>
        public static string GetMsgData(string lang, int argInt) 
        {
            string reStr = ""; //初期化

            if (argInt == 0) { return reStr; } // 0  == 処理 OK    return ""

            switch (lang)
            {
                case "ja-jp":
                    if (Msg_jajp.MsgData.ContainsKey(argInt)) 
                    {
                        reStr = Msg_jajp.MsgData[argInt];   //日本語パラメータの取得
                    }                        
                    break;

                case "en-us":
                    if (Msg_enus.MsgData.ContainsKey(argInt))
                    { reStr = Msg_enus.MsgData[argInt]; }    //英語パラメータの取得
                    else
                    { reStr = Msg_jajp.MsgData[argInt]; }    //デフォルト - 日本語パラメータの取得
                    break;

                case "zh-cn":
                    if (Msg_zhcn.MsgData.ContainsKey(argInt))
                    { reStr = Msg_zhcn.MsgData[argInt]; }    //中国語パラメータの取得
                    else
                    { reStr = Msg_jajp.MsgData[argInt]; }    //デフォルト - 日本語パラメータの取得
                    break;

                default:
                    if (Msg_jajp.MsgData.ContainsKey(argInt)) 
                    {
                        reStr = Msg_jajp.MsgData[argInt];    //デフォルト - 日本語パラメータの取得
                    }                        
                    break;
            }

            if (string.IsNullOrEmpty(reStr)) 
            {
                reStr = "システム Debug/Exception コード: " + argInt.ToString() + " 管理者に連絡してください.";
            }
            return reStr;
        }


        /// <summary>
        ///  一括表示用データ抽出
        /// </summary>
        /// <param name="lang"></param>
        /// <param name="argInt"></param>
        /// <returns></returns>
        public static string[,] GetMsgArr(string lang, int argInt)
        {
            string[,] reArr = new string[1,1]; //初期化  reArr[0,0]=null

            switch (lang)
            {
                case "ja-jp":
                    if (Msg_jajp.MsgArr.ContainsKey(argInt)) 
                    {
                        reArr = Msg_jajp.MsgArr[argInt];    //日本語パラメータの取得
                    }                        
                    break;

                case "en-us":
                    if (Msg_enus.MsgArr.ContainsKey(argInt))
                    { reArr = Msg_enus.MsgArr[argInt]; }    //英語パラメータの取得
                    else 
                    { reArr = Msg_jajp.MsgArr[argInt]; }    //デフォルト - 日本語パラメータの取得
                    break;

                case "zh-cn":
                    if (Msg_zhcn.MsgArr.ContainsKey(argInt))
                    { reArr = Msg_zhcn.MsgArr[argInt]; }    //中国語パラメータの取得
                    else
                    { reArr = Msg_jajp.MsgArr[argInt]; }    //デフォルト - 日本語パラメータの取得
                    break;

                default:
                    if (Msg_jajp.MsgArr.ContainsKey(argInt)) 
                    {
                        reArr = Msg_jajp.MsgArr[argInt];    //デフォルト - 日本語パラメータの取得
                    }                        
                    break;
            }

            // Not Found Message
            if (reArr[0, 0] == null) { reArr[0, 0] = "データが定義されていません."; }

            return reArr;
        }


    }
}
