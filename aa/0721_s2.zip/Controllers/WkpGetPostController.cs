﻿using demo1.Common;
using Microsoft.AspNetCore.Mvc;
using System.Data;
using System.Reflection;
using demo1.CodeMsg;
using System.Diagnostics;
using Microsoft.AspNetCore.DataProtection.KeyManagement;

namespace demo1.Controllers
{

    /// <summary>
    /// Author: Kamikawa
    /// Date: 2023-03
    /// LastEditTime: 
    /// Description: 
    /// 
    /// </summary>
    public class WkpGetPostController : Controller
    {

        public static int _ClassID;
        //private readonly IHttpContextAccessor _httpContextAccessor;

        public WkpGetPostController()
        {
            _ClassID = ClassCode.GetClassId(typeof(WkpGetPostController));

            //IHttpContextAccessor httpContextAccessor
            //_httpContextAccessor = httpContextAccessor;
        }


        /// <summary>
        /// http://localhost:52827/WkpGetPost/DoGet?arg1=2&arg2=4
        ///  共通 GET Interface
        /// </summary>
        /// <returns></returns>
        public ActionResult<string> DoGet()
        {
            string reqType = Request.Method;    //POST / GET
            //Only accept POST ... or Return 404
            if ("GET".Equals(reqType) == false) { return NotFound(); }

            string strRP = Request.Path;
            string strRQ = Request.QueryString.ToString();
            Trace.WriteLine(strRP);
            Trace.WriteLine(strRQ);

            string lang = "";  // 初期値
            if (RouteData.Values.ContainsKey("lang"))
            {
                lang = UtilityFunc.ObjToString(RouteData.Values["lang"]);                
            }
            // Route 中に{lang=def-lang} 
            if (("def-lang".Equals(lang) == true) || (string.IsNullOrEmpty(lang) == true))
            {
                return Redirect("/ja-jp" + Request.Path + Request.QueryString.ToString());
            }
            //if ("def-lang".Equals(lang)) { return Redirect("/ja-jp" + Request.Path); }


            //http://localhost:52827/WkpGetPost/DoGet?ddl=NYUKA
            //Test get DDL list data
            if (Request.Query.Keys.Contains("ddl"))            
            {
                demo1.Models.TestModels.GetddlData gdd = new();
                gdd.DoGetFunc(Request.Query["ddl"].ToString());

                JobjOut reJobject = gdd._JobjOut;

                // PostProcessStep() 実行 OK -- 返信用 Jobjectの設定
                reJobject.datetime = DateTime.Now.ToString("yyyyMMddHHmmss");
                reJobject.code = gdd._Ur._ReInt.ToString(); // 0
                //reJobject.msg = ""; // 設定不要
                reJobject.msgd += gdd._Ur.GetAllDebugExceptionMsg();
                reJobject.lang = lang;


                UtilityReturn ur = new();
                // Generate the Response Json string
                ur = JsonFunc.ObjectToJson(reJobject, out string responseStr);
                if (ur._ReInt != 0)
                {
                    // Json 変換 Error 直接 JsonString を返信する
                    string eStr = "{datetime: \"" + DateTime.Now.ToString("yyyyMMddHHmmss") + "\",code: \"" + (-(_ClassID + 977)).ToString() + "\",msg: \"システム Debug/Exception コード: \"" + (-(_ClassID + 977)).ToString() + "\" 管理者に連絡してください.\",msgd: \"\",lang: \"ja-jp\",dl1max: \"\",dl2max: \"\",dl3max: \"\",dl1: [],dl2: [],dl3: []}";
                    return eStr;
                }

                // Json 変換 OK -- Return Json string
                return responseStr;
            }



            //Request.Query --> Parameters on URL Link
            //http://localhost:52827/WkpGetPost/DoGet?arg1=2&arg2=4

            //Dictionary<string, string> dReq = new Dictionary<string, string>();
            string reStr = "lang : " + lang + "\r\n";
            reStr += "url : " + strRP + strRQ + "\r\n";
            foreach (string qkey in Request.Query.Keys)
            {
                //Trace.WriteLine(qkey + ":" + Request.Query[qkey]);
                reStr += (qkey + " : " + Request.Query[qkey]) + "\r\n";
                //dReq.Add(qkey, Request.Query[qkey].ToString());
            }

            return reStr;
        }






        /// <summary>
        /// http://localhost:52827/WkpGetPost/DoFormPost
        ///  普通 Form POST Interface
        /// </summary>
        /// <param name="collection"></param>
        /// <returns></returns>
        public IActionResult DoFormPost([FromForm] IFormCollection collection)
        {
            string reqType = Request.Method;    //POST / GET
            //Only accept POST ... or Return 404
            if ("POST".Equals(reqType) == false) { return NotFound(); }

            //string reStr = "";
            foreach (string key in collection.Keys) 
            {
                //reStr += "Name: " + key + ", Value: " + collection[key] + "\r\n";
                Trace.WriteLine(key + ":" + collection[key]);
            }

            ViewBag.Arg1 = "From Post Test";  //Pass Value to View Page
            ViewBag.Arg2 = collection;  //Pass Value to View Page

            return View();
        }


        /// <summary>
        /// http://localhost:52827/WkpGetPost/DoPost
        ///  共通 POST Interface
        /// </summary>
        /// <returns></returns>
        public ActionResult<string> DoPost()
        {
            string reqType = Request.Method;    //POST / GET
            //Only accept POST ... or Return 404
            if ("POST".Equals(reqType) == false) { return NotFound(); }


            //Get IP address
            //string ipV4 = "", ipV6 = "";
            ////IHttpContextAccessor httpContextAccessor;
            //if (_httpContextAccessor.HttpContext!=null)
            //{
            //    var ipAdd = _httpContextAccessor.HttpContext.Connection.RemoteIpAddress;
            //    if (ipAdd!=null) 
            //    {                    
            //        ipV6 = ipAdd.ToString();
            //        ipV4 = ipAdd.MapToIPv4().ToString();
            //    }                
            //}            

            //string ControllerName = ControllerContext.ActionDescriptor.ControllerName;
            //string ActionName = ControllerContext.ActionDescriptor.ActionName;

            string lang = "ja-jp";  // 初期値
            if (RouteData.Values.ContainsKey("lang")) 
            {
                string? langR = UtilityFunc.ObjToString(RouteData.Values["lang"]);
                if (string.IsNullOrEmpty(langR) == false) 
                {
                    // Route 中に{lang=def-lang} があれば、 langの値を更新する
                    if ("def-lang".Equals(langR) == false) { lang = langR; }
                }
            }            

            //収集 POST HeaderData -- true/false
            //収集 POST RequestData -- true/false
            //JobjIn.option =  | showheaders | showrequest | 
            bool ifShowheaders = false;
            bool ifShowrequest = false;

//#if DEBUG
//            // JsonParam の msgd 中に POSTデータを返信する
//            ifShowheaders = true;
//            ifShowrequest = true;
//#else
//    ifShowheaders = false;
//    ifShowrequest = false;
//#endif

            // Get Body Data
            StreamReader stream = new StreamReader(Request.Body);
            string bodyStr = stream.ReadToEndAsync().GetAwaiter().GetResult();

            // Call Model use Reflection
            JobjOut reJobject = new();
            UtilityReturn ur = new();
            string langPost = "";
            ur = PostProcessStep(bodyStr, out ifShowheaders, out ifShowrequest, out langPost, out reJobject);

            // PostProcessStep() 実行後　以下の datetime, msgd は設定必須
            reJobject.datetime = DateTime.Now.ToString("yyyyMMddHHmmss");
            reJobject.msgd += ur.GetAllDebugExceptionMsg();

            if (ur._ReInt != 0)
            {
                ifShowheaders = true;
                ifShowrequest = true;

                // PostProcessStep() 実行 Error -- 返信用 Jobjectの設定
                //reJobject.datetime = DateTime.Now.ToString("yyyyMMddHHmmss");  -- PostProcessStep() 実行後 設定済
                reJobject.code = ur._ReInt.ToString();
                reJobject.msg = UtilityMsg.GetMsgData(lang, ur._ReInt);
                //reJobject.msgd = ur.GetAllDebugExceptionMsg();  -- PostProcessStep() 実行後 設定済
                reJobject.lang = lang;
            }

            // PostParameter中のlang値は優先
            if (string.IsNullOrEmpty(langPost) == false)
            {
                if ("def-lang".Equals(langPost) == false) { lang = langPost; }
            }

            string allHeadBody = "";
            if (ifShowheaders) // Debug 時
            {
                //Get Headers Data
                allHeadBody += Request.Method + "\r\n";
                //allHeadBody += "IP" + ":" + ipV4 + "\r\n";
                foreach (string key in Request.Headers.Keys)
                {
                    allHeadBody += key + ":" + Request.Headers[key].ToString() + "\r\n";
                }
                allHeadBody += " ------------- Headers Data End ------------- " + "\r\n";
                //Trace.WriteLine(alls);
            }

            if (ifShowrequest) // Debug 時
            {
                allHeadBody += bodyStr + "\r\n";
                allHeadBody += "------------- Request Body Data End -------------" + "\r\n";
                //Trace.WriteLine("body content:" + bodyStr);
            }

            //  Add Debug Data(Header + Body)
            if (string.IsNullOrEmpty(allHeadBody) == false)
            {
                reJobject.msgd = allHeadBody + "\r\n\r\n" + reJobject.msgd;
            }

            // PostProcessStep() 実行 OK -- 返信用 Jobjectの設定
            //reJobject.datetime = DateTime.Now.ToString("yyyyMMddHHmmss");  -- PostProcessStep() 実行後 設定済
            reJobject.code = ur._ReInt.ToString(); // 0
            //reJobject.msg = ""; // 設定不要
            //reJobject.msgd += ur.GetAllDebugExceptionMsg();  -- PostProcessStep() 実行後 設定済
            reJobject.lang = lang;

            // Generate the Response Json string
            ur = JsonFunc.ObjectToJson(reJobject, out string responseStr);
            if (ur._ReInt != 0)
            {
                // Json 変換 Error 直接 JsonString を返信する
                string eStr = "{datetime: \"" + DateTime.Now.ToString("yyyyMMddHHmmss") + "\",code: \"" + (-(_ClassID + 988)).ToString() + "\",msg: \"システム Debug/Exception コード: \"" + (-(_ClassID + 988)).ToString() + "\" 管理者に連絡してください.\",msgd: \"\",lang: \"ja-jp\",dl1max: \"\",dl2max: \"\",dl3max: \"\",dl1: [],dl2: [],dl3: []}";
                return eStr;
            }

            // Json 変換 OK -- Return Json string
            return responseStr;

            // Generate return Dictionary
            //Dictionary<string, string> dReq = new Dictionary<string, string>();
            //dReq.Add("RequestType", Request.Method);
            //foreach (string qkey in Request.Headers.Keys)
            //{
            //    dReq.Add(qkey, Request.Headers[qkey].ToString());
            //}
            //dReq.Add("Body", bodyStr);

            //string jsonString = JsonSerializer.Serialize<Dictionary<string, string>>(dReq);
            //return jsonString;
        }


        /// <summary>
        /// DoPost 用 Reflection Call Module
        /// </summary>
        /// <param name="postBodyStr"></param>
        /// <param name="ifShowheaders"></param>
        /// <param name="ifShowrequest"></param>
        /// <param name="outLang"></param>
        /// <param name="outJ"></param>
        /// <returns></returns>
        private UtilityReturn PostProcessStep(string postBodyStr, out bool ifShowheaders, out bool ifShowrequest, out string outLang, out JobjOut outJ)
        {
            UtilityReturn ur = new();
            ifShowheaders = false;
            ifShowrequest = false;
            outLang = "";
            outJ = new();
            int reInt = -100;

            try
            {
                // 1. POST(Json string) 変換to  ObjectClass & DataSet
                JobjIn JclassIn;
                DataSet dsIn;
                ur = JsonFunc.GetRequestDataFromJsonString(postBodyStr, out JclassIn, out dsIn);
                if (ur._ReInt != 0) { return ur; }

                // set switch  by  option = showheaders | showrequest | 
                if (JclassIn.option.IndexOf("showheaders") >= 0) { ifShowheaders = true; }
                if (JclassIn.option.IndexOf("showrequest") >= 0) { ifShowrequest = true; }

                // set lang from POST parameter
                outLang = JclassIn.lang;

                // 2. Get ClassName and MethodName  By ModelName
                string clsName = "";
                string funcName = "";
                reInt = InstClassFunc.GetClassMethod(JclassIn.module, out clsName, out funcName);
                if (reInt != 0)
                {
                    ur.AddExceptionMsg("InstClassFunc.GetClassMethod() Error. ");
                    return ur.RetuenCode(_ClassID + 31);
                }

                // 3. Create Instance Class By ClassName and Set ObjectClass & DataSet
                ClassInst<PostCaseCls> myInst = new();
                reInt = myInst.CreateInst(clsName);
                if (reInt != 0)
                {
                    ur.AddExceptionMsg("ClassInst<T>.CreateInst() Error. ");
                    return ur.RetuenCode(_ClassID + 32);
                }
                myInst.instClass._JobjIn = JclassIn;        // Set PostIN JsonClass into Model
                myInst.instClass._DataSetIn = dsIn;         // Set PostIN DataSet into Model

                // 4. Call Method
                MethodInfo? mtdInfo = myInst.instType.GetMethod(funcName);
                if (mtdInfo is null)
                {
                    ur.AddExceptionMsg("myInst.instType.GetMethod() Error. ");
                    return ur.RetuenCode(_ClassID + 33);
                }
                mtdInfo.Invoke(myInst.instClass, null);

                // 5. After call Method  determine the UtilityReturn._ReInt
                if (myInst.instClass._Ur._ReInt != 0)
                {
                    // Error --> return _Ur
                    return myInst.instClass._Ur;
                }

                // Set output JobjOut
                outJ = myInst.instClass._JobjOut;
                return ur.RetuenCode(0);
            }
            catch (Exception ex)
            {
                ur.AddExceptionMsg("Exception Class: " + "WkpGetPostController - PostProcessStep");
                ur.AddExceptionMsg("Exception: " + ex.Message);
                if (ex.InnerException != null)
                {
                    ur.AddExceptionMsg("InnerException: ");
                    ur.AddExceptionMsg(String.Concat(ex.InnerException.StackTrace, ex.InnerException.Message));
                }
                return ur.RetuenCode(-(_ClassID + 999));
            }
        }


    }
}
