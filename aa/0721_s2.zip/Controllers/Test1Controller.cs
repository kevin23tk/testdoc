﻿using demo1.Models.TestModels;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using demo1.CodeMsg;
using System.Reflection;

namespace demo1.Controllers
{
    /// <summary>
    /// Author: Kamikawa
    /// Date: 2023-03
    /// LastEditTime: 
    /// Description: 
    /// 
    /// </summary>
    public class Test1Controller : Controller
    {

        public static int _ClassID;
        public Test1Controller() 
        {
            _ClassID = ClassCode.GetClassId(typeof(Test1Controller));
        }


        public ActionResult<string> Hello()
        {
            return "HELLO2！";
        }

        /// <summary>
        /// Call Action
        /// http://localhost:52827/Test1/HelloAct
        /// [Route("{lang=ja}/Test1/HelloAct/{id?}")] --> http://localhost:52827/xxx/Test1/HelloAct
        /// [Route("[controller]/[action]")]
        /// </summary>
        /// <returns></returns>
        public ActionResult<string> HelloAct(string lang)
        {
            // 下は多言語対応のテスト
            Trace.WriteLine(_ClassID);

            //Request.QueryString.ToString();

            if ("def-lang".Equals(lang))
            {
                return Redirect("/ja-jp" + Request.Path);
            }

            Trace.WriteLine(lang);
            string a = Request.Path;
            string bb = Request.QueryString.ToString();

            Trace.WriteLine(a);
            Trace.WriteLine(bb);
            //Trace.WriteLine(Url.RouteUrl.t);
            //Url.RouteUrl

            if ("ja-jp".Equals(lang)) { return "こんにちは！"; }
            if ("en-us".Equals(lang)) { return "Hello world."; }
            if ("zh-cn".Equals(lang)) { return "中国语 简体字 中华人民!"; }
            if ("zh-tw".Equals(lang)) { return "中国語 繁体字 中華人民!"; }
            return "こんにちは！";
        }


        /// <summary>
        /// Call Action
        /// http://localhost:52827/Test1/GetTime
        /// </summary>
        /// <returns></returns>        
        public JsonResult GetTime()
        {
            return Json(new {time= DateTime.Now.ToString() });
        }


        /// <summary>
        /// Call Action
        /// http://localhost:52827/Test1/Add?arg1=2&arg2=4
        /// </summary>
        /// <returns></returns>
        public JsonResult Add(int arg1, int arg2)
        {
            string sTrace = "";
            sTrace += Request.Query["arg1"].ToString() + "\r\n";
            sTrace += Request.Query["arg2"].ToString() + "\r\n";
            Trace.WriteLine(sTrace);

            return Json(new { Result = arg1+ arg2 });
        }


        /// <summary>
        /// Call Action
        /// http://localhost:52827/Test1/Getid/57
        /// 
        /// app.MapControllerRoute(
        /// name: "default",
        /// pattern: "{controller=Home}/{action=Index}/{id?}");
        /// </summary>
        /// <returns></returns>
        public ActionResult<string> Getid(int id)
        {
            
            //return Json(new { ID = id });
            return "ID: " + id.ToString();
        }

        /// <summary>
        /// Call Action
        /// http://localhost:52827/Test1/Page1/23
        /// 
        /// Must Create a View at Views/Test1/Page1.cshtml
        /// And will use Views/Shared/_Layout.cshtml   put HTML into the @RenderBody()
        /// 
        /// Modify _Layout.cshtml
        /// <a class="nav-link text-dark" asp-area="" asp-controller="Test1" asp-action="Page1" asp-route-id="8">Test Page1</a>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public IActionResult Page1(int id)
        {
            string reqType = Request.Method;    //POST / GET
            if ("POST".Equals(reqType) == true) { return NotFound(); }

            id *= id;            
            ViewBag.aaa = id;  //Pass Value to View Page
            ViewData["vdid"] = id;

            var mod1 = new Test1Page1Model();
            mod1.MyArg1 = id;
            return View(mod1);
        }

        /// <summary>
        /// Call Action
        /// http://localhost:52827/Test1/Page2/23
        /// 
        /// Not use Views/Shared/_Layout.cshtml
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public IActionResult Page2(int id)
        {
            return View();
        }


        public IActionResult Page3()
        {
            DbTestModel dtm =new();
            dtm.GetData();
            return View(dtm);
        }



        public IActionResult Index()
        {
            return View();
        }
    }
}
