﻿using Microsoft.AspNetCore.Mvc;

namespace demo1.Controllers
{
    public class DefaultController : Controller
    {
        public ActionResult<string> DefaultAction(string lang)
        {
            //// 指定のURLにリダイレクト
            //return Redirect("https://localhost:44335/NK0022a.html");

            //// ほかのActionにリダイレクト
            //return RedirectToAction("OtherAction", "OtherController");
            return RedirectToAction("Index", "Nyuka");


            //if ("def-lang".Equals(lang))
            //{
            //    return Redirect("/ja-jp" + Request.Path);
            //}

            //return "Hello world.";
        }
    }
}
