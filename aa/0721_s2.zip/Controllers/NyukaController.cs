﻿using demo1.CodeMsg;
using demo1.Common;
using demo1.Models.Nyuka;
using Microsoft.AspNetCore.Mvc;

namespace demo1.Controllers
{
    /// <summary>
    /// Author: Kamikawa
    /// Date: 2023-03
    /// LastEditTime: 
    /// Description: 
    /// 
    /// </summary>
    public class NyukaController : Controller
    {

        public static int _ClassID;
        public NyukaController()
        {
            _ClassID = ClassCode.GetClassId(typeof(NyukaController));
        }
                
        /// <summary>
        /// Index demo 多言語表示
        /// </summary>
        /// <returns></returns>
        public IActionResult Index()
        {
            string lang = "ja-jp";  // 初期値
            if (RouteData.Values.ContainsKey("lang"))
            {
                string? langR = UtilityFunc.ObjToString(RouteData.Values["lang"]);
                if (string.IsNullOrEmpty(langR) == false)
                {
                    // Route 中に{lang=def-lang} があれば、 langの値を更新する
                    if ("def-lang".Equals(langR) == false)
                    { lang = langR; }
                    else
                    {
                        return Redirect("/ja-jp" + Request.Path);
                    }
                }
            }

            NyukaMdisp nm = new();
            string[,] dLabel = UtilityMsg.GetMsgArr(lang, _ClassID + 3);   //表示用 Label01
            nm.Dic_Label01 = UtilityFunc.GetDictionaryFromArray(dLabel); // 表示用 Dictionary<string, string>
            nm.Page_Title = "入荷・入庫 Title";

            return View(nm);
        }

        /// <summary>
        /// 履歴画面
        /// </summary>
        /// <returns></returns>
        public IActionResult Rireki()
        {
            return View();
        }

        /// <summary>
        /// 予定画面
        /// </summary>
        /// <returns></returns>
        public IActionResult Yotei()
        {

            string lang = "ja-jp";  // 初期値
            if (RouteData.Values.ContainsKey("lang"))
            {
                string? langR = UtilityFunc.ObjToString(RouteData.Values["lang"]);
                if (string.IsNullOrEmpty(langR) == false)
                {
                    // Route 中に{lang=def-lang} があれば、 langの値を更新する
                    if ("def-lang".Equals(langR) == false)
                    { lang = langR; }
                    else
                    {
                        return Redirect("/ja-jp" + Request.Path);
                    }
                }
            }

            NyukaMdisp nm = new();
            string[,] dLabel = UtilityMsg.GetMsgArr(lang, _ClassID + 3);   //表示用 Label01
            nm.Dic_Label01 = UtilityFunc.GetDictionaryFromArray(dLabel); // 表示用 Dictionary<string, string>
            nm.Page_Title = "入荷予定 Title";


            return View(nm);
        }

        /// <summary>
        /// 実績画面
        /// </summary>
        /// <returns></returns>
        public IActionResult Ziseki()
        {
            return View();
        }

        
    }
}
