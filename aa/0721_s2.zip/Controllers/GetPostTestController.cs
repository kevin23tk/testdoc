﻿using Microsoft.AspNetCore.DataProtection.KeyManagement;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System.Diagnostics;
using System.Text.Json;

namespace demo1.Controllers
{
    /// <summary>
    /// Author: Kamikawa
    /// Date: 2023-03
    /// LastEditTime: 
    /// Description: 
    /// 
    /// </summary>
    public class GetPostTestController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }


        public JsonResult TestGet()
        {
            string sHeaderProp = "";
            foreach (string hkey in Request.Headers.Keys)
            {
                sHeaderProp += hkey + ":" + Request.Headers[hkey].ToString() + "\r\n";
            }            
            Trace.WriteLine(sHeaderProp);


            //Request.Query --> Parameters on URL Link
            //http://localhost:52827/Test1/Add?arg1=2&arg2=4


            Dictionary<string, string> dReq = new Dictionary<string, string>();
            foreach (string qkey in Request.Query.Keys)
            {
                dReq.Add(qkey, Request.Query[qkey].ToString());
            }

            dReq.Add("HEAD", sHeaderProp);
            string jsonString = JsonSerializer.Serialize<Dictionary<string, string>>(dReq);

            //var jj = Json(new { a1 = Request.Query["name"].ToString(), a2 = Request.Query["gender"].ToString(), a3 = Request.Query["age"].ToString() });

            var jj = Json(jsonString);
            return jj;
        }


        public JsonResult TestPost([FromForm] IFormCollection collection)
        {
            try
            {
                string sHeaderProp = "";
                foreach (string hkey in Request.Headers.Keys)
                {
                    sHeaderProp += hkey + ":" + Request.Headers[hkey].ToString() + "\r\n";
                }
                Trace.WriteLine(sHeaderProp);

                string name = collection["name"];
                string gender = collection["gender"];
                string age = collection["age"];
                //return $"姓名:{name}\n性别:{gender}\n年龄:{age}";
                //return Json(new { 名前 = name, 性別 = gender, 年齢 = age });
                return Json(new { b1 = name, b2 = gender, b3 = age });
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return Json(new { time = DateTime.Now.ToString() });
            }
            
        }


        //http://localhost:52827/GetPostTest/TestPost2
        public ActionResult<string> TestPost2()
        {
            string reqType = Request.Method;    //POST / GET
            //Only accept POST ... or Return 404
            if ("POST".Equals(reqType) == false) { return NotFound(); }

            string alls = Request.Method + "\r\n";

            foreach (string key in Request.Headers.Keys)
            {
                alls += key + ":" + Request.Headers[key].ToString()+"\r\n";
                //Console.WriteLine(key +":"+ Request.Headers[key].ToString());
            }
            Trace.WriteLine(alls);

            //string content = Request.Body..Content.ReadAsStringAsync().Result;
            //using (StreamReader reader = new StreamReader(Request.Body))
            //{
            //    bodyStr = reader.ReadToEnd();
            //    //bodyStr = reader.ReadToEndAsync().ConfigureAwait(false);
            //}           

            //var bodyStr = string.Empty;
            StreamReader stream = new StreamReader(Request.Body);
            string bodyStr = stream.ReadToEndAsync().GetAwaiter().GetResult();
            //_logger.LogDebug("body content:" + body);
            //base.OnActionExecuting(context);

            Trace.WriteLine("body content:" + bodyStr);

            // Generate return Dictionary
            Dictionary<string, string> dReq = new Dictionary<string, string>();
            dReq.Add("RequestType", Request.Method);
            foreach (string qkey in Request.Headers.Keys)
            {
                dReq.Add(qkey, Request.Headers[qkey].ToString());
            }
            dReq.Add("Body", bodyStr);

            string jsonString = JsonSerializer.Serialize<Dictionary<string, string>>(dReq);
            return jsonString;
        }
    }



}
