﻿using Microsoft.AspNetCore.DataProtection.KeyManagement;
using System.Data;

namespace demo1.Common
{

    /// <summary>
    /// Author: Kamikawa
    /// Date: 2023-03
    /// LastEditTime: 
    /// Description: 
    /// 
    /// </summary>
    public class UtilityFunc
    {

        /// <summary>  
        /// DataTable typeof(string) の作成 Struct Only
        /// </summary>  
        /// <param name="colNames"></param> 
        /// <returns>return DataTable</returns>  
        /// <remarks></remarks>  
        public static DataTable GenDtOnlyStruct(string[] colNames)
        {
            DataTable dt = new();

            foreach (string colName in colNames)
            {
                dt.Columns.Add(colName, typeof(string));
            }
            return dt;
        }


        /// <summary>
        /// 判断 DataTable Empty or Not
        /// </summary>
        /// <param name="argDt"></param>
        /// <returns></returns>
        public static bool IsEmptyDataTable(DataTable argDt)
        {
            if (argDt is null) { return true; }
            if (argDt.Rows.Count <=0 ) { return true; }
            return false;
        }


        /// <summary>
        ///  Convert Object to String (Avoid null)
        /// </summary>
        /// <param name="argO"></param>
        /// <returns></returns>
        public static string ObjToString(Object? argO)
        {
            if (argO is null)
            { return ""; }
            else 
            { 
                string? s = argO.ToString();
                if (s == null) { s = ""; }
                return s; 
            } 
        }

        /// <summary>
        /// 多言語処理用 表示用データの取得
        /// </summary>
        /// <param name="strArr"></param>
        /// <param name="strName"></param>
        /// <returns></returns>
        public static string GetDisplayStr(string[,] strArr, string strName)
        {
            for (int i=0;i< strArr.GetLength(0);i++) 
            {
                if (strName.Equals(strArr[i,0])) 
                {
                    return strArr[i, 1];
                }
            }
            return "";
        }

        /// <summary>
        /// string 配列 --> Dictionary<string, string>
        /// </summary>
        /// <param name="strArr"></param>
        /// <returns></returns>
        public static Dictionary<string, string> GetDictionaryFromArray(string[,] strArr)
        {
            Dictionary<string, string> rd = new();
            for (int i = 0; i < strArr.GetLength(0); i++)
            {
                rd.Add(strArr[i,0], strArr[i, 1]);
            }
            return rd;
        }

    }
}
