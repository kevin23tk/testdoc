﻿namespace demo1.Common
{


    /// <summary>
    /// Author: Kamikawa
    /// Date: 2023-03
    /// LastEditTime: 
    /// Description: 
    /// 
    /// </summary>
    public class EnvConst
    {

        //public static readonly string DB_CONSTR = "Host=BS-SV-V221WEB01;Port=5432;User Id=kepdemo;Password=kepdemo;Database=kepdemo;";

        //public static readonly string DB_CONSTR = "Host=BS-SV-V221WEB01;Port=5432;User Id=postgres;Password=postgres;Database=dev_db;";
        public static readonly string DB_CONSTR = "Host=BS-SV-V221WEB01;Port=5432;User Id=dev05;Password=dev05;Database=dev_db;";


        // Post requestのHead Dataを収集し、Responseに返信します.
        //public static bool IF_CONTROLLER_COLLECT_POSTHEAD = false;


    }
}
