﻿using System.Text;

namespace demo1.Common
{

    /// <summary>
    /// Author: Kamikawa
    /// Date: 2023-03
    /// LastEditTime: 
    /// Description: 
    /// 
    /// </summary>
    public class UtilityReturn
    {

        /// <summary>
        /// Professional Setting
        /// Should Set a Link
        /// http://localhost:52827/WkpGetPost/UtilityReturnSetting
        /// To set _IF_WRITE_DEBUG_MSG = true || false
        /// </summary>
        public static bool _IF_WRITE_DEBUG_MSG = false;


        // Return Values
        public int _ReInt;                                  // Return Code
        private StringBuilder _SbdShowMsg = new();          // お客様へ表示用MSG
        private StringBuilder _SbdDebugMsg = new();         // DEBUG 調査用 MSG
        private StringBuilder _SbdExceptionMsg = new();     // Error + Exception 用 MSG

        /// <summary>
        /// 初期化 MSG DATA
        /// </summary>
        public UtilityReturn() 
        {
            _ReInt = -100;

            _SbdShowMsg = new();
            _SbdDebugMsg = new();
            _SbdExceptionMsg = new();
        }

        /// <summary>
        /// Set DEBUG 調査用 MSG
        /// </summary>
        /// <param name="argStr"></param>
        public void AddDebugMsg(string argStr) 
        {
#if DEBUG
            _SbdDebugMsg.Append(argStr + "\r\n");
#else
            if (_IF_WRITE_DEBUG_MSG == true) 
            {
                _SbdDebugMsg.Append(argStr + "\r\n");
            }
#endif
        }


        /// <summary>
        /// Set お客様へ表示用MSG
        /// </summary>
        /// <param name="argStr"></param>
        public void AddShowMsg(string argStr)
        {
            _SbdShowMsg.Append(argStr + "\r\n");
        }


        /// <summary>
        /// Set Exception 用 MSG
        /// 
        /// catch (Exception ex)
        /// {
        ///     ur.AddExceptionMsg("Exception: " + ex.Message);
        ///     if (ex.InnerException != null)
        ///     {
        ///         ur.AddExceptionMsg("InnerException: ");
        ///         ur.AddExceptionMsg(String.Concat(ex.InnerException.StackTrace, ex.InnerException.Message));
        ///     }
        ///     return ur.RetuenCode(-(_ClassID + 50));
        /// }
        /// 
        /// </summary>
        /// <param name="argStr"></param>
        public void AddExceptionMsg(string argStr)
        {
            _SbdExceptionMsg.Append(argStr + "\r\n");
        }

        /// <summary>
        /// Get DEBUG 調査用 MSG
        /// </summary>
        /// <returns></returns>
        public string GetAllDebugMsg()
        {
            return _SbdDebugMsg.ToString();
        }

        /// <summary>
        /// Get お客様へ表示用MSG
        /// </summary>
        /// <returns></returns>
        public string GetAllShowMsg()
        {
            return _SbdShowMsg.ToString();
        }

        /// <summary>
        /// Get Exception 用 MSG
        /// </summary>
        /// <returns></returns>
        public string GetAllExceptionMsg()
        {
            return _SbdExceptionMsg.ToString();
        }


        /// <summary>
        /// Get DEBUG + Exception 用 MSG
        /// </summary>
        /// <returns></returns>
        public string GetAllDebugExceptionMsg()
        {
            string reStr = "";
            string reStr1 = _SbdDebugMsg.ToString();
            string reStr2 = _SbdExceptionMsg.ToString();

            if (string.IsNullOrEmpty(reStr1) == false) 
            {
                reStr += reStr1;
            }

            if (string.IsNullOrEmpty(reStr2) == false)
            {
                if (string.IsNullOrEmpty(reStr) == false)
                {
                    reStr2 = "\r\n\r\n" + reStr2;
                }

                reStr += reStr2;
            }

            return reStr;
        }


        /// <summary>
        ///  For easy using return
        ///  return ur.RetuenCode(0);
        ///  return ur.RetuenCode(_ClassID +11)
        /// </summary>
        /// <param name="argInt"></param>
        /// <returns></returns>
        public UtilityReturn RetuenCode(int argInt)
        {
            this._ReInt= argInt;
            return this;
        }


        /// <summary>
        ///  Merge 2 UtilityReturn
        ///  
        ///  Function A()
        ///  {
        ///     UtilityReturn ur1 = new();
        ///     ur1.AddDebugMsg("Function A msg");
        ///     Call Function B() --> return ur2
        ///     return ur1.RetuenMerg(ur2);
        ///  } 
        /// </summary>
        /// <param name="argUr"></param>
        /// <returns></returns>
        public UtilityReturn RetuenMerge(UtilityReturn argUr)
        {
            string strD = argUr.GetAllDebugMsg();
            string strE = argUr.GetAllExceptionMsg();

            this.AddDebugMsg(strD);
            this.AddExceptionMsg(strE);
            this._ReInt = argUr._ReInt;
            return this;
        }


    }
}
