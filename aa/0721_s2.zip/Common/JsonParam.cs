﻿namespace demo1.Common
{

    /// <summary>
    /// Author: Kamikawa
    /// Date: 2023-03
    /// LastEditTime: 
    /// Description: 
    /// 
    /// </summary>
    public class JsonParam { }


    //    {
    //      datetime: "2023-02-28 10:38:56",
    //      loginid: "L001",
    //      devid: "D001",
    //      tkid: "T001",
    //      snid: "S001",
    //      module: "A001",
    //      lang: "ja-jp",
    //      option: "showheaders|showrequest",
    //      dl1max: "1",
    //      dl2max: "",
    //      dl3max: "",
    //      dl4max: "",
    //      dl5max: "",
    //      dl1: [
    //            { c: ["name", "gender", "age"]}, 
    //            { c: ["田中", "男", "35"] }
    //           ],
    //      dl2: [],
    //      dl3: [],
    //      dl4: [],
    //      dl5: []
    //    }



    /// <summary>
    ///  Json Data Format POST from Client
    ///  2023-6-27 add dl4 dl5  
    ///  dl1max = DataTable.rowcount
    ///  Json dl1.rowcount = dl1max + 1(title row)
    /// </summary>
    public class JobjIn
    {
        public string datetime = "";
        public string loginid = "";
        public string devid = "";
        public string tkid = "";
        public string snid = "";
        public string module = "";
        public string lang = "";
        public string option = "";      // showheaders | showrequest | 
        public string dl1max = "";
        public string dl2max = "";
        public string dl3max = "";
        public string dl4max = "";
        public string dl5max = "";
        public Data_dl[] dl1 = new Data_dl[0];
        public Data_dl[] dl2 = new Data_dl[0];
        public Data_dl[] dl3 = new Data_dl[0];
        public Data_dl[] dl4 = new Data_dl[0];
        public Data_dl[] dl5 = new Data_dl[0];
    }



    //        {
    //          datetime: "2023-02-28 10:38:56",
    //          code: "0",
    //          msg: "Msg display for Customer ",
    //          msgd: "Here is the debug + Exception Msg ",
    //          lang: "ja-jp",
    //          dl1max: "1",
    //          dl2max: "",
    //          dl3max: "",
    //          dl4max: "",
    //          dl5max: "",
    //          dl1: [
    //                { c: ["name", "gender", "age"]}, 
    //                { c: ["田中", "男", "35"] }
    //               ],
    //          dl2: [],
    //          dl3: [],
    //          dl4: [],
    //          dl5: []
    //        }


    /// <summary>
    /// Json Data Format Return to Client
    /// 2023-6-27 add dl4 dl5  
    /// dl1max = DataTable.rowcount
    /// Json dl1.rowcount = dl1max + 1(title row)
    /// </summary>
    public class JobjOut
    {
        public string datetime = "";
        public string code = "";
        public string msg = "";
        public string msgd = "";        // debug + Exception Msg
        public string lang = "";
        public string dl1max = "";
        public string dl2max = "";
        public string dl3max = "";
        public string dl4max = "";
        public string dl5max = "";
        public Data_dl[] dl1 = new Data_dl[0];
        public Data_dl[] dl2 = new Data_dl[0];
        public Data_dl[] dl3 = new Data_dl[0];
        public Data_dl[] dl4 = new Data_dl[0];
        public Data_dl[] dl5 = new Data_dl[0];
    }

    /// <summary>
    ///  data list -- the first row is data column
    /// </summary>
    public class Data_dl
    {
        public string[] c;

        public Data_dl() 
        {
            c = new string[0];  // new string[0]  Array.Empty<string>()
        }
        public Data_dl(int colMax)
        {
            c = new string[colMax];
        }
    }




}
