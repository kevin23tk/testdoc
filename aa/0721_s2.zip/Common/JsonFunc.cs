﻿using System.Data;

namespace demo1.Common
{

    /// <summary>
    /// Author: Kamikawa
    /// 
    /// Date: 2023-03
    /// LastEditTime: 
    /// Description: 
    /// 
    /// </summary>
    public class JsonFunc
    {

        public static int _ClassID = ClassCode.GetClassId(typeof(JsonFunc));


        /// <summary>
        /// Json String ---> Object
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="jStr"></param>
        /// <param name="outT"></param>
        /// <returns></returns>
        public static UtilityReturn JsonToObject<T>(string jStr, out T outT) where T:new()
        {
            outT = new(); //default(T);
            UtilityReturn ur = new();

            try
            {
                // JSON String 変換--> Dictionary<string, object> 型对象  
                //T? t = JsonSerializer.Deserialize<T>(jStr);
                T? t = Newtonsoft.Json.JsonConvert.DeserializeObject<T>(jStr);
                if (t is not null) { outT = t; }
                return ur.RetuenCode(0);
            }
            catch (Exception ex)
            {
                ur.AddExceptionMsg("Exception Class: " + "JsonFunc - JsonToObject<T>");
                ur.AddExceptionMsg("Exception: " + ex.Message);
                if (ex.InnerException != null)
                {
                    ur.AddExceptionMsg("InnerException: ");
                    ur.AddExceptionMsg(String.Concat(ex.InnerException.StackTrace, ex.InnerException.Message));
                }
                return ur.RetuenCode(-(_ClassID + 10));
            }           
        }

        /// <summary>
        /// Object ---> Json String
        /// </summary>
        /// <param name="jObj"></param>
        /// <param name="strJson"></param>
        /// <returns></returns>
        public static UtilityReturn ObjectToJson(Object jObj, out string strJson)
        {
            strJson = "";
            UtilityReturn ur = new();

            try
            {
                // Dictionary<string, object> 型对象  変換--> JSON String 
                //strJson = JsonSerializer.Serialize(jObj);
                strJson = Newtonsoft.Json.JsonConvert.SerializeObject(jObj);
                return ur.RetuenCode(0);
            }
            catch (Exception ex)
            {
                ur.AddExceptionMsg("Exception Class: " + "JsonFunc - ObjectToJson");
                ur.AddExceptionMsg("Exception: " + ex.Message);
                if (ex.InnerException != null)
                {
                    ur.AddExceptionMsg("InnerException: ");
                    ur.AddExceptionMsg(String.Concat(ex.InnerException.StackTrace, ex.InnerException.Message));
                }
                return ur.RetuenCode(-(_ClassID + 10));
            }
        }




        /// <summary>
        /// Set data to DataTable
        /// 
        /// </summary>
        /// <param name="argData"></param>
        /// <returns></returns>
        public static DataTable GetTbFromDatalist(Data_dl[] argData)
        {
            //string[] Data_dl.c --->  DataTable
            //Data_dl[] dlIn = argData;
            string[]? strArr = argData[0].c;

            DataTable outDt = new();

            if (strArr is not null)
            {
                // argData[0].c ---> DataTableのタイトル
                outDt = UtilityFunc.GenDtOnlyStruct(strArr);

                //  row 0 is タイトル
                //　Add data into　DataTable　(row 1 ～ row.Length)
                for (int i = 1; i < argData.Length; i++)
                {
                    // 1 ～ Data_dl[].Length  are data
                    strArr = argData[i].c;
                    if (strArr is not null)
                    {
                        DataRow dr = outDt.NewRow();
                        for (int r = 0; r < strArr.Length; r++)
                        {
                            dr[r] = strArr[r].ToString();
                        }
                        outDt.Rows.Add(dr);
                    }
                }
            }
            return outDt;
        }

        /// <summary>
        ///  DataTable Data Convert to DataList
        /// 
        /// </summary>
        /// <param name="argDt"></param>
        /// <returns></returns>
        public static Data_dl[] GetDatalistFromTb(DataTable argDt)
        {
            // Empty DataTable
            if (UtilityFunc.IsEmptyDataTable(argDt)) 
            {
                return (new Data_dl[0]);
            }

            // DataTable の行数和列数
            int rCount = argDt.Rows.Count; 
            int cCount = argDt.Columns.Count;

            Data_dl[]  outDl = new Data_dl[rCount + 1]; // + title
            int r = 0;

            // 第一行 タイトル
            outDl[r] = new Data_dl(cCount);
            for (int j = 0; j < cCount; j++)
            {
                outDl[r].c[j] = argDt.Columns[j].ColumnName.ToString();
            }
            r ++;

            // 行 1～rCount Datatable のデータ
            for (int i = 0; i < rCount; i++)
            {
                outDl[r] = new Data_dl(cCount);
                for (int j = 0; j < cCount; j++)
                {
                    outDl[r].c[j] = UtilityFunc.ObjToString(argDt.Rows[i][j]);

                }
                r ++;
            }

            return outDl;
        }




        /// <summary>
        /// Json String In --> Json object Class
        /// 
        /// DataSet dt1, dt2, dt3  Max 3 Tables
        /// 
        /// </summary>
        /// <param name="strJson">in Json String</param>
        /// <param name="outParamIn">out JadmIn对象</param>
        /// <param name="outDtIn">out DataTable</param>
        /// <returns> UtilityReturn </returns>
        public static UtilityReturn GetRequestDataFromJsonString(string strJson, out JobjIn outParamIn, out DataSet outDsIn)
        {
            outParamIn = new JobjIn();
            outDsIn = new();
            UtilityReturn ur = new();

            try
            {
                //转换 Json 的标准参数 部分 为 Json 标准 Class
                ur = JsonFunc.JsonToObject<JobjIn>(strJson, out outParamIn);

                if (ur._ReInt != 0) { return ur; } // return Error                

                if (outParamIn is not null)
                {
                    if ((outParamIn.dl1 is not null) && (outParamIn.dl1.GetLength(0) > 0))
                    {
                        DataTable dt1 = GetTbFromDatalist(outParamIn.dl1);
                        dt1.TableName = "dt1";
                        outDsIn.Tables.Add(dt1);
                    }

                    if ((outParamIn.dl2 is not null) && (outParamIn.dl2.GetLength(0) > 0))
                    {
                        DataTable dt2 = GetTbFromDatalist(outParamIn.dl2);
                        dt2.TableName = "dt2";
                        outDsIn.Tables.Add(dt2);
                    }

                    if ((outParamIn.dl3 is not null) && (outParamIn.dl3.GetLength(0) > 0))
                    {
                        DataTable dt3 = GetTbFromDatalist(outParamIn.dl3);
                        dt3.TableName = "dt3";
                        outDsIn.Tables.Add(dt3);
                    }
                }

                return ur.RetuenCode(0);
            }
            catch (Exception ex)
            {
                ur.AddExceptionMsg("Exception Class: " + "JsonFunc");
                ur.AddExceptionMsg("Exception: " + ex.Message);
                if (ex.InnerException != null) 
                {
                    ur.AddExceptionMsg("InnerException: ");
                    ur.AddExceptionMsg(String.Concat(ex.InnerException.StackTrace, ex.InnerException.Message));
                }
                return ur.RetuenCode(-(_ClassID + 50));
            }
        }

        /// <summary>
        ///  Add DataSet(to Data_dl[])into JobjOut(For Response) class
        ///  
        /// </summary>
        /// <param name="ParamOut"></param>
        /// <param name="dsOut"></param>
        /// <returns></returns>
        //public static JobjOut AddDataSetIntoResponseJsonClass(JobjOut ParamOut, DataSet dsOut)
        //{

        //    foreach (DataTable dt in dsOut.Tables) 
        //    {
        //        if (("dt1".Equals(dt.TableName)) && (UtilityFunc.IsEmptyDataTable(dt)==false))
        //        {
        //            ParamOut.dl1 = GetDatalistFromTb(dt);
        //            ParamOut.dl1max = dt.Rows.Count.ToString();
        //        }

        //        if (("dt2".Equals(dt.TableName)) && (UtilityFunc.IsEmptyDataTable(dt) == false))
        //        {
        //            ParamOut.dl2 = GetDatalistFromTb(dt);
        //            ParamOut.dl2max = dt.Rows.Count.ToString();
        //        }

        //        if (("dt3".Equals(dt.TableName)) && (UtilityFunc.IsEmptyDataTable(dt) == false))
        //        {
        //            ParamOut.dl3 = GetDatalistFromTb(dt);
        //            ParamOut.dl3max = dt.Rows.Count.ToString();
        //        }

        //        if (("dt4".Equals(dt.TableName)) && (UtilityFunc.IsEmptyDataTable(dt) == false))
        //        {
        //            ParamOut.dl4 = GetDatalistFromTb(dt);
        //            ParamOut.dl4max = dt.Rows.Count.ToString();
        //        }

        //        if (("dt5".Equals(dt.TableName)) && (UtilityFunc.IsEmptyDataTable(dt) == false))
        //        {
        //            ParamOut.dl5 = GetDatalistFromTb(dt);
        //            ParamOut.dl5max = dt.Rows.Count.ToString();
        //        }
        //    }

        //    return ParamOut;
        //}


    }
}
