﻿using demo1.CodeMsg;
using System.Data;

namespace demo1.Common
{

    /// <summary>
    /// Author: Kamikawa
    /// Date: 2023-03
    /// LastEditTime: 
    /// Description: 
    /// 
    /// </summary>
    public class PostCaseCls
    {

        public int _ClassID;    // Class ID
        public UtilityReturn _Ur = new();

        //Request・Response 用 Json Class
        public JobjIn _JobjIn = new();      // Json Object In
        public JobjOut _JobjOut = new();    // Json Object Out

        // Request・Response 用 DataSet
        public DataSet _DataSetIn = new();  // DataSet In
        //public DataSet _DataSetOut = new(); // DataSet Out

        // Request 用 DataSet
        public DataTable _TableIn1 = new();  // DataTable In 1
        public DataTable _TableIn2 = new();  // DataTable In 2
        public DataTable _TableIn3 = new();  // DataTable In 3
        public DataTable _TableIn4 = new();  // DataTable In 4
        public DataTable _TableIn5 = new();  // DataTable In 5


        // Set _DataSetIn.Tables["dt1"] --> _TableIn1
        // Set _DataSetIn.Tables["dt2"] --> _TableIn2
        // Set _DataSetIn.Tables["dt3"] --> _TableIn3
        // Set _DataSetIn.Tables["dt4"] --> _TableIn4
        // Set _DataSetIn.Tables["dt5"] --> _TableIn5
        public void GetTablesFromDataSet() 
        {
            foreach (DataTable table in _DataSetIn.Tables)
            {
                if ("dt1".Equals(table.TableName)) { _TableIn1 = table; }
                if ("dt2".Equals(table.TableName)) { _TableIn2 = table; }
                if ("dt3".Equals(table.TableName)) { _TableIn3 = table; }
                if ("dt4".Equals(table.TableName)) { _TableIn4 = table; }
                if ("dt5".Equals(table.TableName)) { _TableIn5 = table; }
            }
        }

        // Response 用 DataSet
        public DataTable _TableOut1 = new();  // DataTable Out 1
        public DataTable _TableOut2 = new();  // DataTable Out 2
        public DataTable _TableOut3 = new();  // DataTable Out 3
        public DataTable _TableOut4 = new();  // DataTable Out 4
        public DataTable _TableOut5 = new();  // DataTable Out 5




        //    public class JobjOut
        //{
        //    public string datetime = "";
        //    public string code = "";
        //    public string msg = "";
        //    public string msgd = "";        // debug + Exception Msg
        //    public string lang = "";
        //    public string dl1max = "";
        //    public string dl2max = "";
        //    public string dl3max = "";
        //    public string dl4max = "";
        //    public string dl5max = "";
        //    public Data_dl[]? dl1;
        //    public Data_dl[]? dl2;
        //    public Data_dl[]? dl3;
        //    public Data_dl[]? dl4;
        //    public Data_dl[]? dl5;
        //}

        public void SetResponseJsonClass()
        {
            try
            {
                _JobjOut.datetime = DateTime.Now.ToString("yyyyMMddHHmmss");
                _JobjOut.code = _Ur._ReInt.ToString();

                // Debug Msg + Exception Msg ---> msgdに設定する
                _JobjOut.msgd = _Ur.GetAllDebugExceptionMsg();
                _JobjOut.lang = _JobjIn.lang;

                // _ReInt より メッセージを設定する(お客様に表示用)
                if (_Ur._ReInt != 0)
                {
                    _JobjOut.msg = UtilityMsg.GetMsgData(_JobjIn.lang, _Ur._ReInt);
                    //if (string.IsNullOrEmpty(_JobjOut.msg))
                    //{
                    //    _JobjOut.msg = "システム Debug/Exception コード: " + _Ur._ReInt.ToString() + " 管理者に連絡してください.";
                    //}

                    return; // _ReInt != 0,   just return _Ur
                }
                

                if (UtilityFunc.IsEmptyDataTable(_TableOut1) == false)
                {
                    _JobjOut.dl1 = JsonFunc.GetDatalistFromTb(_TableOut1);
                    _JobjOut.dl1max = _TableOut1.Rows.Count.ToString();
                }

                if (UtilityFunc.IsEmptyDataTable(_TableOut2) == false)
                {
                    _JobjOut.dl2 = JsonFunc.GetDatalistFromTb(_TableOut2);
                    _JobjOut.dl2max = _TableOut2.Rows.Count.ToString();
                }

                if (UtilityFunc.IsEmptyDataTable(_TableOut3) == false)
                {
                    _JobjOut.dl3 = JsonFunc.GetDatalistFromTb(_TableOut3);
                    _JobjOut.dl3max = _TableOut3.Rows.Count.ToString();
                }

                if (UtilityFunc.IsEmptyDataTable(_TableOut4) == false)
                {
                    _JobjOut.dl4 = JsonFunc.GetDatalistFromTb(_TableOut4);
                    _JobjOut.dl4max = _TableOut4.Rows.Count.ToString();
                }

                if (UtilityFunc.IsEmptyDataTable(_TableOut5) == false)
                {
                    _JobjOut.dl5 = JsonFunc.GetDatalistFromTb(_TableOut5);
                    _JobjOut.dl5max = _TableOut5.Rows.Count.ToString();
                }
            }
            catch (Exception ex)
            {
                _Ur.AddExceptionMsg("Exception Class: " + "PostCaseCls - SetResponseJsonClass");
                _Ur.AddExceptionMsg("Exception: " + ex.Message);
                if (ex.InnerException != null)
                {
                    _Ur.AddExceptionMsg("InnerException: ");
                    _Ur.AddExceptionMsg(String.Concat(ex.InnerException.StackTrace, ex.InnerException.Message));
                }
                _Ur._ReInt = (-(_ClassID + 999));

                // Exception 発生する時、_JobjOut再設定する
                _JobjOut.datetime = DateTime.Now.ToString("yyyyMMddHHmmss");
                _JobjOut.code = _Ur._ReInt.ToString();
                _JobjOut.msg = UtilityMsg.GetMsgData(_JobjIn.lang, _Ur._ReInt);
                _JobjOut.msgd = _Ur.GetAllDebugExceptionMsg();
                _JobjOut.lang = _JobjIn.lang;
            }            
        }


    }
}
