﻿using System.Diagnostics;

namespace demo1.Common
{

    /// <summary>
    /// Author: Kamikawa
    /// Date: 2023-03
    /// LastEditTime: 
    /// Description: 
    /// 
    /// </summary>
    public class InstClassFunc
    {

        public readonly static string[,] Class_Func = {
            { "0","ModelName","Class Name","Function Name"},
            { "1","GetDbData","demo1.Models.TestModels.GetDbData","DoPostFunc"},
            { "2","Model","","DoPostFunc"},
            { "11","Yotei01","demo1.Models.Nyuka.Yotei01","DoPostFunc"},
            { "12","Yotei02","demo1.Models.Nyuka.Yotei02","DoPostFunc"},
            { "15","WebGridModel","demo1.Models.TestModels.WebGridModel","DoPostFunc"},
            { "20","NkYoteiInsertCheck","demo1.Models.Nyuka.NkYoteiInsertCheck","DoPostFunc"},
            { "21","NkYoteiDataSearch","demo1.Models.Nyuka.NkYoteiDataSearch","DoPostFunc"},
            { "22","NkYoteiAutoSupplier","demo1.Models.Nyuka.NkYoteiAutoSupplier","DoPostFunc"},
            { "23","NkYoteiDataUpdate","demo1.Models.Nyuka.NkYoteiDataUpdate","DoPostFunc"},
            { "24","NkYoteiSlipSearch","demo1.Models.Nyuka.NkYoteiSlipSearch","DoPostFunc"},
            { "25","NkYoteiDataDelete","demo1.Models.Nyuka.NkYoteiDataDelete","DoPostFunc"},
            { "26","ModCopySample","demo1.Models.CopyModel.ModCopySample","DoPostFunc"},
            { "27","LockTestSelect","demo1.Models.TestModels.LockTestSelect","DoPostFunc"},
            { "28","LockTestUpdate","demo1.Models.TestModels.LockTestUpdate","DoPostFunc"}
        };


        public static int GetClassMethod(string modName, out string clsName, out string funcName) 
        {
            clsName = "";
            funcName = "";

            for (int i= 1; i< Class_Func.GetLength(0);i++) 
            {
                if (Class_Func[i,1].Equals(modName)) 
                {
                    clsName = Class_Func[i, 2];
                    funcName = Class_Func[i, 3];
                    return 0;
                }
            }

            return -10;
            // Type name  = assembly + namespace + classname
            //Type? tt = Type.GetType(sAction);
        }
    }


    /// <summary>
    /// Models Instance Case
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class ClassInst<T> where T:new()
    {
        public Type instType = typeof(System.Int16); //Just set a default value
        public T instClass = new();

        public int CreateInst(string clsName) 
        {
            try
            {
                Type? t = Type.GetType(clsName + ",demo1"); //  Type.GetType(full classname, assembly); 
                if (t is not null)
                {
                    object? o = System.Activator.CreateInstance(t, true);
                    if (o is not null)
                    {
                        instClass = (T)o;
                        instType = t;
                        return 0;
                    }
                }
                return 10;
            }
            catch (Exception ex)
            {
                Trace.WriteLine(ex.Message);
                return -10;
            }
            
        }

    }


}
