﻿using Npgsql;
using System.Data;
using System.Data.Common;

namespace demo1.Common
{

    /// <summary>
    /// Author: Kamikawa
    /// Date: 2023-03
    /// LastEditTime: 
    /// Description: 
    /// 
    /// </summary>
    public class DbMethod
    {
        public static int _ClassID = ClassCode.GetClassId(typeof(DbMethod));
        public static NpgsqlConnection _DummyConn = new();

        /// <summary>
        /// NpgsqlConnection の発行処理
        /// </summary>
        /// <returns></returns>
        public static UtilityReturn GetConnection(out NpgsqlConnection sqlConn) 
        {
            UtilityReturn reUr = new();
            sqlConn = DbMethod._DummyConn;  // Speed改善点：既存 空Connectionを設定する

            try
            {
                // 統一 Connection の発行処理, 将来 ConnectionPool を作成
                sqlConn = new(EnvConst.DB_CONSTR);
                if (sqlConn.State != ConnectionState.Open) { sqlConn.Open(); } // Connection Open
                return reUr.RetuenCode(0);
            }
            catch (Exception ex)
            {
                reUr.AddExceptionMsg("Exception Class: " + "DbMethod - GetConnection");
                reUr.AddExceptionMsg("Exception: " + ex.Message);
                if (ex.InnerException != null)
                {
                    reUr.AddExceptionMsg("InnerException: ");
                    reUr.AddExceptionMsg(String.Concat(ex.InnerException.StackTrace, ex.InnerException.Message));
                }
                return reUr.RetuenCode(-(DbMethod._ClassID + 12));
            }            
        }


        /// <summary>
        /// NpgsqlConnection の閉じる
        /// </summary>
        /// <param name="sqlConn"></param>
        public static void CloseConnection(NpgsqlConnection sqlConn)
        {
            if (sqlConn.State == ConnectionState.Open)
            {
                sqlConn.Close();
            }
        }



        /// <summary>
        /// Use DataAdapter，Return DataSet
        /// </summary>
        /// <param name="sqrstr"></param>
        /// <returns></returns>
        public DataSet ExecuteQuery(string sqrstr)
        {
            NpgsqlConnection SqlConn = new(EnvConst.DB_CONSTR);
            DataSet ds = new();
            SqlConn.Open();
            try
            {
                using (NpgsqlDataAdapter sqldap = new(sqrstr, SqlConn))
                {
                    sqldap.Fill(ds);
                }
                return ds;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                return ds;
            }
            finally { SqlConn.Close(); }
        }


        /// <summary>
        /// USE DataReader 
        /// </summary>
        /// <param name="cmdText"></param>
        /// <returns></returns>
        //public DbDataReader GetReader(string cmdText)
        //{
        //    NpgsqlConnection sqlConn = new(EnvConst.DB_CONSTR);
        //    if (sqlConn.State != ConnectionState.Open)
        //        sqlConn.Open();
        //    try
        //    {
        //        using (NpgsqlCommand cmd = new(cmdText, sqlConn))
        //        {
        //            //use CommandBehavior.CloseConnection
        //            // stream reader will auto close Connection when finished reading data.
        //            //https://learn.microsoft.com/ja-jp/dotnet/api/system.data.commandbehavior?view=net-7.0
        //            NpgsqlDataReader sdr = cmd.ExecuteReader(CommandBehavior.CloseConnection);                      
        //            return sdr;
        //        }
        //    }
        //    catch (System.Exception ex)
        //    {
        //        Console.WriteLine(ex);
        //        return null;
        //    }
        //    finally { sqlConn.Close(); }
        //}



        /// <summary>
        /// update delete
        /// </summary>
        /// <param name="sqrstr"></param>
        /// <returns></returns>
        public int ExecuteNonQuery(string sqrstr)
        {
            NpgsqlConnection sqlConn = new(EnvConst.DB_CONSTR);
            try
            {
                sqlConn.Open();
                using (NpgsqlCommand SqlCommand = new(sqrstr, sqlConn))
                {
                    int r = SqlCommand.ExecuteNonQuery();  // execute rows
                    return r; // r >= 0
                }
            }
            catch (System.Exception ex)
            {
                Console.WriteLine(ex);
                return 0;
            }
            finally { sqlConn.Close(); }

        }










    }
}
