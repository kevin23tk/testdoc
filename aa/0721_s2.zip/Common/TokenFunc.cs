﻿using System.Diagnostics;
using System.Diagnostics.Metrics;

namespace demo1.Common
{

    /// <summary>
    /// Author: Kamikawa
    /// Date: 2023-03
    /// LastEditTime: 
    /// Description: 
    /// 
    /// </summary>
    public class TokenFunc
    {
        public static string GenUUID(string sType)
        {
            Guid uuid = Guid.NewGuid();
            string reStr = "";

            switch (sType)
            {
                case "D":
                    reStr = uuid.ToString("D");
                    break;

                case "N":
                    reStr = uuid.ToString("N");
                    break;

                case "B":
                    reStr = uuid.ToString("B");
                    break;

                case "P":
                    reStr = uuid.ToString("P");
                    break;

                default:
                    reStr = uuid.ToString();
                    break;
            }


            //Trace.WriteLine("standard format： " + uuid.ToString("D"));
            //Trace.WriteLine("simplified format： " + uuid.ToString("N"));
            //Trace.WriteLine("curly braces format： " + uuid.ToString("B"));
            //Trace.WriteLine("parenthesis format： " + uuid.ToString("P"));
            //standard format：      1c104694-85fb-4299-a946-45222b4f5fef
            //simplified format：    1c10469485fb4299a94645222b4f5fef
            //curly braces format：  {1c104694-85fb-4299-a946-45222b4f5fef}
            //parenthesis format：   (1c104694-85fb-4299-a946-45222b4f5fef)

            return reStr;
        }


    }
}
