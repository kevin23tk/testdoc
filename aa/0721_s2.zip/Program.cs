using Microsoft.AspNetCore.Mvc;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
}
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

//app.MapControllerRoute(name: "blog",
//                pattern: "blog/{*article}",
//                defaults: new { controller = "Blog", action = "Article" });
//app.MapControllerRoute(name: "nolang",
//                pattern: "{controller=Home}/{action=Index}/{id?}",
//                defaults: new { lang = "ja", controller = "[controller]", action = "[action]" });
//app.MapControllerRoute(
//    name: "default",
//    pattern: "{lang=ja}/{controller=Home}/{action=Index}/{id?}");

app.MapControllerRoute(
    name: "another",
    pattern: "{controller=Default}/{action=DefaultAction}/{lang=def-lang}/{id?}");

app.MapControllerRoute(
    name: "default",
    pattern: "{lang=en-us}/{controller=Default}/{action=DefaultAction}/{id?}");

app.Run();
