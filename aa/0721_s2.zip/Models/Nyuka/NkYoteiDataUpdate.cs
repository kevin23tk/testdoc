﻿using demo1.Common;
using Npgsql;
using NpgsqlTypes;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;

namespace demo1.Models.Nyuka
{
    /// <summary>
    /// Author: Kamikawa
    /// Date: 2023-05
    /// LastEditTime: 
    /// Description: 入荷予定画面
    /// 
    /// 関連するモジュル
    /// NkYoteiInsertCheck -- 新規前に入荷伝票番号の存在確認
    /// NkYoteiDataSearch -- 入荷伝票番号より検索
    /// NkYoteiAutoSupplier -- 仕入先マスタから仕入先名称を取得する
    /// NkYoteiDataUpdate -- 入力データのDB更新
    /// NkYoteiSlipSearch -- 入荷伝票番号マスタ検索
    /// NkYoteiDataDelete -- 入荷伝票番号より削除（論理削除）
    /// </summary>
    public class NkYoteiDataUpdate : PostCaseCls
    {

        public NkYoteiDataUpdate()
        {
            this._ClassID = ClassCode.GetClassId(typeof(NkYoteiDataUpdate));
        }



        // POST から実行する
        public void DoPostFunc()
        {

            #region ----------- Request Data の取得 -------------

            // Request Data は Json 形式です。

            //{
            //  datetime: "2023-02-28 10:38:56",
            //  loginid: "L001",
            //  devid: "D001",
            //  action: "A001",
            //  lang: "ja-jp",
            //  dl1max: "1",
            //  dl2max: "",
            //  dl3max: "",
            //  dl4max: "",
            //  dl5max: "",
            //  dl1: [
            //        { c: ["name", "gender", "age"]}, 
            //        { c: ["田中", "男", "35"] }
            //       ],
            //  dl2: [],
            //  dl3: [],
            //  dl4: [],
            //  dl5: []
            //}


            // Usage:
            // DataTable 形式のデータ取得
            // JsonParamのパラメータより最大３つListデータを取得可能です。
            // すでに自動でList-->DataTableを変換しました。

            // Set _DataSetIn.Tables["dt1"] --> _TableIn1
            // Set _DataSetIn.Tables["dt2"] --> _TableIn2
            // Set _DataSetIn.Tables["dt3"] --> _TableIn3
            // Set _DataSetIn.Tables["dt4"] --> _TableIn4
            // Set _DataSetIn.Tables["dt5"] --> _TableIn5
            GetTablesFromDataSet();

            // DataTable は以下のとおりで使える
            //_TableIn1.Rows[0]["name"].ToString() --> "田中"

            // Json Class 形式のデータ取得
            //string sLogin = this._JobjIn.loginid;
            //string sLang = this._JobjIn.lang;

            #endregion


            //クラスのプロセス実行
            ProcessFlow();


            #region ----------- Response JsonClassの作成 -------------



            //    public class JobjOut
            //{
            //    public string datetime = "";
            //    public string code = "";
            //    public string msg = "";
            //    public string msgd = "";        // debug + Exception Msg
            //    public string lang = "";
            //    public string dl1max = "";
            //    public string dl2max = "";
            //    public string dl3max = "";
            //    public string dl4max = "";
            //    public string dl5max = "";
            //    public Data_dl[]? dl1;
            //    public Data_dl[]? dl2;
            //    public Data_dl[]? dl3;
            //    public Data_dl[]? dl4;
            //    public Data_dl[]? dl5;
            //}

            //返信用データを _TableOut1 ～ _TableOut5 に設定する
            SetResponseJsonClass();


            #endregion

        }



        //流程处理
        public UtilityReturn ProcessFlow()
        {
            //step1 データチェック
            DataCheck();
            if (_Ur._ReInt != 0) { return _Ur; }

            //step2
            // .......

            //step3
            // .......

            //stepN データ处理
            DataProcess();
            if (_Ur._ReInt != 0) { return _Ur; }

            return _Ur;
        }

        private UtilityReturn DataCheck()
        {
            //if (UtilityFunc.IsEmptyDataTable(_TableIn1))
            //{
            //    _Ur.AddExceptionMsg("_TableIn1 パラメータ Empty.");
            //    return _Ur.RetuenCode(_ClassID + 31);
            //}

            if (UtilityFunc.IsEmptyDataTable(_TableIn2))
            {
                _Ur.AddExceptionMsg("_TableIn2 パラメータ Empty.");
                return _Ur.RetuenCode(_ClassID + 32);
            }

            if (UtilityFunc.IsEmptyDataTable(_TableIn3))
            {
                _Ur.AddExceptionMsg("_TableIn3 パラメータ Empty.");
                return _Ur.RetuenCode(_ClassID + 33);
            }

            // Column 存在チエック
            //DataColumnCollection columns = _TableIn1.Columns;
            //if (columns.Contains("shipcode") == false)
            //{
            //    _Ur.AddExceptionMsg("_TableIn1 column shipcode not exist.");
            //    return _Ur.RetuenCode(_ClassID + 32);
            //}

            ////必須項目チェック
            //string ss = UtilityFunc.ObjToString(_TableIn1.Rows[0]["shipcode"]);
            //if (string.IsNullOrEmpty(ss))
            //{
            //    _Ur.AddExceptionMsg("パラメータ shipcode is Empty.");
            //    return _Ur.RetuenCode(_ClassID + 33);
            //}

            return _Ur.RetuenCode(0);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public UtilityReturn DataProcess()
        {
            NpgsqlConnection sqlConn = DbMethod._DummyConn;
            NpgsqlTransaction? transaction = null;
            bool doRollback = false;
            int exeRows = -1;
            DateTime tempDtm = DateTime.Now;
            string str_arrival_slip_detail_key = "";

            try
            {
                // DB Connection の取得
                //sqlConn = new(EnvConst.DB_CONSTR);
                //sqlConn.Open();
                UtilityReturn reUr = DbMethod.GetConnection(out sqlConn);
                if (reUr._ReInt != 0) 
                {
                    return _Ur.RetuenMerge(reUr);
                }

                // Transaction 作成
                transaction = sqlConn.BeginTransaction();

                string headFlg = "";

                String headerkey = UtilityFunc.ObjToString(_TableIn1.Rows[0]["arrival_slip_header_key"]);

                headFlg = UtilityFunc.ObjToString(_TableIn1.Rows[0]["type"]);  // new/edit/delete/none

                //insert t_arrival_slip_header
                if ("new".Equals(headFlg))
                {

                    headerkey = "ASH" + TokenFunc.GenUUID("N").Substring(0, 12);

                    if (doRollback == false)
                    {
                        NpgsqlCommand cmd11 = sqlConn.CreateCommand();
                        cmd11.CommandType = CommandType.Text;
                        cmd11.Transaction = transaction;
                        cmd11.Parameters.Clear();
                        cmd11.CommandText = @"
                                              insert
                                              into t_arrival_slip_header(
                                                  arrival_slip_header_key
                                                , delete_flag
                                                , system_code
                                                , customer_code
                                                , logistics_base_code
                                                , arrival_slip_no
                                                , arrival_plan_date
                                                , order_no
                                                , supplier_code
                                                , regist_datetime
                                                , regist_user
                                                , update_datetime
                                                , update_user
                                                , update_program_id
                                              ) 
                                              values ( 
                                                  @tash_p1
                                                , @tash_p2
                                                , @tash_p3
                                                , @tash_p4
                                                , @tash_p5
                                                , DATE @tash_p6
                                                , @tash_p7
                                                , @tash_p8
                                                , CURRENT_TIMESTAMP
                                                , @tash_p9
                                                , CURRENT_TIMESTAMP
                                                , @tash_p10
                                                , @tash_p11
                                              )
                                             ";

                        NpgsqlParameter parm11_1 = new NpgsqlParameter("@tash_p1", NpgsqlDbType.Varchar, 12);
                        parm11_1.Value = headerkey;

                        NpgsqlParameter parm11_2 = new NpgsqlParameter("@tash_p2", NpgsqlDbType.Varchar, 12);
                        parm11_2.Value = _TableIn1.Rows[0]["system_code"].ToString();

                        NpgsqlParameter parm11_3 = new NpgsqlParameter("@tash_p3", NpgsqlDbType.Varchar, 12);
                        parm11_3.Value = _TableIn1.Rows[0]["customer_code"].ToString();

                        NpgsqlParameter parm11_4 = new NpgsqlParameter("@tash_p4", NpgsqlDbType.Varchar, 12);
                        parm11_4.Value = _TableIn1.Rows[0]["logistics_base_code"].ToString();

                        NpgsqlParameter parm11_5 = new NpgsqlParameter("@tash_p5", NpgsqlDbType.Varchar, 25);
                        parm11_5.Value = _TableIn1.Rows[0]["arrival_slip_no"].ToString();

                        NpgsqlParameter parm11_6 = new NpgsqlParameter("@tash_p6", NpgsqlDbType.Date);
                        parm11_6.Value = _TableIn3.Rows[0]["arrival_plan_date"].ToString();

                        NpgsqlParameter parm11_7 = new NpgsqlParameter("@tash_p7", NpgsqlDbType.Varchar, 25);
                        parm11_7.Value = _TableIn3.Rows[0]["order_no"].ToString();

                        NpgsqlParameter parm11_8 = new NpgsqlParameter("@tash_p8", NpgsqlDbType.Varchar, 12);
                        parm11_8.Value = _TableIn3.Rows[0]["supplier_code"].ToString();

                        NpgsqlParameter parm11_9 = new NpgsqlParameter("@tash_p9", NpgsqlDbType.Varchar, 10);
                        parm11_9.Value = _TableIn1.Rows[0]["user"].ToString();

                        NpgsqlParameter parm11_10 = new NpgsqlParameter("@tash_p10", NpgsqlDbType.Varchar, 10);
                        parm11_10.Value = _TableIn1.Rows[0]["user"].ToString();

                        NpgsqlParameter parm11_11 = new NpgsqlParameter("@tash_p11", NpgsqlDbType.Varchar, 6);
                        parm11_11.Value = _TableIn1.Rows[0]["program_id"].ToString();


                        cmd11.Parameters.Add(parm11_1);
                        cmd11.Parameters.Add(parm11_2);
                        cmd11.Parameters.Add(parm11_3);
                        cmd11.Parameters.Add(parm11_4);
                        cmd11.Parameters.Add(parm11_5);
                        cmd11.Parameters.Add(parm11_6);
                        cmd11.Parameters.Add(parm11_7);
                        cmd11.Parameters.Add(parm11_8);
                        cmd11.Parameters.Add(parm11_9);
                        cmd11.Parameters.Add(parm11_10);
                        cmd11.Parameters.Add(parm11_11);

                        exeRows = cmd11.ExecuteNonQuery();

                        // 結果チェック
                        if (exeRows != 1)
                        {
                            _Ur.AddExceptionMsg("insert t_arrival_slip_header , row: 0 insert row <> 1");
                            doRollback = true;
                        }
                    }
                }


                if ("edit".Equals(headFlg))
                { }


                if ("delete".Equals(headFlg))
                { }


                //_TableIn2 = [
                //    ["tb_key", "type"],    new|edit
                //    ["ash_key2#asd_key3#asds_key2", "edit"],
                //    ["ash_key2#asd_key4#", "edit"]
                //];

                //_TableIn3 = [
                //    ["tb_key", "arrival_slip_header_key", "arrival_slip_detail_key", "arrival_slip_detail_stockkey_key", "order_no", "supplier_code", "arrival_plan_date", "item_code_1", "arrival_plan_quantity_piece", "allocate_kinds", "recipt_pay_division", "work_division", "management_department", "packing_quantity", "arrival_unit_price", "remarks", "t_asds_stock_key_character_1", "t_asds_stock_key_character_2", "t_asds_stock_key_character_3", "t_asds_stock_key_character_4", "t_asds_stock_key_character_5", "t_asds_stock_key_character_6", "t_asds_stock_key_date_1", "t_asds_stock_key_date_2", "t_asds_stock_key_number_1", "t_asds_stock_key_number_2", "item_name_1", "quantity_per_pallet", "quantity_per_pack", "quantity_per_case", "quantity_per_carton", "weight_piece", "parameter_setting_1", "parameter_setting_2", "parameter_setting_3", "parameter_setting_4"],
                //    ["ash_key2#asd_key3#asds_key2", "ash_key2", "asd_key3", "asds_key2", "order2", "sup01", "2023/04/20 0:00:00", "item1", "100.000", "01", "01", "01", "01", "3", "100.00", "備考３", "A", "B", "", "", "", "", "2023/05/01 0:00:00", "", "2.000", "2.000", "商品名称１", "1", "1", "1", "1", "1.000", "A部門", "受払区分A", "引当種別A", "作業区分A"],
                //    ["ash_key2#asd_key4#", "ash_key2", "asd_key4", "", "order2", "sup01", "2023/04/20 0:00:00", "item2", "100.000", "01", "01", "01", "01", "3", "100.00", "備考４", "", "", "", "", "", "", "", "", "", "", "商品名称２", "2", "2", "2", "2", "2.000", "A部門", "受払区分A", "引当種別A", "作業区分A"]
                //];


                string detailFlg = "";
                string newDetailKey = "";

                //t_arrival_slip_header 更新操作失敗
                if (doRollback == false)
                {

                    for (int i = 0; i < _TableIn2.Rows.Count; i++)
                    {
                        detailFlg = UtilityFunc.ObjToString(_TableIn2.Rows[i]["type"]); // new/edit/delete

                        // edit 
                        // upfate t_arrival_slip_detail
                        // update t_arrival_slip_detail_stockkey
                        // update m_item 
                        // update m_parameter 
                        if ("edit".Equals(detailFlg))
                        {

                            //update t_arrival_slip_header
                            //if (doRollback == false)
                            //{
                            //    NpgsqlCommand cmd1 = sqlConn.CreateCommand();
                            //    cmd1.CommandType = CommandType.Text;
                            //    cmd1.Transaction = transaction;
                            //    cmd1.Parameters.Clear();
                            //    cmd1.CommandText = @"update t_arrival_slip_header
                            //                  set 
                            //                    order_no = @tash_p1, 
                            //                    supplier_code = @tash_p2, 
                            //                    arrival_plan_date = @tash_p3 
                            //                  where
                            //                    arrival_slip_header_key = @tash_w1 
                            //            ";

                            //    NpgsqlParameter parm1_1 = new NpgsqlParameter("@tash_p1", NpgsqlDbType.Varchar, 10);
                            //    parm1_1.Value = _TableIn3.Rows[i]["order_no"].ToString();

                            //    NpgsqlParameter parm1_2 = new NpgsqlParameter("@tash_p2", NpgsqlDbType.Varchar, 11);
                            //    parm1_2.Value = _TableIn3.Rows[i]["supplier_code"].ToString();

                            //    NpgsqlParameter parm1_3 = new NpgsqlParameter("@tash_p3", NpgsqlDbType.Date);
                            //    tempDtm = DateTime.Now;
                            //    DateTime.TryParseExact(_TableIn3.Rows[i]["arrival_plan_date"].ToString(), "yyyyMMdd", null, DateTimeStyles.None, out tempDtm);
                            //    parm1_3.Value = tempDtm;

                            //    NpgsqlParameter parm1_11 = new NpgsqlParameter("@tash_w1", NpgsqlDbType.Varchar, 15);
                            //    parm1_11.Value = _TableIn3.Rows[i]["arrival_slip_header_key"].ToString();

                            //    cmd1.Parameters.Add(parm1_1);
                            //    cmd1.Parameters.Add(parm1_2);
                            //    cmd1.Parameters.Add(parm1_3);
                            //    cmd1.Parameters.Add(parm1_11);

                            //    exeRows = cmd1.ExecuteNonQuery();  // execute rows

                            //    // Unique チェック
                            //    if (exeRows != 1)
                            //    {
                            //        _Ur.AddExceptionMsg("update t_arrival_slip_header , row: " + i.ToString() + " update row <> 1");
                            //        doRollback = true;
                            //        //return _Ur.RetuenCode(_ClassID + 52);
                            //    }
                            //}


                            //upfate t_arrival_slip_detail
                            if (doRollback == false)
                            {
                                NpgsqlCommand cmd2 = sqlConn.CreateCommand();
                                cmd2.CommandType = CommandType.Text;
                                cmd2.Transaction = transaction;
                                cmd2.Parameters.Clear();
                                cmd2.CommandText = @"update t_arrival_slip_detail
                                              set 
                                                item_code_1 = @tasd_p1, 
                                                arrival_plan_quantity_piece = @tasd_p2, 
                                                allocate_kinds = @tasd_p3, 
                                                recipt_pay_division = @tasd_p4, 
                                                work_division = @tasd_p5, 
                                                management_department = @tasd_p6, 
                                                packing_quantity = @tasd_p7, 
                                                arrival_unit_price = @tasd_p8, 
                                                remarks = @tasd_p9  
                                              where 
                                                arrival_slip_detail_key = @tasd_w1
                                        ";

                                NpgsqlParameter parm2_1 = new NpgsqlParameter("@tasd_p1", NpgsqlDbType.Varchar, 25);
                                parm2_1.Value = _TableIn3.Rows[i]["item_code_1"].ToString();

                                NpgsqlParameter parm2_2 = new NpgsqlParameter("@tasd_p2", NpgsqlDbType.Numeric, 16);
                                parm2_2.Value = Convert.ToDecimal(_TableIn3.Rows[i]["arrival_plan_quantity_piece"].ToString());

                                NpgsqlParameter parm2_3 = new NpgsqlParameter("@tasd_p3", NpgsqlDbType.Varchar, 40);
                                parm2_3.Value = _TableIn3.Rows[i]["allocate_kinds"].ToString();

                                NpgsqlParameter parm2_4 = new NpgsqlParameter("@tasd_p4", NpgsqlDbType.Varchar, 40);
                                parm2_4.Value = _TableIn3.Rows[i]["recipt_pay_division"].ToString();

                                NpgsqlParameter parm2_5 = new NpgsqlParameter("@tasd_p5", NpgsqlDbType.Varchar, 40);
                                parm2_5.Value = _TableIn3.Rows[i]["work_division"].ToString();

                                NpgsqlParameter parm2_6 = new NpgsqlParameter("@tasd_p6", NpgsqlDbType.Varchar, 40);
                                parm2_6.Value = _TableIn3.Rows[i]["management_department"].ToString();

                                NpgsqlParameter parm2_7 = new NpgsqlParameter("@tasd_p7", NpgsqlDbType.Numeric, 9);
                                parm2_7.Value = Convert.ToDecimal(_TableIn3.Rows[i]["packing_quantity"].ToString());

                                NpgsqlParameter parm2_8 = new NpgsqlParameter("@tasd_p8", NpgsqlDbType.Numeric, 13);
                                parm2_8.Value = Convert.ToDecimal(_TableIn3.Rows[i]["arrival_unit_price"].ToString());

                                NpgsqlParameter parm2_9 = new NpgsqlParameter("@tasd_p9", NpgsqlDbType.Varchar, 100);
                                parm2_9.Value = _TableIn3.Rows[i]["remarks"].ToString();

                                NpgsqlParameter parm2_11 = new NpgsqlParameter("@tasd_w1", NpgsqlDbType.Varchar, 15);
                                parm2_11.Value = _TableIn3.Rows[i]["arrival_slip_detail_key"].ToString();


                                cmd2.Parameters.Add(parm2_1);
                                cmd2.Parameters.Add(parm2_2);
                                cmd2.Parameters.Add(parm2_3);
                                cmd2.Parameters.Add(parm2_4);
                                cmd2.Parameters.Add(parm2_5);
                                cmd2.Parameters.Add(parm2_6);
                                cmd2.Parameters.Add(parm2_7);
                                cmd2.Parameters.Add(parm2_8);
                                cmd2.Parameters.Add(parm2_9);
                                cmd2.Parameters.Add(parm2_11);

                                exeRows = cmd2.ExecuteNonQuery();  // execute rows

                                // Unique チェック
                                if (exeRows != 1)
                                {
                                    _Ur.AddExceptionMsg("update t_arrival_slip_detail , row: " + i.ToString() + " update row <> 1");
                                    doRollback = true;
                                    //return _Ur.RetuenCode(_ClassID + 52);
                                }
                            }


                            //update t_arrival_slip_detail_stockkey
                            if (doRollback == false)
                            {
                                str_arrival_slip_detail_key = UtilityFunc.ObjToString(_TableIn3.Rows[i]["arrival_slip_detail_stockkey_key"]);
                                if (string.IsNullOrEmpty(str_arrival_slip_detail_key) == false)
                                {
                                    NpgsqlCommand cmd3 = sqlConn.CreateCommand();
                                    cmd3.CommandType = CommandType.Text;
                                    cmd3.Transaction = transaction;
                                    cmd3.Parameters.Clear();
                                    cmd3.CommandText = @"update t_arrival_slip_detail_stockkey
                                              set 
                                                stock_key_character_1 = @tasds_p1, 
                                                stock_key_character_2 = @tasds_p2, 
                                                stock_key_character_3 = @tasds_p3, 
                                                stock_key_character_4 = @tasds_p4, 
                                                stock_key_character_5 = @tasds_p5, 
                                                stock_key_character_6 = @tasds_p6, 
                                                stock_key_date_1 = @tasds_p7, 
                                                stock_key_date_2 = @tasds_p8, 
                                                stock_key_number_1 = @tasds_p9, 
                                                stock_key_number_2 = @tasds_p10  
                                              where 
                                                arrival_slip_detail_stockkey_key = @tasds_w1 
                                        ";

                                    NpgsqlParameter parm3_1 = new NpgsqlParameter("@tasds_p1", NpgsqlDbType.Varchar, 25);
                                    parm3_1.Value = _TableIn3.Rows[i]["t_asds_stock_key_character_1"].ToString();

                                    NpgsqlParameter parm3_2 = new NpgsqlParameter("@tasds_p2", NpgsqlDbType.Varchar, 25);
                                    parm3_2.Value = _TableIn3.Rows[i]["t_asds_stock_key_character_2"].ToString();

                                    NpgsqlParameter parm3_3 = new NpgsqlParameter("@tasds_p3", NpgsqlDbType.Varchar, 25);
                                    parm3_3.Value = _TableIn3.Rows[i]["t_asds_stock_key_character_3"].ToString();

                                    NpgsqlParameter parm3_4 = new NpgsqlParameter("@tasds_p4", NpgsqlDbType.Varchar, 25);
                                    parm3_4.Value = _TableIn3.Rows[i]["t_asds_stock_key_character_4"].ToString();

                                    NpgsqlParameter parm3_5 = new NpgsqlParameter("@tasds_p5", NpgsqlDbType.Varchar, 25);
                                    parm3_5.Value = _TableIn3.Rows[i]["t_asds_stock_key_character_5"].ToString();

                                    NpgsqlParameter parm3_6 = new NpgsqlParameter("@tasds_p6", NpgsqlDbType.Varchar, 25);
                                    parm3_6.Value = _TableIn3.Rows[i]["t_asds_stock_key_character_6"].ToString();

                                    NpgsqlParameter parm3_7 = new NpgsqlParameter("@tasds_p7", NpgsqlDbType.Date);
                                    tempDtm = DateTime.Now;
                                    DateTime.TryParseExact(_TableIn3.Rows[i]["t_asds_stock_key_date_1"].ToString(), "yyyyMMdd", null, DateTimeStyles.None, out tempDtm);
                                    parm3_7.Value = tempDtm;

                                    NpgsqlParameter parm3_8 = new NpgsqlParameter("@tasds_p8", NpgsqlDbType.Date);
                                    tempDtm = DateTime.Now;
                                    DateTime.TryParseExact(_TableIn3.Rows[i]["t_asds_stock_key_date_2"].ToString(), "yyyyMMdd", null, DateTimeStyles.None, out tempDtm);
                                    parm3_8.Value = tempDtm;

                                    NpgsqlParameter parm3_9 = new NpgsqlParameter("@tasds_p9", NpgsqlDbType.Numeric, 15);
                                    parm3_9.Value = Convert.ToDecimal(_TableIn3.Rows[i]["t_asds_stock_key_number_1"].ToString());

                                    NpgsqlParameter parm3_10 = new NpgsqlParameter("@tasds_p10", NpgsqlDbType.Numeric, 15);
                                    parm3_10.Value = Convert.ToDecimal(_TableIn3.Rows[i]["t_asds_stock_key_number_2"].ToString());

                                    NpgsqlParameter parm3_11 = new NpgsqlParameter("@tasds_w1", NpgsqlDbType.Varchar, 15);
                                    parm3_11.Value = _TableIn3.Rows[i]["arrival_slip_detail_stockkey_key"].ToString();

                                    cmd3.Parameters.Add(parm3_1);
                                    cmd3.Parameters.Add(parm3_2);
                                    cmd3.Parameters.Add(parm3_3);
                                    cmd3.Parameters.Add(parm3_4);
                                    cmd3.Parameters.Add(parm3_5);
                                    cmd3.Parameters.Add(parm3_6);
                                    cmd3.Parameters.Add(parm3_7);
                                    cmd3.Parameters.Add(parm3_8);
                                    cmd3.Parameters.Add(parm3_9);
                                    cmd3.Parameters.Add(parm3_10);
                                    cmd3.Parameters.Add(parm3_11);

                                    exeRows = cmd3.ExecuteNonQuery();  // execute rows

                                    // Unique チェック
                                    if (exeRows != 1)
                                    {
                                        _Ur.AddExceptionMsg("update t_arrival_slip_detail_stockkey , row: " + i.ToString() + " update row <> 1");
                                        doRollback = true;
                                        //return _Ur.RetuenCode(_ClassID + 52);
                                    }
                                }

                            }

                            //update m_item 
                            //if (doRollback == false)
                            //{
                            //    NpgsqlCommand cmd4 = sqlConn.CreateCommand();
                            //    cmd4.CommandType = CommandType.Text;
                            //    cmd4.Transaction = transaction;
                            //    cmd4.Parameters.Clear();
                            //    cmd4.CommandText = @"update m_item 
                            //                          set 
                            //                            item_name_1 = @mi_p1, 
                            //                            quantity_per_pallet = @mi_p2, 
                            //                            quantity_per_pack = @mi_p3, 
                            //                            quantity_per_case = @mi_p4, 
                            //                            quantity_per_carton = @mi_p5, 
                            //                            weight_piece = @mi_p6 
                            //                          where 
                            //                            system_code = @mi_w1 
                            //                            and customer_code = @mi_w2
                            //                            and item_code_1 = @mi_w3 
                            //                            and apply_start_date 

                            //                    ";

                            //    NpgsqlParameter parm4_1 = new NpgsqlParameter("@mi_p1", NpgsqlDbType.Varchar, 12);
                            //    parm4_1.Value = _TableIn1.Rows[0]["syscode"].ToString();
                            //    NpgsqlParameter parm4_2 = new NpgsqlParameter("@mi_p2", NpgsqlDbType.Varchar, 12);
                            //    parm4_2.Value = _TableIn1.Rows[0]["cuscode"].ToString();
                            //    cmd4.Parameters.Add(parm4_1);
                            //    cmd4.Parameters.Add(parm4_2);

                            //    exeRows = cmd4.ExecuteNonQuery();  // execute rows

                            //    // Unique チェック
                            //    if (exeRows != 1)
                            //    {
                            //        _Ur.AddExceptionMsg("update row <> 1");
                            //        doRollback = true;
                            //        //return _Ur.RetuenCode(_ClassID + 52);
                            //    }
                            //}


                            //update m_parameter 
                            //if (doRollback == false)
                            //{
                            //    NpgsqlCommand cmd5 = sqlConn.CreateCommand();
                            //    cmd5.CommandType = CommandType.Text;
                            //    cmd5.Transaction = transaction;
                            //    cmd5.Parameters.Clear();
                            //    cmd5.CommandText = @"update m_parameter 
                            //                          set 
                            //                            m_p1.parameter_setting_1 = @mp_p1, 
                            //                          where 
                            //                            system_code = @mp_w1 
                            //                            and customer_code = @mp_w2 
                            //                            and parameter_code = @mp_w3 
                            //                            and m_p1.parameter_kinds = '0001'

                            //                    ";

                            //    NpgsqlParameter parm5_1 = new NpgsqlParameter("@mp_p1", NpgsqlDbType.Varchar, 12);
                            //    parm5_1.Value = _TableIn1.Rows[0]["syscode"].ToString();
                            //    NpgsqlParameter parm5_2 = new NpgsqlParameter("@mp_w1", NpgsqlDbType.Varchar, 12);
                            //    parm5_2.Value = _TableIn1.Rows[0]["cuscode"].ToString();
                            //    cmd5.Parameters.Add(parm5_1);
                            //    cmd5.Parameters.Add(parm5_2);

                            //    exeRows = cmd5.ExecuteNonQuery();  // execute rows

                            //    // Unique チェック
                            //    if (exeRows != 1)
                            //    {
                            //        _Ur.AddExceptionMsg("update row <> 1");
                            //        doRollback = true;
                            //        //return _Ur.RetuenCode(_ClassID + 52);
                            //    }
                            //}

                        }

                        // new
                        // insert t_arrival_slip_detail
                        // insert t_arrival_slip_detail_stockkey
                        if ("new".Equals(detailFlg))
                        {                            

                            //update t_arrival_slip_detail
                            if (doRollback == false)
                            {

                                //採番
                                newDetailKey = "ASD" + TokenFunc.GenUUID("N").Substring(0, 12);

                                //MAX（Row NO）
                                NpgsqlCommand selCmd1 = sqlConn.CreateCommand();
                                selCmd1.CommandType = CommandType.Text;
                                selCmd1.Parameters.Clear();
                                //String selSql = @"
                                //              select coalesce(max(arrival_slip_row_no),0) as max_row_no
                                //              from   t_arrival_slip_detail
                                //              where  arrival_slip_header_key = @headerkey
                                //            ";
                                selCmd1.CommandText = @"
                                              select max(arrival_slip_row_no) as max_row_no
                                              from   t_arrival_slip_detail
                                              where  arrival_slip_header_key = @headerkey
                                            "; ;
                                NpgsqlParameter selParm1_1 = new NpgsqlParameter("@headerkey", NpgsqlDbType.Varchar, 12);
                                selParm1_1.Value = headerkey;
                                selCmd1.Parameters.Add(selParm1_1);
                                DataTable selTb01 = new DataTable();
                                NpgsqlDataAdapter selSqladp1 = new(selCmd1);
                                selSqladp1.Fill(selTb01);

                                int newRowNo = Convert.ToInt16(selTb01.Rows[0]["max_row_no"].ToString()) + 1;


                                //Insert data
                                NpgsqlCommand cmd12 = sqlConn.CreateCommand();
                                cmd12.CommandType = CommandType.Text;
                                cmd12.Transaction = transaction;
                                cmd12.Parameters.Clear();
                                cmd12.CommandText = @"
                                                  insert
                                                  into t_arrival_slip_detail(
                                                      arrival_slip_detail_key
                                                    , arrival_slip_header_key
                                                    , arrival_slip_row_no
                                                    , item_code_1
                                                    , arrival_plan_quantity_piece
                                                    , allocate_kinds
                                                    , recipt_pay_division
                                                    , work_division
                                                    , management_department
                                                    , arrival_unit_price
                                                    , packing_quantity
                                                    , remarks
                                                    , regist_datetime
                                                    , regist_user
                                                    , update_datetime
                                                    , update_user
                                                    , update_program_id
                                                  )
                                                  values (
                                                      @tasd_p1
                                                    , @tasd_p2
                                                    , @tasd_p3
                                                    , @tasd_p4
                                                    , @tasd_p5
                                                    , @tasd_p6
                                                    , @tasd_p7
                                                    , @tasd_p8
                                                    , @tasd_p9
                                                    , @tasd_p10
                                                    , @tasd_p11
                                                    , @tasd_p12
                                                    , CURRENT_TIMESTAMP
                                                    , @tasd_p13
                                                    , CURRENT_TIMESTAMP
                                                    , @tasd_p14
                                                    , @tasd_p15
                                                  )
                                                 ";

                                NpgsqlParameter parm12_1 = new NpgsqlParameter("@tasd_p1", NpgsqlDbType.Varchar, 15);
                                parm12_1.Value = newDetailKey;

                                NpgsqlParameter parm12_2 = new NpgsqlParameter("@tasd_p2", NpgsqlDbType.Varchar, 15);
                                parm12_2.Value = headerkey;

                                NpgsqlParameter parm12_3 = new NpgsqlParameter("@tasd_p3", NpgsqlDbType.Numeric, 4);
                                parm12_3.Value = newRowNo;

                                NpgsqlParameter parm12_4 = new NpgsqlParameter("@tasd_p4", NpgsqlDbType.Varchar, 25);
                                parm12_4.Value = _TableIn3.Rows[i]["item_code_1"].ToString();


                                NpgsqlParameter parm12_5 = new NpgsqlParameter("@tasd_p5", NpgsqlDbType.Numeric, 15);
                                parm12_5.Value = Convert.ToDecimal(_TableIn3.Rows[i]["arrival_plan_quantity_piece"].ToString());

                                NpgsqlParameter parm12_6 = new NpgsqlParameter("@tasd_p6", NpgsqlDbType.Varchar, 40);
                                parm12_6.Value = _TableIn3.Rows[i]["allocate_kinds"].ToString();

                                NpgsqlParameter parm12_7 = new NpgsqlParameter("@tasd_p7", NpgsqlDbType.Varchar, 40);
                                parm12_7.Value = _TableIn3.Rows[i]["recipt_pay_division"].ToString();

                                NpgsqlParameter parm12_8 = new NpgsqlParameter("@tasd_p8", NpgsqlDbType.Varchar, 40);
                                parm12_8.Value = _TableIn3.Rows[i]["work_division"].ToString();

                                NpgsqlParameter parm12_9 = new NpgsqlParameter("@tasd_p9", NpgsqlDbType.Varchar, 40);
                                parm12_9.Value = _TableIn3.Rows[i]["management_department"].ToString();

                                NpgsqlParameter parm12_10 = new NpgsqlParameter("@tasd_p10", NpgsqlDbType.Numeric, 12);
                                parm12_10.Value = Convert.ToDecimal(_TableIn3.Rows[i]["arrival_unit_price"].ToString());

                                NpgsqlParameter parm12_11 = new NpgsqlParameter("@tasd_p11", NpgsqlDbType.Numeric, 9);
                                parm12_11.Value = Convert.ToDecimal(_TableIn3.Rows[i]["packing_quantity"].ToString());

                                NpgsqlParameter parm12_12 = new NpgsqlParameter("@tasd_p12", NpgsqlDbType.Varchar, 100);
                                parm12_12.Value = _TableIn3.Rows[i]["remarks"].ToString();

                                NpgsqlParameter parm12_13 = new NpgsqlParameter("@tasd_p13", NpgsqlDbType.Varchar, 10);
                                parm12_13.Value = _TableIn1.Rows[0]["user"].ToString();

                                NpgsqlParameter parm12_14 = new NpgsqlParameter("@tasd_p14", NpgsqlDbType.Varchar, 10);
                                parm12_14.Value = _TableIn1.Rows[0]["user"].ToString();

                                NpgsqlParameter parm12_15 = new NpgsqlParameter("@tasd_p15", NpgsqlDbType.Varchar, 6);
                                parm12_15.Value = _TableIn1.Rows[0]["program_id"].ToString();

                                cmd12.Parameters.Add(parm12_1);
                                cmd12.Parameters.Add(parm12_2);
                                cmd12.Parameters.Add(parm12_3);
                                cmd12.Parameters.Add(parm12_4);
                                cmd12.Parameters.Add(parm12_5);
                                cmd12.Parameters.Add(parm12_6);
                                cmd12.Parameters.Add(parm12_7);
                                cmd12.Parameters.Add(parm12_8);
                                cmd12.Parameters.Add(parm12_9);
                                cmd12.Parameters.Add(parm12_10);
                                cmd12.Parameters.Add(parm12_11);
                                cmd12.Parameters.Add(parm12_12);
                                cmd12.Parameters.Add(parm12_13);
                                cmd12.Parameters.Add(parm12_14);
                                cmd12.Parameters.Add(parm12_15);

                                exeRows = cmd12.ExecuteNonQuery();

                                // 結果チェック
                                if (exeRows != 1)
                                {
                                    _Ur.AddExceptionMsg("insert t_arrival_slip_detail , row: " + i.ToString() + " insert row <> 1");
                                    doRollback = true;

                                }
                            }

                            //update t_arrival_slip_detail_stockkey
                            if (doRollback == false)
                            {
                                //採番
                                String newDetailStockKey = "ASDS" + TokenFunc.GenUUID("N").Substring(0, 11);

                                NpgsqlCommand cmd13 = sqlConn.CreateCommand();
                                cmd13.CommandType = CommandType.Text;
                                cmd13.Transaction = transaction;
                                cmd13.Parameters.Clear();
                                cmd13.CommandText = @"
                                                  insert
                                                  into t_arrival_slip_detail_stockkey(
                                                      arrival_slip_detail_stockkey_key
                                                    , arrival_slip_detail_key
                                                    , stock_key_character_1
                                                    , stock_key_character_2
                                                    , stock_key_character_3
                                                    , stock_key_character_4
                                                    , stock_key_character_5
                                                    , stock_key_character_6
                                                    , stock_key_date_1
                                                    , stock_key_date_2
                                                    , stock_key_number_1
                                                    , stock_key_number_2
                                                    , regist_datetime
                                                    , regist_user
                                                    , update_datetime
                                                    , update_user
                                                    , update_program_id
                                                  )
                                                  values (
                                                      @tasds_p1
                                                    , @tasds_p2
                                                    , @tasds_p3
                                                    , @tasds_p4
                                                    , @tasds_p5
                                                    , @tasds_p6
                                                    , @tasds_p7
                                                    , @tasds_p8
                                                    , @tasds_p9
                                                    , @tasds_p10
                                                    , @tasds_p11
                                                    , @tasds_p12
                                                    , CURRENT_TIMESTAMP
                                                    , @tasds_p13
                                                    , CURRENT_TIMESTAMP
                                                    , @tasds_p14
                                                    , @tasds_p15
                                                  )
                                                ";

                                NpgsqlParameter parm13_1 = new NpgsqlParameter("@tasds_p1", NpgsqlDbType.Varchar, 15);
                                parm13_1.Value = newDetailStockKey;

                                NpgsqlParameter parm13_2 = new NpgsqlParameter("@tasds_p2", NpgsqlDbType.Varchar, 15);
                                parm13_2.Value = newDetailKey;

                                NpgsqlParameter parm13_3 = new NpgsqlParameter("@tasds_p3", NpgsqlDbType.Varchar, 25);
                                parm13_3.Value = _TableIn3.Rows[i]["t_asds_stock_key_character_1"].ToString();

                                NpgsqlParameter parm13_4 = new NpgsqlParameter("@tasds_p4", NpgsqlDbType.Varchar, 25);
                                parm13_4.Value = _TableIn3.Rows[i]["t_asds_stock_key_character_2"].ToString();

                                NpgsqlParameter parm13_5 = new NpgsqlParameter("@tasds_p5", NpgsqlDbType.Varchar, 25);
                                parm13_5.Value = _TableIn3.Rows[i]["t_asds_stock_key_character_3"].ToString();

                                NpgsqlParameter parm13_6 = new NpgsqlParameter("@tasds_p6", NpgsqlDbType.Varchar, 25);
                                parm13_6.Value = _TableIn3.Rows[i]["t_asds_stock_key_character_4"].ToString();

                                NpgsqlParameter parm13_7 = new NpgsqlParameter("@tasds_p7", NpgsqlDbType.Varchar, 25);
                                parm13_7.Value = _TableIn3.Rows[i]["t_asds_stock_key_character_5"].ToString();

                                NpgsqlParameter parm13_8 = new NpgsqlParameter("@tasds_p8", NpgsqlDbType.Varchar, 25);
                                parm13_8.Value = _TableIn3.Rows[i]["t_asds_stock_key_character_6"].ToString();


                                NpgsqlParameter parm13_9 = new NpgsqlParameter("@tasds_p9", NpgsqlDbType.Date);
                                tempDtm = DateTime.Now;
                                DateTime.TryParseExact(_TableIn3.Rows[i]["t_asds_stock_key_date_1"].ToString(), "yyyyMMdd", null, DateTimeStyles.None, out tempDtm);
                                parm13_9.Value = tempDtm;

                                NpgsqlParameter parm13_10 = new NpgsqlParameter("@tasds_p10", NpgsqlDbType.Date);
                                tempDtm = DateTime.Now;
                                DateTime.TryParseExact(_TableIn3.Rows[i]["t_asds_stock_key_date_2"].ToString(), "yyyyMMdd", null, DateTimeStyles.None, out tempDtm);
                                parm13_10.Value = tempDtm;

                                NpgsqlParameter parm13_11 = new NpgsqlParameter("@tasds_p11", NpgsqlDbType.Numeric, 14);
                                parm13_11.Value = Convert.ToDecimal(_TableIn3.Rows[i]["t_asds_stock_key_number_1"].ToString());

                                NpgsqlParameter parm13_12 = new NpgsqlParameter("@tasds_p12", NpgsqlDbType.Numeric, 14);
                                parm13_12.Value = Convert.ToDecimal(_TableIn3.Rows[i]["t_asds_stock_key_number_2"].ToString());

                                NpgsqlParameter parm13_13 = new NpgsqlParameter("@tasds_p13", NpgsqlDbType.Varchar, 10);
                                parm13_13.Value = _TableIn1.Rows[0]["user"].ToString();

                                NpgsqlParameter parm13_14 = new NpgsqlParameter("@tasds_p14", NpgsqlDbType.Varchar, 10);
                                parm13_14.Value = _TableIn1.Rows[0]["user"].ToString();

                                NpgsqlParameter parm13_15 = new NpgsqlParameter("@tasds_p15", NpgsqlDbType.Varchar, 6);
                                parm13_15.Value = _TableIn1.Rows[0]["program_id"].ToString();

                                cmd13.Parameters.Add(parm13_1);
                                cmd13.Parameters.Add(parm13_2);
                                cmd13.Parameters.Add(parm13_3);
                                cmd13.Parameters.Add(parm13_4);
                                cmd13.Parameters.Add(parm13_5);
                                cmd13.Parameters.Add(parm13_6);
                                cmd13.Parameters.Add(parm13_7);
                                cmd13.Parameters.Add(parm13_8);
                                cmd13.Parameters.Add(parm13_9);
                                cmd13.Parameters.Add(parm13_10);
                                cmd13.Parameters.Add(parm13_11);
                                cmd13.Parameters.Add(parm13_12);
                                cmd13.Parameters.Add(parm13_13);
                                cmd13.Parameters.Add(parm13_14);
                                cmd13.Parameters.Add(parm13_15);

                                exeRows = cmd13.ExecuteNonQuery();

                                // 結果チェック
                                if (exeRows != 1)
                                {
                                    _Ur.AddExceptionMsg("insert t_arrival_slip_detail_stockkey , row: " + i.ToString() + " insert row <> 1");
                                    doRollback = true;
                                }
                            }

                        }


                        //delete 
                        // really delete  or  update the  delete_flg 
                        // t_arrival_slip_detail
                        // t_arrival_slip_detail_stockkey
                        if ("delete".Equals(detailFlg))
                        {

                        }


                    }

                }


                // Commit || Rollback
                if (doRollback == false)
                {
                    transaction.Commit();
                    return _Ur.RetuenCode(0);
                }
                else
                {
                    transaction.Rollback();
                    return _Ur.RetuenCode(_ClassID + 52);
                }
            }
            catch (Exception ex)
            {
                if (transaction!= null) { transaction.Rollback(); }                

                _Ur.AddExceptionMsg("Exception Class: " + "NkYoteiDataUpdate - DataProcess");
                _Ur.AddExceptionMsg("Exception: " + ex.Message);
                if (ex.InnerException != null)
                {
                    _Ur.AddExceptionMsg("InnerException: ");
                    _Ur.AddExceptionMsg(String.Concat(ex.InnerException.StackTrace, ex.InnerException.Message));
                }
                return _Ur.RetuenCode(-(_ClassID + 53));
            }
            finally
            {
                if (transaction != null) { transaction.Dispose(); }
                DbMethod.CloseConnection(sqlConn);
            }

        }





        //入荷予定データを取得する。
        //入荷明細VIEWから入荷済数を取得する。
        //仕入先マスタから仕入先名称を取得する

        //入荷予定データを削除（論理削除）する。対象は入荷予定ヘッダテーブル。
        //入荷予定データを削除（論理削除）する。対象は入荷伝票明細テーブル。
        //入荷予定データを削除（論理削除）する。対象は入荷伝票明細_在庫キーテーブル。

        //入荷予定データを新規追加する。対象は入荷予定ヘッダテーブル。新規追加したレコードのtable_keyの値を実行元に返す。
        //入荷予定データを新規追加する。対象は入荷伝票明細テーブル。新規追加したレコードのtable_keyの値を実行元に返す。
        //入荷予定データを新規追加する。対象は入荷伝票明細_在庫キーテーブル。

        //入荷予定データを更新する。対象は入荷予定ヘッダテーブル。
        //入荷予定データを更新する。対象は入荷伝票明細テーブル。
        //入荷予定データを更新する。対象は入荷伝票明細_在庫キーテーブル。

        //採番種別マスタと採番管理テーブルから採番に必要な情報を取得する。
        //採番管理テーブルに当日日付の採番データを挿入する。
        //採番管理テーブルの当日日付の採番データを更新する。

    }
}
