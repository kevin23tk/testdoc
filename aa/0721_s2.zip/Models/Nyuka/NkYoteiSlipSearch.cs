﻿using demo1.Common;
using Npgsql;
using NpgsqlTypes;
using System.Collections.Generic;
using System.Data;
using System.Globalization;

namespace demo1.Models.Nyuka
{
    /// <summary>
    /// Author: Kamikawa
    /// Date: 2023-05
    /// LastEditTime: 
    /// Description: 入荷予定画面
    /// 
    /// 関連するモジュル
    /// NkYoteiInsertCheck -- 新規前に入荷伝票番号の存在確認
    /// NkYoteiDataSearch -- 入荷伝票番号より検索
    /// NkYoteiAutoSupplier -- 仕入先マスタから仕入先名称を取得する
    /// NkYoteiDataUpdate -- 入力データのDB更新
    /// NkYoteiSlipSearch -- 入荷伝票番号マスタ検索
    /// NkYoteiDataDelete -- 入荷伝票番号より削除（論理削除）
    /// </summary>
    public class NkYoteiSlipSearch : PostCaseCls
    {

        public NkYoteiSlipSearch()
        {
            this._ClassID = ClassCode.GetClassId(typeof(NkYoteiSlipSearch));
        }



        // POST から実行する
        public void DoPostFunc()
        {

            #region ----------- Request Data の取得 -------------

            // Request Data は Json 形式です。

            //{
            //  datetime: "2023-02-28 10:38:56",
            //  loginid: "L001",
            //  devid: "D001",
            //  action: "A001",
            //  lang: "ja-jp",
            //  dl1max: "1",
            //  dl2max: "",
            //  dl3max: "",
            //  dl1: [
            //        { c: ["syscode", "cuscode", "datebegin", "dateend", "slipcode", "liketype"]}, 
            //        { c: ["sys01", "cus01", "20220301", "20220331", "AAA", "like_begin"] }
            //       ],
            //  dl2: [],
            //  dl3: [],
            //}


            // Usage:
            // DataTable 形式のデータ取得
            // JsonParamのパラメータより最大３つListデータを取得可能です。
            // すでに自動でList-->DataTableを変換しました。

            // Set _DataSetIn.Tables["dt1"] --> _TableIn1
            // Set _DataSetIn.Tables["dt2"] --> _TableIn2
            // Set _DataSetIn.Tables["dt3"] --> _TableIn3
            GetTablesFromDataSet();

            // DataTable は以下のとおりで使える
            //_TableIn1.Rows[0]["name"].ToString() --> "田中"

            // Json Class 形式のデータ取得
            //string sLogin = this._JobjIn.loginid;
            //string sLang = this._JobjIn.lang;

            #endregion


            //クラスのプロセス実行
            ProcessFlow();


            #region ----------- Response JsonClassの作成 -------------



            //    public class JobjOut
            //{
            //    public string datetime = "";
            //    public string code = "";
            //    public string msg = "";
            //    public string msgd = "";        // debug + Exception Msg
            //    public string lang = "";
            //    public string dl1max = "";
            //    public string dl2max = "";
            //    public string dl3max = "";
            //    public string dl4max = "";
            //    public string dl5max = "";
            //    public Data_dl[]? dl1;
            //    public Data_dl[]? dl2;
            //    public Data_dl[]? dl3;
            //    public Data_dl[]? dl4;
            //    public Data_dl[]? dl5;
            //}

            //返信用データを _TableOut1 ～ _TableOut5 に設定する
            SetResponseJsonClass();


            #endregion

        }



        //流程处理
        public UtilityReturn ProcessFlow()
        {
            //step1 データチェック
            DataCheck();
            if (_Ur._ReInt != 0) { return _Ur; }

            //step2
            // .......

            //step3
            // .......

            //stepN データ处理
            DataProcess();
            if (_Ur._ReInt != 0) { return _Ur; }

            return _Ur;
        }

        private UtilityReturn DataCheck()
        {
            if (UtilityFunc.IsEmptyDataTable(_TableIn1))
            {
                _Ur.AddExceptionMsg("_TableIn1 パラメータ Empty.");
                return _Ur.RetuenCode(_ClassID + 31);
            }

            // slipno 空欄でもOK です

            // Column 存在チエック
            //DataColumnCollection columns = _TableIn1.Columns;
            //if (columns.Contains("slipno") == false)
            //{
            //    _Ur.AddExceptionMsg("_TableIn1 column slipno not exist.");
            //    return _Ur.RetuenCode(_ClassID + 32);
            //}

            ////必須項目チェック
            //string ss = UtilityFunc.ObjToString(_TableIn1.Rows[0]["slipno"]);
            //if (string.IsNullOrEmpty(ss))
            //{
            //    _Ur.AddExceptionMsg("パラメータ slipno is Empty.");
            //    return _Ur.RetuenCode(_ClassID + 33);
            //}

            return _Ur.RetuenCode(0);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public UtilityReturn DataProcess()
        {
            NpgsqlConnection sqlConn = DbMethod._DummyConn;
            NpgsqlTransaction? transaction = null;
            bool doRollback = false;
            int exeRows = -1;

            try
            {
                // DB Connection の取得
                //sqlConn = new(EnvConst.DB_CONSTR);
                //sqlConn.Open();
                UtilityReturn reUr = DbMethod.GetConnection(out sqlConn);
                if (reUr._ReInt != 0) 
                {
                    return _Ur.RetuenMerge(reUr);
                }

                // Transaction 作成
                transaction = sqlConn.BeginTransaction();


                // 存在チェック
                if (doRollback == false) 
                {
                    NpgsqlCommand cmd1 = sqlConn.CreateCommand();
                    cmd1.CommandType = CommandType.Text;
                    cmd1.Transaction= transaction;          // 必要ないか
                    cmd1.Parameters.Clear();

                    // 検索方法:  前方一致、     後方一致、   部分一致、   完全一致
                    //            like_begin     like_end     like_part    like_same

                                    //select arrival_slip_no, arrival_plan_date
                                    //    from t_arrival_slip_header
                                    //    where system_code = 'sys01'
                                    //    and customer_code = 'cus01'
                                    //    and delete_flag = '0'
                                    //    and arrival_plan_date <= DATE '2022-03-31'
                                    //    and arrival_plan_date >= DATE '2022-03-01'
                                    //    and arrival_slip_no like '%AAA';

                    string sqlLike = UtilityFunc.ObjToString(_TableIn1.Rows[0]["liketype"]);
                    string tempSql = "";
                    string tempSlipno = UtilityFunc.ObjToString(_TableIn1.Rows[0]["slipno"]);
                    if (string.IsNullOrEmpty(tempSlipno)) { sqlLike = "slipno_blank"; }

                    if ("slipno_blank".Equals(sqlLike))
                    {
                        tempSql = @"select arrival_slip_no, arrival_plan_date, arrival_slip_header_key
                                        from t_arrival_slip_header
                                        where system_code = @syscode
                                        and customer_code = @cuscode 
                                        and delete_flag = '0'
                                        and arrival_plan_date <= @dateend
                                        and arrival_plan_date >= @datebegin ;";
                    }
                    else if("equal".Equals(sqlLike))
                    {
                        tempSql = @"select arrival_slip_no, arrival_plan_date, arrival_slip_header_key
                                        from t_arrival_slip_header
                                        where system_code = @syscode
                                        and customer_code = @cuscode 
                                        and delete_flag = '0'
                                        and arrival_plan_date <= @dateend
                                        and arrival_plan_date >= @datebegin
                                        and arrival_slip_no = @slipno;";
                    }
                    else
                    {
                        tempSql = @"select arrival_slip_no, arrival_plan_date, arrival_slip_header_key
                                        from t_arrival_slip_header
                                        where system_code = @syscode
                                        and customer_code = @cuscode 
                                        and delete_flag = '0'
                                        and arrival_plan_date <= @dateend
                                        and arrival_plan_date >= @datebegin
                                        and arrival_slip_no like @slipno;";
                    }

                    cmd1.CommandText = tempSql;

                    NpgsqlParameter parm1_1 = new NpgsqlParameter("@syscode", NpgsqlDbType.Varchar, 12);
                    parm1_1.Value = _TableIn1.Rows[0]["syscode"].ToString();
                    NpgsqlParameter parm1_2 = new NpgsqlParameter("@cuscode", NpgsqlDbType.Varchar, 12);
                    parm1_2.Value = _TableIn1.Rows[0]["cuscode"].ToString();

                    //parm1.Value = new DateTime(2022, 2, 4);
                    //bool b = DateTime.TryParseExact("20210419", "yyyyMMdd", null, DateTimeStyles.None, out d);
                    DateTime tempDtm = DateTime.Now;
                    DateTime.TryParseExact(_TableIn1.Rows[0]["datebegin"].ToString(), "yyyyMMdd", null, DateTimeStyles.None, out tempDtm);
                    NpgsqlParameter parm1_3 = new NpgsqlParameter("@datebegin", NpgsqlDbType.Date);
                    parm1_3.Value = tempDtm;

                    DateTime.TryParseExact(_TableIn1.Rows[0]["dateend"].ToString(), "yyyyMMdd", null, DateTimeStyles.None, out tempDtm);
                    NpgsqlParameter parm1_4 = new NpgsqlParameter("@dateend", NpgsqlDbType.Date);
                    parm1_4.Value = tempDtm;

                    cmd1.Parameters.Add(parm1_1);
                    cmd1.Parameters.Add(parm1_2);
                    cmd1.Parameters.Add(parm1_3);
                    cmd1.Parameters.Add(parm1_4);

                    if ("slipno_blank".Equals(sqlLike) == false)
                    {
                        NpgsqlParameter parm1_5 = new NpgsqlParameter("@slipno", NpgsqlDbType.Varchar, 25);
                        if ("like_begin".Equals(sqlLike))
                        {
                            parm1_5.Value = _TableIn1.Rows[0]["slipno"].ToString() + "%";
                        }
                        else if ("like_end".Equals(sqlLike))
                        {
                            parm1_5.Value = "%" + _TableIn1.Rows[0]["slipno"].ToString();
                        }
                        else if ("like_part".Equals(sqlLike))
                        {
                            parm1_5.Value = "%" + _TableIn1.Rows[0]["slipno"].ToString() + "%";
                        }
                        else
                        {
                            //equal
                            parm1_5.Value = _TableIn1.Rows[0]["slipno"].ToString();
                        }

                        cmd1.Parameters.Add(parm1_5);
                    }
                    

                    DataTable tb01 = new DataTable();
                    NpgsqlDataAdapter sqladp1 = new(cmd1);
                    sqladp1.Fill(tb01);

                    //データ存在しない
                    if (UtilityFunc.IsEmptyDataTable(tb01))
                    {
                        _Ur.AddExceptionMsg("tb01 データが存在しない！");
                        doRollback = true;
                        //return _Ur.RetuenCode(_ClassID + 52);
                    }

                    // Unique チェック
                    //if (tb01.Rows.Count!= 1)
                    //{
                    //    _Ur.AddExceptionMsg("tb01 データはUnique ではない！");
                    //    doRollback = true;
                    //    //return _Ur.RetuenCode(_ClassID + 52);
                    //}

                    //戻り DataTable
                    _TableOut1 = tb01;
                }                


                // Commit || Rollback
                if (doRollback == false)
                {
                    transaction.Commit();
                    return _Ur.RetuenCode(0);
                }
                else 
                {
                    transaction.Rollback();
                    return _Ur.RetuenCode(_ClassID + 52);
                }

            }
            catch (Exception ex)
            {
                if (transaction!= null) { transaction.Rollback(); }                

                _Ur.AddExceptionMsg("Exception Class: " + "NkYoteiSlipSearch - DataProcess");
                _Ur.AddExceptionMsg("Exception: " + ex.Message);
                if (ex.InnerException != null)
                {
                    _Ur.AddExceptionMsg("InnerException: ");
                    _Ur.AddExceptionMsg(String.Concat(ex.InnerException.StackTrace, ex.InnerException.Message));
                }
                return _Ur.RetuenCode(-(_ClassID + 53));
            }
            finally
            {
                if (transaction != null) { transaction.Dispose(); }
                DbMethod.CloseConnection(sqlConn);
            }

        }


        




    }
}
