﻿using demo1.Common;
using Npgsql;
using NpgsqlTypes;
using System.Collections.Generic;
using System.Data;

namespace demo1.Models.Nyuka
{
    /// <summary>
    /// Author: Kamikawa
    /// Date: 2023-05
    /// LastEditTime: 
    /// Description:  入荷予定画面
    /// 
    /// 関連するモジュル
    /// NkYoteiInsertCheck -- 新規前に入荷伝票番号の存在確認
    /// NkYoteiDataSearch -- 入荷伝票番号より検索
    /// NkYoteiAutoSupplier -- 仕入先マスタから仕入先名称を取得する
    /// NkYoteiDataUpdate -- 入力データのDB更新
    /// NkYoteiSlipSearch -- 入荷伝票番号マスタ検索
    /// NkYoteiDataDelete -- 入荷伝票番号より削除（論理削除）
    /// </summary>
    public class NkYoteiAutoSupplier : PostCaseCls
    {

        public NkYoteiAutoSupplier()
        {
            this._ClassID = ClassCode.GetClassId(typeof(NkYoteiAutoSupplier));
        }



        // POST から実行する
        public void DoPostFunc()
        {

            #region ----------- Request Data の取得 -------------

            // Request Data は Json 形式です。

            //{
            //  datetime: "2023-02-28 10:38:56",
            //  loginid: "L001",
            //  devid: "D001",
            //  action: "A001",
            //  lang: "ja-jp",
            //  dl1max: "1",
            //  dl2max: "",
            //  dl3max: "",
            //  dl1: [
            //        { c: ["syscode", "cuscode", "suppliercode", "searchtype"]},     searchtype = getmaster / getonename
            //        { c: ["sys01", "cus01", "sup01", "getmaster"] }
            //       ],
            //  dl2: [],
            //  dl3: [],
            //}


            // Usage:
            // DataTable 形式のデータ取得
            // JsonParamのパラメータより最大３つListデータを取得可能です。
            // すでに自動でList-->DataTableを変換しました。

            // Set _DataSetIn.Tables["dt1"] --> _TableIn1
            // Set _DataSetIn.Tables["dt2"] --> _TableIn2
            // Set _DataSetIn.Tables["dt3"] --> _TableIn3
            GetTablesFromDataSet();

            // DataTable は以下のとおりで使える
            //_TableIn1.Rows[0]["syscode"].ToString() --> "sys1"

            // Json Class 形式のデータ取得
            //string sLogin = this._JobjIn.loginid;
            //string sLang = this._JobjIn.lang;

            #endregion


            //クラスのプロセス実行
            ProcessFlow();


            #region ----------- Response JsonClassの作成 -------------



            //    public class JobjOut
            //{
            //    public string datetime = "";
            //    public string code = "";
            //    public string msg = "";
            //    public string msgd = "";        // debug + Exception Msg
            //    public string lang = "";
            //    public string dl1max = "";
            //    public string dl2max = "";
            //    public string dl3max = "";
            //    public string dl4max = "";
            //    public string dl5max = "";
            //    public Data_dl[]? dl1;
            //    public Data_dl[]? dl2;
            //    public Data_dl[]? dl3;
            //    public Data_dl[]? dl4;
            //    public Data_dl[]? dl5;
            //}

            //返信用データを _TableOut1 ～ _TableOut5 に設定する
            SetResponseJsonClass();


            #endregion

        }



        //流程处理
        public UtilityReturn ProcessFlow()
        {
            //step1 データチェック
            DataCheck();
            if (_Ur._ReInt != 0) { return _Ur; }

            //step2
            // .......

            //step3
            // .......

            //stepN データ处理
            DataProcess();
            if (_Ur._ReInt != 0) { return _Ur; }

            return _Ur;
        }

        private UtilityReturn DataCheck()
        {
            if (UtilityFunc.IsEmptyDataTable(_TableIn1))
            {
                _Ur.AddExceptionMsg("_TableIn1 パラメータ Empty.");
                return _Ur.RetuenCode(_ClassID + 31);
            }

            // Column 存在チエック
            DataColumnCollection columns = _TableIn1.Columns;
            if (columns.Contains("searchtype") == false)
            {
                _Ur.AddExceptionMsg("_TableIn1 column searchtype not exist.");
                return _Ur.RetuenCode(_ClassID + 32);
            }

            //必須項目チェック
            string ss = UtilityFunc.ObjToString(_TableIn1.Rows[0]["searchtype"]);
            if (string.IsNullOrEmpty(ss))
            {
                _Ur.AddExceptionMsg("パラメータ searchtype is Empty.");
                return _Ur.RetuenCode(_ClassID + 33);
            }

            return _Ur.RetuenCode(0);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public UtilityReturn DataProcess()
        {
            NpgsqlConnection sqlConn = DbMethod._DummyConn;
            NpgsqlTransaction? transaction = null;
            bool doRollback = false;
            int exeRows = -1;

            try
            {
                // DB Connection の取得
                //sqlConn = new(EnvConst.DB_CONSTR);
                //sqlConn.Open();
                UtilityReturn reUr = DbMethod.GetConnection(out sqlConn);
                if (reUr._ReInt != 0) 
                {
                    return _Ur.RetuenMerge(reUr);
                }

                // Transaction 作成
                transaction = sqlConn.BeginTransaction();                

                string sType = UtilityFunc.ObjToString(_TableIn1.Rows[0]["searchtype"]);

                // Get Master
                if ((doRollback == false)&&(sType.Equals("getmaster")))
                {
                    NpgsqlCommand cmd1 = sqlConn.CreateCommand();
                    cmd1.CommandType = CommandType.Text;
                    cmd1.Transaction= transaction;          // 必要ないか
                    cmd1.Parameters.Clear();

                    string tempSql = @"select
                                            m_s.supplier_code,
                                            m_s.supplier_name,
                                            m_s.customer_code
                                        from
                                            m_supplier m_s
                                        where
                                            m_s.system_code = @syscode
                                            and m_s.customer_code = @cuscode
                                            and m_s.apply_start_date <= CURRENT_TIMESTAMP
                                            and m_s.apply_end_date >= CURRENT_TIMESTAMP";

                    string tempDate = DateTime.Now.ToString("yyyy-MM-dd");
                    tempDate = "DATE '" + tempDate + "'";
                    tempSql = tempSql.Replace("CURRENT_TIMESTAMP", tempDate);

                    cmd1.CommandText = tempSql;

                    NpgsqlParameter parm1_1 = new NpgsqlParameter("@syscode", NpgsqlDbType.Varchar, 12);
                    parm1_1.Value = _TableIn1.Rows[0]["syscode"].ToString();
                    NpgsqlParameter parm1_2 = new NpgsqlParameter("@cuscode", NpgsqlDbType.Varchar, 12);
                    parm1_2.Value = _TableIn1.Rows[0]["cuscode"].ToString();
                    //NpgsqlParameter parm1_3 = new NpgsqlParameter("@suppliercode", NpgsqlDbType.Varchar, 12);
                    //parm1_3.Value = _TableIn1.Rows[0]["suppliercode"].ToString();
                    cmd1.Parameters.Add(parm1_1);
                    cmd1.Parameters.Add(parm1_2);
                    //cmd1.Parameters.Add(parm1_3);

                    DataTable tb01 = new DataTable();
                    NpgsqlDataAdapter sqladp1 = new(cmd1);
                    sqladp1.Fill(tb01);

                    //データ存在しない
                    if (UtilityFunc.IsEmptyDataTable(tb01))
                    {
                        _Ur.AddExceptionMsg("tb01 データが存在しない！");
                        doRollback = true;
                        //return _Ur.RetuenCode(_ClassID + 52);
                    }
                    
                    //戻り DataTable
                    _TableOut1 = tb01;
                }



                // Get One Name
                if ((doRollback == false) && (sType.Equals("getonename")))
                {
                    NpgsqlCommand cmd2 = sqlConn.CreateCommand();
                    cmd2.CommandType = CommandType.Text;
                    cmd2.Transaction = transaction;          // 必要ないか
                    cmd2.Parameters.Clear();

                    string tempSql2 = @"select
                                            m_s.supplier_name
                                        from
                                            m_supplier m_s
                                        where
                                            m_s.system_code = @syscode
                                            and m_s.customer_code = @cuscode
                                            and m_s.supplier_code = @suppliercode
                                            and m_s.apply_start_date <= CURRENT_TIMESTAMP
                                            and m_s.apply_end_date >= CURRENT_TIMESTAMP";

                    string tempDate2 = DateTime.Now.ToString("yyyy-MM-dd");
                    tempDate2 = "DATE '" + tempDate2 + "'";
                    tempSql2 = tempSql2.Replace("CURRENT_TIMESTAMP", tempDate2);

                    cmd2.CommandText = tempSql2;

                    NpgsqlParameter parm2_1 = new NpgsqlParameter("@syscode", NpgsqlDbType.Varchar, 12);
                    parm2_1.Value = _TableIn1.Rows[0]["syscode"].ToString();
                    NpgsqlParameter parm2_2 = new NpgsqlParameter("@cuscode", NpgsqlDbType.Varchar, 12);
                    parm2_2.Value = _TableIn1.Rows[0]["cuscode"].ToString();
                    NpgsqlParameter parm2_3 = new NpgsqlParameter("@suppliercode", NpgsqlDbType.Varchar, 12);
                    parm2_3.Value = _TableIn1.Rows[0]["suppliercode"].ToString();
                    cmd2.Parameters.Add(parm2_1);
                    cmd2.Parameters.Add(parm2_2);
                    cmd2.Parameters.Add(parm2_3);

                    DataTable tb01 = new DataTable();
                    NpgsqlDataAdapter sqladp2 = new(cmd2);
                    sqladp2.Fill(tb01);

                    //データ存在しない
                    if (UtilityFunc.IsEmptyDataTable(tb01))
                    {
                        _Ur.AddExceptionMsg("tb01 データが存在しない！");
                        doRollback = true;
                        //return _Ur.RetuenCode(_ClassID + 52);
                    }

                    // Unique チェック
                    if (tb01.Rows.Count != 1)
                    {
                        _Ur.AddExceptionMsg("tb01 データはUnique ではない！");
                        doRollback = true;
                        //return _Ur.RetuenCode(_ClassID + 52);
                    }

                    //戻り DataTable
                    _TableOut1 = tb01;
                }

                // Commit || Rollback
                if (doRollback == false)
                {
                    transaction.Commit();
                    return _Ur.RetuenCode(0);
                }
                else 
                {
                    transaction.Rollback();
                    return _Ur.RetuenCode(_ClassID + 52);
                }

            }
            catch (Exception ex)
            {
                if (transaction!= null) { transaction.Rollback(); }                

                _Ur.AddExceptionMsg("Exception Class: " + "NkYoteiAutoSupplier - DataProcess");
                _Ur.AddExceptionMsg("Exception: " + ex.Message);
                if (ex.InnerException != null)
                {
                    _Ur.AddExceptionMsg("InnerException: ");
                    _Ur.AddExceptionMsg(String.Concat(ex.InnerException.StackTrace, ex.InnerException.Message));
                }
                return _Ur.RetuenCode(-(_ClassID + 53));
            }
            finally
            {
                if (transaction != null) { transaction.Dispose(); }
                DbMethod.CloseConnection(sqlConn);
            }

        }


        




    }
}
