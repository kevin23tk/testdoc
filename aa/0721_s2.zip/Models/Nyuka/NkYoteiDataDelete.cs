﻿using demo1.Common;
using Npgsql;
using NpgsqlTypes;
using System.Collections.Generic;
using System.Data;

namespace demo1.Models.Nyuka
{
    /// <summary>
    /// Author: Kamikawa
    /// Date: 2023-05
    /// LastEditTime: 
    /// Description: 入荷予定画面
    /// 
    /// 関連するモジュル
    /// NkYoteiInsertCheck -- 新規前に入荷伝票番号の存在確認
    /// NkYoteiDataSearch -- 入荷伝票番号より検索
    /// NkYoteiAutoSupplier -- 仕入先マスタから仕入先名称を取得する
    /// NkYoteiDataUpdate -- 入力データのDB更新
    /// NkYoteiSlipSearch -- 入荷伝票番号マスタ検索
    /// NkYoteiDataDelete -- 入荷伝票番号より削除（論理削除）
    /// </summary>
    public class NkYoteiDataDelete : PostCaseCls
    {

        public NkYoteiDataDelete()
        {
            this._ClassID = ClassCode.GetClassId(typeof(NkYoteiDataDelete));
        }



        // POST から実行する
        public void DoPostFunc()
        {

            #region ----------- Request Data の取得 -------------

            // Request Data は Json 形式です。

            //{
            //  datetime: "2023-02-28 10:38:56",
            //  loginid: "L001",
            //  devid: "D001",
            //  action: "A001",
            //  lang: "ja-jp",
            //  dl1max: "1",
            //  dl2max: "",
            //  dl3max: "",
            //  dl1: [
            //        { c: ["name", "gender", "age"]}, 
            //        { c: ["田中", "男", "35"] }
            //       ],
            //  dl2: [],
            //  dl3: [],
            //}


            // Usage:
            // DataTable 形式のデータ取得
            // JsonParamのパラメータより最大３つListデータを取得可能です。
            // すでに自動でList-->DataTableを変換しました。

            // Set _DataSetIn.Tables["dt1"] --> _TableIn1
            // Set _DataSetIn.Tables["dt2"] --> _TableIn2
            // Set _DataSetIn.Tables["dt3"] --> _TableIn3
            GetTablesFromDataSet();

            // DataTable は以下のとおりで使える
            //_TableIn1.Rows[0]["name"].ToString() --> "田中"

            // Json Class 形式のデータ取得
            //string sLogin = this._JobjIn.loginid;
            //string sLang = this._JobjIn.lang;

            #endregion


            //クラスのプロセス実行
            ProcessFlow();


            #region ----------- Response JsonClassの作成 -------------



            //    public class JobjOut
            //{
            //    public string datetime = "";
            //    public string code = "";
            //    public string msg = "";
            //    public string msgd = "";        // debug + Exception Msg
            //    public string lang = "";
            //    public string dl1max = "";
            //    public string dl2max = "";
            //    public string dl3max = "";
            //    public string dl4max = "";
            //    public string dl5max = "";
            //    public Data_dl[]? dl1;
            //    public Data_dl[]? dl2;
            //    public Data_dl[]? dl3;
            //    public Data_dl[]? dl4;
            //    public Data_dl[]? dl5;
            //}

            //返信用データを _TableOut1 ～ _TableOut5 に設定する
            SetResponseJsonClass();


            #endregion

        }



        //流程处理
        public UtilityReturn ProcessFlow()
        {
            //step1 データチェック
            DataCheck();
            if (_Ur._ReInt != 0) { return _Ur; }

            //step2
            // .......

            //step3
            // .......

            //stepN データ处理
            DataProcess();
            if (_Ur._ReInt != 0) { return _Ur; }

            return _Ur;
        }

        private UtilityReturn DataCheck()
        {
            if (UtilityFunc.IsEmptyDataTable(_TableIn1))
            {
                _Ur.AddExceptionMsg("_TableIn1 パラメータ Empty.");
                return _Ur.RetuenCode(_ClassID + 31);
            }

            // Column 存在チエック
            DataColumnCollection columns = _TableIn1.Columns;
            if (columns.Contains("header_key") == false)
            {
                _Ur.AddExceptionMsg("_TableIn1 column header_key not exist.");
                return _Ur.RetuenCode(_ClassID + 32);
            }

            //必須項目チェック
            string ss = UtilityFunc.ObjToString(_TableIn1.Rows[0]["header_key"]);
            if (string.IsNullOrEmpty(ss))
            {
                _Ur.AddExceptionMsg("パラメータ header_key is Empty.");
                return _Ur.RetuenCode(_ClassID + 33);
            }

            return _Ur.RetuenCode(0);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public UtilityReturn DataProcess()
        {
            NpgsqlConnection sqlConn = DbMethod._DummyConn;
            NpgsqlTransaction? transaction = null;
            bool doRollback = false;
            int exeRows = -1;

            try
            {
                // DB Connection の取得
                //sqlConn = new(EnvConst.DB_CONSTR);
                //sqlConn.Open();
                UtilityReturn reUr = DbMethod.GetConnection(out sqlConn);
                if (reUr._ReInt != 0) 
                {
                    return _Ur.RetuenMerge(reUr);
                }

                // Transaction 作成
                transaction = sqlConn.BeginTransaction();

                //入荷予定データを削除（論理削除）する。対象は入荷予定ヘッダテーブル。
                //入荷予定データを削除（論理削除）する。対象は入荷伝票明細テーブル。
                //入荷予定データを削除（論理削除）する。対象は入荷伝票明細_在庫キーテーブル。

                // 存在チェック
                if (doRollback == false) 
                {
                    NpgsqlCommand cmd1 = sqlConn.CreateCommand();
                    cmd1.CommandType = CommandType.Text;
                    cmd1.Transaction= transaction; 
                    cmd1.Parameters.Clear();
                    cmd1.CommandText = @"update t_arrival_slip_header
                                        set
                                            delete_flag = '1' 
                                            , update_datetime = @CURRENT_TIMESTAMP 
                                            , update_user = @userid 
                                            , update_program_id = 'NK0020' 
                                        where
                                            arrival_slip_header_key = @header_key 
                                            and delete_flag = '0'
                                        ";

                    NpgsqlParameter parm1_1 = new NpgsqlParameter("@CURRENT_TIMESTAMP", NpgsqlDbType.Date);
                    parm1_1.Value = DateTime.Now;
                    NpgsqlParameter parm1_2 = new NpgsqlParameter("@userid", NpgsqlDbType.Varchar, 10);
                    parm1_2.Value = _TableIn1.Rows[0]["userid"].ToString();
                    NpgsqlParameter parm1_3 = new NpgsqlParameter("@header_key", NpgsqlDbType.Varchar, 15);
                    parm1_3.Value = _TableIn1.Rows[0]["header_key"].ToString();                  

                    cmd1.Parameters.Add(parm1_1);
                    cmd1.Parameters.Add(parm1_2);
                    cmd1.Parameters.Add(parm1_3);

                    exeRows = cmd1.ExecuteNonQuery();  // execute rows
                    if (exeRows != 1)
                    {
                        _Ur.AddExceptionMsg("cmd1 更新失敗！");
                        doRollback = true;
                        //return _Ur.RetuenCode(_ClassID + 52);
                    }
                }

                // Update データ
                if (doRollback == false)
                {
                    NpgsqlCommand cmd2 = sqlConn.CreateCommand();
                    cmd2.CommandType = CommandType.Text;
                    cmd2.Transaction = transaction;          // 必要ないか
                    cmd2.Parameters.Clear();
                    cmd2.CommandText = @"update t_arrival_slip_detail
                                            set
                                                delete_flag = '1'
                                                , update_datetime = @CURRENT_TIMESTAMP
                                                , update_user = @userid 
                                                , update_program_id = 'NK0020'
                                            where
                                                arrival_slip_header_key = @header_key 
                                                and delete_flag = '0' 
                                        ";

                    NpgsqlParameter parm2_1 = new NpgsqlParameter("@CURRENT_TIMESTAMP", NpgsqlDbType.Date);
                    parm2_1.Value = DateTime.Now;
                    NpgsqlParameter parm2_2 = new NpgsqlParameter("@userid", NpgsqlDbType.Varchar, 10);
                    parm2_2.Value = _TableIn1.Rows[0]["userid"].ToString();
                    NpgsqlParameter parm2_3 = new NpgsqlParameter("@header_key", NpgsqlDbType.Varchar, 6);
                    parm2_3.Value = _TableIn1.Rows[0]["header_key"].ToString();

                    cmd2.Parameters.Add(parm2_1);
                    cmd2.Parameters.Add(parm2_2);
                    cmd2.Parameters.Add(parm2_3);

                    exeRows = cmd2.ExecuteNonQuery();  // execute rows
                    if (exeRows < 0)
                    {
                        _Ur.AddExceptionMsg("cmd2 更新失敗！");
                        doRollback = true;
                        //return _Ur.RetuenCode(_ClassID + 52);
                    }
                }

                // Update データ
                if (doRollback == false)
                {
                    NpgsqlCommand cmd3 = sqlConn.CreateCommand();
                    cmd3.CommandType = CommandType.Text;
                    cmd3.Transaction = transaction;          // 必要ないか
                    cmd3.Parameters.Clear();
                    cmd3.CommandText = @"update t_arrival_slip_detail_stockkey
                                            set
                                                delete_flag = '1'
                                                , update_datetime = @CURRENT_TIMESTAMP 
                                                , update_user = @userid 
                                                , update_program_id = 'NK0020'
                                            where
                                                arrival_slip_header_key = @header_key 
                                                and delete_flag = '0'

                                        ";

                    NpgsqlParameter parm3_1 = new NpgsqlParameter("@CURRENT_TIMESTAMP", NpgsqlDbType.Date);
                    parm3_1.Value = DateTime.Now;
                    NpgsqlParameter parm3_2 = new NpgsqlParameter("@userid", NpgsqlDbType.Varchar, 10);
                    parm3_2.Value = _TableIn1.Rows[0]["userid"].ToString();
                    NpgsqlParameter parm3_3 = new NpgsqlParameter("@header_key", NpgsqlDbType.Varchar, 6);
                    parm3_3.Value = _TableIn1.Rows[0]["header_key"].ToString();

                    cmd3.Parameters.Add(parm3_1);
                    cmd3.Parameters.Add(parm3_2);
                    cmd3.Parameters.Add(parm3_3);

                    exeRows = cmd3.ExecuteNonQuery();  // execute rows
                    if (exeRows < 0)
                    {
                        _Ur.AddExceptionMsg("cmd3 更新失敗！");
                        doRollback = true;
                        //return _Ur.RetuenCode(_ClassID + 52);
                    }
                }

                // Commit || Rollback
                if (doRollback == false)
                {
                    transaction.Commit();
                    return _Ur.RetuenCode(0);
                }
                else 
                {
                    transaction.Rollback();
                    return _Ur.RetuenCode(_ClassID + 52);
                }

            }
            catch (Exception ex)
            {
                if (transaction!= null) { transaction.Rollback(); }                

                _Ur.AddExceptionMsg("Exception Class: " + "NkYoteiDataUpdate - DataProcess");
                _Ur.AddExceptionMsg("Exception: " + ex.Message);
                if (ex.InnerException != null)
                {
                    _Ur.AddExceptionMsg("InnerException: ");
                    _Ur.AddExceptionMsg(String.Concat(ex.InnerException.StackTrace, ex.InnerException.Message));
                }
                return _Ur.RetuenCode(-(_ClassID + 53));
            }
            finally
            {
                if (transaction != null) { transaction.Dispose(); }
                DbMethod.CloseConnection(sqlConn);
            }

        }





        //入荷予定データを取得する。
        //入荷明細VIEWから入荷済数を取得する。
        //仕入先マスタから仕入先名称を取得する

        

        //入荷予定データを新規追加する。対象は入荷予定ヘッダテーブル。新規追加したレコードのtable_keyの値を実行元に返す。
        //入荷予定データを新規追加する。対象は入荷伝票明細テーブル。新規追加したレコードのtable_keyの値を実行元に返す。
        //入荷予定データを新規追加する。対象は入荷伝票明細_在庫キーテーブル。

        //入荷予定データを更新する。対象は入荷予定ヘッダテーブル。
        //入荷予定データを更新する。対象は入荷伝票明細テーブル。
        //入荷予定データを更新する。対象は入荷伝票明細_在庫キーテーブル。

        //採番種別マスタと採番管理テーブルから採番に必要な情報を取得する。
        //採番管理テーブルに当日日付の採番データを挿入する。
        //採番管理テーブルの当日日付の採番データを更新する。

    }
}
