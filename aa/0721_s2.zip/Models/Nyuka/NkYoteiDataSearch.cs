﻿using demo1.Common;
using Npgsql;
using NpgsqlTypes;
using System.Collections.Generic;
using System.Data;

namespace demo1.Models.Nyuka
{
    /// <summary>
    /// Author: Kamikawa
    /// Date: 2023-05
    /// LastEditTime: 
    /// Description:  入荷予定画面
    /// 
    /// 関連するモジュル
    /// NkYoteiInsertCheck -- 新規前に入荷伝票番号の存在確認
    /// NkYoteiDataSearch -- 入荷伝票番号より検索
    /// NkYoteiAutoSupplier -- 仕入先マスタから仕入先名称を取得する
    /// NkYoteiDataUpdate -- 入力データのDB更新
    /// NkYoteiSlipSearch -- 入荷伝票番号マスタ検索
    /// NkYoteiDataDelete -- 入荷伝票番号より削除（論理削除）
    /// </summary>
    public class NkYoteiDataSearch : PostCaseCls
    {

        public NkYoteiDataSearch()
        {
            this._ClassID = ClassCode.GetClassId(typeof(NkYoteiDataSearch));
        }

        //private string[] list_title = {
        //                                "table_key",
        //                                "発注_番号",
        //                                "仕入先_コード",
        //                                "入荷_予定_日付",
        //                                "商品_コード_1",
        //                                "入荷_予定_数量_バラ",
        //                                "作業_区分",
        //                                "引当_種別",
        //                                "受払_区分",
        //                                "管理_部門",
        //                                "荷姿_数量",
        //                                "入荷_単価",
        //                                "備考",
        //                                "在庫_キー_文字列_1",
        //                                "在庫_キー_文字列_2",
        //                                "在庫_キー_文字列_3",
        //                                "在庫_キー_文字列_4",
        //                                "在庫_キー_文字列_5",
        //                                "在庫_キー_文字列_6",
        //                                "在庫_キー_数値_1",
        //                                "在庫_キー_数値_2",
        //                                "在庫_キー_日付_1",
        //                                "在庫_キー_日付_2",
        //                                "商品_名称_1",
        //                                "入り数_パレット",
        //                                "入り数_梱",
        //                                "入り数_ケース",
        //                                "入り数_ボール",
        //                                "重量_バラ",
        //                                "パラメータ_設定値1",
        //                                "パラメータ_設定値2",
        //                                "パラメータ_設定値3",
        //                                "パラメータ_設定値4"
        //                            };


        // POST から実行する
        public void DoPostFunc()
        {

            #region ----------- Request Data の取得 -------------

            // Request Data は Json 形式です。

            //{
            //  datetime: "2023-02-28 10:38:56",
            //  loginid: "L001",
            //  devid: "D001",
            //  action: "A001",
            //  lang: "ja-jp",
            //  dl1max: "1",
            //  dl2max: "",
            //  dl3max: "",
            //  dl1: [
            //        { c: ["syscode", "cuscode", "logistics", "slipno", "programid"]}, 
            //        { c: ["sys01", "cus01", "log01", "slipno2", "yotei1"] }
            //       ],
            //  dl2: [],
            //  dl3: [],
            //}


            // Usage:
            // DataTable 形式のデータ取得
            // JsonParamのパラメータより最大３つListデータを取得可能です。
            // すでに自動でList-->DataTableを変換しました。

            // Set _DataSetIn.Tables["dt1"] --> _TableIn1
            // Set _DataSetIn.Tables["dt2"] --> _TableIn2
            // Set _DataSetIn.Tables["dt3"] --> _TableIn3
            GetTablesFromDataSet();

            // DataTable は以下のとおりで使える
            //_TableIn1.Rows[0]["name"].ToString() --> "田中"

            // Json Class 形式のデータ取得
            //string sLogin = this._JobjIn.loginid;
            //string sLang = this._JobjIn.lang;

            #endregion


            //クラスのプロセス実行
            ProcessFlow();


            #region ----------- Response JsonClassの作成 -------------



            //    public class JobjOut
            //{
            //    public string datetime = "";
            //    public string code = "";
            //    public string msg = "";
            //    public string msgd = "";        // debug + Exception Msg
            //    public string lang = "";
            //    public string dl1max = "";
            //    public string dl2max = "";
            //    public string dl3max = "";
            //    public string dl4max = "";
            //    public string dl5max = "";
            //    public Data_dl[]? dl1;
            //    public Data_dl[]? dl2;
            //    public Data_dl[]? dl3;
            //    public Data_dl[]? dl4;
            //    public Data_dl[]? dl5;
            //}

            //返信用データを _TableOut1 ～ _TableOut5 に設定する
            SetResponseJsonClass();


            #endregion

        }



        //流程处理
        public UtilityReturn ProcessFlow()
        {
            //step1 データチェック
            DataCheck();
            if (_Ur._ReInt != 0) { return _Ur; }

            //step2
            // .......

            //step3
            // .......

            //stepN データ处理
            DataProcess();
            if (_Ur._ReInt != 0) { return _Ur; }

            return _Ur;
        }

        private UtilityReturn DataCheck()
        {
            if (UtilityFunc.IsEmptyDataTable(_TableIn1))
            {
                _Ur.AddExceptionMsg("_TableIn1 パラメータ Empty.");
                return _Ur.RetuenCode(_ClassID + 31);
            }

            // Column 存在チエック
            DataColumnCollection columns = _TableIn1.Columns;
            if (columns.Contains("slipno") == false)
            {
                _Ur.AddExceptionMsg("_TableIn1 column slipno not exist.");
                return _Ur.RetuenCode(_ClassID + 32);
            }

            //必須項目チェック
            string ss = UtilityFunc.ObjToString(_TableIn1.Rows[0]["slipno"]);
            if (string.IsNullOrEmpty(ss))
            {
                _Ur.AddExceptionMsg("パラメータ slipno is Empty.");
                return _Ur.RetuenCode(_ClassID + 33);
            }

            return _Ur.RetuenCode(0);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public UtilityReturn DataProcess()
        {
            NpgsqlConnection sqlConn = DbMethod._DummyConn;
            NpgsqlTransaction? transaction = null;
            bool doRollback = false;
            int exeRows = -1;

            try
            {
                // DB Connection の取得
                //sqlConn = new(EnvConst.DB_CONSTR);
                //sqlConn.Open();
                UtilityReturn reUr = DbMethod.GetConnection(out sqlConn);
                if (reUr._ReInt != 0) 
                {
                    return _Ur.RetuenMerge(reUr);
                }

                // Transaction 作成
                transaction = sqlConn.BeginTransaction();


                // Rollbackチェック
                if (doRollback == false) 
                {
                    NpgsqlCommand cmd1 = sqlConn.CreateCommand();
                    cmd1.CommandType = CommandType.Text;
                    cmd1.Transaction= transaction;          // 必要ないか
                    cmd1.Parameters.Clear();

                    string tempSql = @"select
                                    CONCAT(v_ar.arrival_slip_header_key, '#', v_ar.arrival_slip_detail_key, '#', v_ar.arrival_slip_detail_stockkey_key) AS tb_key
                                    ,v_ar.arrival_slip_header_key
                                    ,v_ar.arrival_slip_detail_key
                                    ,v_ar.arrival_slip_detail_stockkey_key
                                    ,v_ar.order_no
                                    , v_ar.supplier_code
                                    , v_ar.arrival_plan_date
                                    , v_ar.item_code_1
                                    , v_ar.arrival_plan_quantity_piece
                                    , v_ar.allocate_kinds
                                    , v_ar.recipt_pay_division
                                    , v_ar.work_division
                                    , v_ar.management_department
                                    , v_ar.packing_quantity
                                    , v_ar.arrival_unit_price
                                    , v_ar.remarks
                                    , v_ar.t_asds_stock_key_character_1
                                    , v_ar.t_asds_stock_key_character_2
                                    , v_ar.t_asds_stock_key_character_3
                                    , v_ar.t_asds_stock_key_character_4
                                    , v_ar.t_asds_stock_key_character_5
                                    , v_ar.t_asds_stock_key_character_6
                                    , v_ar.t_asds_stock_key_date_1
                                    , v_ar.t_asds_stock_key_date_2
                                    , v_ar.t_asds_stock_key_number_1
                                    , v_ar.t_asds_stock_key_number_1 as t_asds_stock_key_number_2
                                    , m_i.item_name_1
                                    , m_i.quantity_per_pallet
                                    , m_i.quantity_per_pack
                                    , m_i.quantity_per_case
                                    , m_i.quantity_per_carton
                                    , m_i.weight_piece
                                    , m_p1.parameter_setting_1
                                    , m_p2.parameter_setting_1  as parameter_setting_2
                                    , m_p3.parameter_setting_1  as parameter_setting_3
                                    , m_p4.parameter_setting_1  as parameter_setting_4
                                from
                                    v_arrival_relation v_ar
                                    inner join m_item m_i
                                        on v_ar.system_code = m_i.system_code
                                        and v_ar.customer_code = m_i.customer_code
                                        and v_ar.item_code_1 = m_i.item_code_1
                                        and m_i.apply_start_date <= CURRENT_TIMESTAMP
                                        and m_i.apply_end_date >= CURRENT_TIMESTAMP
                                    inner join m_parameter m_p1
                                        on v_ar.system_code = m_p1.system_code
                                        and v_ar.customer_code = m_p1.customer_code
                                        and m_p1.parameter_kinds = '0001'
                                        and v_ar.management_department = m_p1.parameter_code
                                    inner join m_parameter m_p2
                                        on v_ar.system_code = m_p2.system_code
                                        and v_ar.customer_code = m_p2.customer_code
                                        and m_p2.parameter_kinds = '0002'
                                        and v_ar.recipt_pay_division = m_p2.parameter_code
                                    inner join m_parameter m_p3
                                        on v_ar.system_code = m_p3.system_code
                                        and v_ar.customer_code = m_p3.customer_code
                                        and m_p3.parameter_kinds = '0003'
                                        and v_ar.allocate_kinds = m_p3.parameter_code
                                    inner join m_parameter m_p4
                                        on v_ar.system_code = m_p4.system_code
                                        and v_ar.customer_code = m_p4.customer_code
                                        and m_p4.parameter_kinds = '0004'
                                        and v_ar.work_division = m_p4.parameter_code
                                where
                                    v_ar.system_code = @syscode
                                    and v_ar.customer_code = @cuscode
                                    and v_ar.logistics_base_code = @logcode
                                    and v_ar.arrival_slip_no = @slipno ";

                    string tempDate = DateTime.Now.ToString("yyyy-MM-dd");
                    tempDate = "DATE '" + tempDate + "'";
                    tempSql = tempSql.Replace("CURRENT_TIMESTAMP", tempDate);
                    cmd1.CommandText = tempSql;

                    NpgsqlParameter parm1_1 = new NpgsqlParameter("@syscode", NpgsqlDbType.Varchar, 12);
                    parm1_1.Value = _TableIn1.Rows[0]["syscode"].ToString();
                    NpgsqlParameter parm1_2 = new NpgsqlParameter("@cuscode", NpgsqlDbType.Varchar, 12);
                    parm1_2.Value = _TableIn1.Rows[0]["cuscode"].ToString();
                    NpgsqlParameter parm1_3 = new NpgsqlParameter("@logcode", NpgsqlDbType.Varchar, 12);
                    parm1_3.Value = _TableIn1.Rows[0]["logistics"].ToString();
                    NpgsqlParameter parm1_4 = new NpgsqlParameter("@slipno", NpgsqlDbType.Varchar, 25);
                    parm1_4.Value = _TableIn1.Rows[0]["slipno"].ToString();
                    cmd1.Parameters.Add(parm1_1);
                    cmd1.Parameters.Add(parm1_2);
                    cmd1.Parameters.Add(parm1_3);
                    cmd1.Parameters.Add(parm1_4);

                    DataTable tb01 = new DataTable();
                    NpgsqlDataAdapter sqladp1 = new(cmd1);
                    sqladp1.Fill(tb01);

                    //データ存在しない
                    if (UtilityFunc.IsEmptyDataTable(tb01))
                    {
                        _Ur.AddExceptionMsg("tb01 データが存在しない！");
                        doRollback = true;
                        //return _Ur.RetuenCode(_ClassID + 52);
                    }

                    // Unique チェック
                    //if (tb01.Rows.Count!= 1)
                    //{
                    //    _Ur.AddExceptionMsg("tb01 データはUnique ではない！");
                    //    doRollback = true;
                    //    //return _Ur.RetuenCode(_ClassID + 52);
                    //}

                    //戻り DataTable
                    _TableOut1 = tb01;

                    //// Column title 修正
                    //for (int i= 0; i< _TableOut1.Columns.Count;i++) 
                    //{
                    //    _TableOut1.Columns[i].ColumnName = list_title[i];
                    //}

                }



                // Rollbackチェック
                if (doRollback == false)
                {
                    NpgsqlCommand cmd2 = sqlConn.CreateCommand();
                    cmd2.CommandType = CommandType.Text;
                    cmd2.Transaction = transaction;          // 必要ないか
                    cmd2.Parameters.Clear();
                    cmd2.CommandText = @"SELECT
                                        CONCAT(system_code, '#', customer_code, '#', program_id) AS rkey
                                        , list_column_pg_name
                                        , list_column_display_name
                                        , data_type
                                        , digits                                        
                                        , display_kinds
                                        , display_order
                                        , sort_order
                                        , asc_desc    
                                    FROM
                                        m_list_display_setting 
                                    WHERE 
                                    system_code = @systemcode
                                    and customer_code = @customercode
                                    and program_id = @programid
                                    ORDER BY sql_order";

                    NpgsqlParameter parm2_1 = new NpgsqlParameter("@systemcode", NpgsqlDbType.Varchar, 50);
                    parm2_1.Value = _TableIn1.Rows[0]["syscode"].ToString();
                    NpgsqlParameter parm2_2 = new NpgsqlParameter("@customercode", NpgsqlDbType.Varchar, 50);
                    parm2_2.Value = _TableIn1.Rows[0]["cuscode"].ToString();
                    NpgsqlParameter parm2_3 = new NpgsqlParameter("@programid", NpgsqlDbType.Varchar, 50);
                    parm2_3.Value = _TableIn1.Rows[0]["programid"].ToString();
                    cmd2.Parameters.Add(parm2_1);
                    cmd2.Parameters.Add(parm2_2);
                    cmd2.Parameters.Add(parm2_3);

                    DataTable tb02 = new DataTable();
                    NpgsqlDataAdapter sqladp2 = new(cmd2);
                    sqladp2.Fill(tb02);

                    //データ存在しない
                    if (UtilityFunc.IsEmptyDataTable(tb02))
                    {
                        _Ur.AddExceptionMsg("tb02 データが存在しない！");
                        doRollback = true;
                        //return _Ur.RetuenCode(_ClassID + 52);
                    }

                    _TableOut2 = tb02;
                }


                // Commit || Rollback
                if (doRollback == false)
                {
                    transaction.Commit();
                    return _Ur.RetuenCode(0);
                }
                else 
                {
                    transaction.Rollback();
                    return _Ur.RetuenCode(_ClassID + 52);
                }

            }
            catch (Exception ex)
            {
                if (transaction!= null) { transaction.Rollback(); }                

                _Ur.AddExceptionMsg("Exception Class: " + "NkYoteiDataSearch - DataProcess");
                _Ur.AddExceptionMsg("Exception: " + ex.Message);
                if (ex.InnerException != null)
                {
                    _Ur.AddExceptionMsg("InnerException: ");
                    _Ur.AddExceptionMsg(String.Concat(ex.InnerException.StackTrace, ex.InnerException.Message));
                }
                return _Ur.RetuenCode(-(_ClassID + 53));
            }
            finally
            {
                if (transaction != null) { transaction.Dispose(); }
                DbMethod.CloseConnection(sqlConn);
            }

        }


        




    }
}
