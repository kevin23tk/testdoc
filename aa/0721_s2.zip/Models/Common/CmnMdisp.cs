﻿namespace demo1.Models.Common
{
    /// <summary>
    /// Author: Kamikawa
    /// Date: 2023-03
    /// LastEditTime: 
    /// Description: 
    /// 
    /// </summary>
    public class CmnMdisp
    {
        public string Page_Title = "";
        public Dictionary<string, string> Dic_Label01 = new Dictionary<string, string> { {"init", "init" } };
        public Dictionary<string, string> Dic_Label02 = new Dictionary<string, string> { { "init", "init" } };
        public Dictionary<string, string> Dic_Label03 = new Dictionary<string, string> { { "init", "init" } };


    }
}
