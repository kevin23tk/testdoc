﻿using demo1.Common;
using Npgsql;
using System.Data;

namespace demo1.Models.TestModels
{
    /// <summary>
    /// Author: Kamikawa
    /// Date: 2023-03
    /// LastEditTime: 
    /// Description: 
    /// 
    /// </summary>
    public class GetDbData : PostCaseCls
    {
        public GetDbData()
        {
            this._ClassID = ClassCode.GetClassId(typeof(GetDbData));
        }

        // POST から実行する
        public void DoPostFunc()
        {

            #region ----------- Request Data の取得 -------------

            // Request Data は Json 形式です。

            //{
            //  datetime: "2023-02-28 10:38:56",
            //  loginid: "L001",
            //  devid: "D001",
            //  action: "A001",
            //  lang: "ja-jp",
            //  dl1max: "1",
            //  dl2max: "",
            //  dl3max: "",
            //  dl1: [
            //        { c: ["name", "gender", "age"]}, 
            //        { c: ["田中", "男", "35"] }
            //       ],
            //  dl2: [],
            //  dl3: [],
            //}


            // Usage:
            // DataTable 形式のデータ取得
            // JsonParamのパラメータより最大３つListデータを取得可能です。
            // すでに自動でList-->DataTableを変換しました。

            // Set _DataSetIn.Tables["dt1"] --> _TableIn1
            // Set _DataSetIn.Tables["dt2"] --> _TableIn2
            // Set _DataSetIn.Tables["dt3"] --> _TableIn3
            GetTablesFromDataSet();

            // DataTable は以下のとおりで使える
            //_TableIn1.Rows[0]["name"].ToString() --> "田中"

            // Json Class 形式のデータ取得
            //string sLogin = this._JobjIn.loginid;
            //string sLang = this._JobjIn.lang;

            #endregion


            //クラスのプロセス実行
            ProcessFlow();


            #region ----------- Response JsonClassの作成 -------------


        //public class JobjOut
        //{
        //    public string datetime = "";
        //    public string code = "";
        //    public string msg = "";
        //    public string msgd = "";        // debug + Exception Msg
        //    public string lang = "";
        //    public string dl1max = "";
        //    public string dl2max = "";
        //    public string dl3max = "";
        //    public string dl4max = "";
        //    public string dl5max = "";
        //    public Data_dl[] dl1 = new Data_dl[0];
        //    public Data_dl[] dl2 = new Data_dl[0];
        //    public Data_dl[] dl3 = new Data_dl[0];
        //    public Data_dl[] dl4 = new Data_dl[0];
        //    public Data_dl[] dl5 = new Data_dl[0];
        //}

        //返信用データを _TableOut1 ～ _TableOut5 に設定する
        SetResponseJsonClass();


            #endregion

        }



        //流程处理
        public UtilityReturn ProcessFlow()
        {
            //step1 データチェック
            DataCheck();
            if (_Ur._ReInt != 0) { return _Ur; }

            //step2
            // .......

            //step3
            // .......

            //stepN データ处理
            DataProcess();
            if (_Ur._ReInt != 0) { return _Ur; }

            return _Ur;
        }

        private UtilityReturn DataCheck()
        {
            if (UtilityFunc.IsEmptyDataTable(_TableIn1))
            {
                _Ur.AddExceptionMsg("_TableIn1 パラメータ Empty.");
                return _Ur.RetuenCode(_ClassID + 31);
            }

            //必須項目チェック
            //if (string.IsNullOrEmpty(UtilityFunc.ObjToString(_TableIn1.Rows[0]["col"])))
            //{
            //    _Ur.AddExceptionMsg("パラメータ XXXXX is Empty.");
            //    return _Ur.RetuenCode(_ClassID + 32);
            //}

            return _Ur.RetuenCode(0);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public UtilityReturn DataProcess()
        {
            NpgsqlConnection sqlConn = new();

            try
            {
                sqlConn = new(EnvConst.DB_CONSTR);
                sqlConn.Open();

                NpgsqlCommand cmd = sqlConn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.Clear();
                cmd.CommandText = "SELECT col1, col2, col3 FROM testtb1 where col2 = 'a3'";  // SELECT col1, col2, col3 FROM testtb1 where col2 = 'a3'

                DataTable tb01 = new DataTable();
                NpgsqlDataAdapter sqladp1 = new(cmd);
                sqladp1.Fill(tb01);

                //数据不存在
                if (UtilityFunc.IsEmptyDataTable(tb01))
                {
                    _Ur.AddExceptionMsg("データが存在しない！");
                    return _Ur.RetuenCode(_ClassID + 51);
                }

                //返回用的 DataTable
                _TableOut1 = tb01;

                return _Ur.RetuenCode(0);

            }
            catch (Exception ex)
            {
                _Ur.AddExceptionMsg("Exception Class: " + "GetDbData - DataProcess");
                _Ur.AddExceptionMsg("Exception: " + ex.Message);
                if (ex.InnerException != null)
                {
                    _Ur.AddExceptionMsg("InnerException: ");
                    _Ur.AddExceptionMsg(String.Concat(ex.InnerException.StackTrace, ex.InnerException.Message));
                }
                return _Ur.RetuenCode(-(_ClassID + 52));
            }
            finally
            {
                if (sqlConn.State == ConnectionState.Open)
                {
                    sqlConn.Close(); //关闭数据库连接 
                }
            }

        }






    }



}
