﻿namespace demo1.Models.TestModels
{
    /// <summary>
    /// Author: Kamikawa
    /// Date: 2023-03
    /// LastEditTime: 
    /// Description: 
    /// 
    /// </summary>
    public class Test1Page1Model
    {
        public int MyArg1 { get; set; }



    }
}
