﻿using demo1.Common;
using Npgsql;
using System.Data;

namespace demo1.Models.TestModels
{
    /// <summary>
    /// Author: Kamikawa
    /// Date: 2023-03
    /// LastEditTime: 
    /// Description: 
    /// 
    /// </summary>
    public class GetddlData : PostCaseCls
    {
        public GetddlData()
        {
            this._ClassID = ClassCode.GetClassId(typeof(GetddlData));
        }

        public void DoGetFunc(string strType)
        {


            //クラスのプロセス実行
            ProcessFlow(strType);

            //    public class JobjOut
            //{
            //    public string datetime = "";
            //    public string code = "";
            //    public string msg = "";
            //    public string msgd = "";        // debug + Exception Msg
            //    public string lang = "";
            //    public string dl1max = "";
            //    public string dl2max = "";
            //    public string dl3max = "";
            //    public string dl4max = "";
            //    public string dl5max = "";
            //    public Data_dl[]? dl1;
            //    public Data_dl[]? dl2;
            //    public Data_dl[]? dl3;
            //    public Data_dl[]? dl4;
            //    public Data_dl[]? dl5;
            //}

            //返信用データを _TableOut1 ～ _TableOut5 に設定する
            SetResponseJsonClass();

        }

        //流程处理
        public UtilityReturn ProcessFlow(string strType)
        {
            //step1 データチェック
            //GetDDL(strType);
            //if (_Ur._ReInt != 0) { return _Ur; }

            GetDataFromDB();
            if (_Ur._ReInt != 0) { return _Ur; }

            //step2
            // .......

            //step3
            // .......

            //stepN データ处理
            //DataProcess();
            //if (_Ur._ReInt != 0) { return _Ur; }

            return _Ur;
        }

        public UtilityReturn GetDDL(string strType)
        {
            try
            {
                string[] tb_title = new string[] { "col" };
                DataTable dd = UtilityFunc.GenDtOnlyStruct(tb_title);
                DataRow dr;

                for (int i = 0; i < 10; i++)
                {
                    dr = dd.NewRow();
                    dr["col"] = strType + "_TICKET_002_123456" + i.ToString();
                    dd.Rows.Add(dr);
                }

                //返回用的 DataTable
                _TableOut1 = dd;
                return _Ur.RetuenCode(0);
            }
            catch (Exception ex)
            {
                _Ur.AddExceptionMsg("Exception Class: " + "Yotei01 - DataProcess");
                _Ur.AddExceptionMsg("Exception: " + ex.Message);
                if (ex.InnerException != null)
                {
                    _Ur.AddExceptionMsg("InnerException: ");
                    _Ur.AddExceptionMsg(String.Concat(ex.InnerException.StackTrace, ex.InnerException.Message));
                }
                return _Ur.RetuenCode(-(_ClassID + 52));
            }

            
        }



        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public UtilityReturn GetDataFromDB()
        {
            NpgsqlConnection sqlConn = new();

            try
            {
                sqlConn = new(EnvConst.DB_CONSTR);
                sqlConn.Open();

                NpgsqlCommand cmd = sqlConn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.Clear();
                cmd.CommandText = "SELECT delinumber FROM nk01_nykayti";  // SELECT col1, col2, col3 FROM testtb1 where col2 = 'a3'

                DataTable tb01 = new DataTable();
                NpgsqlDataAdapter sqladp1 = new(cmd);
                sqladp1.Fill(tb01);

                //数据不存在
                if (UtilityFunc.IsEmptyDataTable(tb01))
                {
                    _Ur.AddExceptionMsg("データが存在しない！");
                    return _Ur.RetuenCode(_ClassID + 51);
                }

                //返回用的 DataTable
                _TableOut1 = tb01;

                return _Ur.RetuenCode(0);

            }
            catch (Exception ex)
            {
                _Ur.AddExceptionMsg("Exception Class: " + "Yotei01 - DataProcess");
                _Ur.AddExceptionMsg("Exception: " + ex.Message);
                if (ex.InnerException != null)
                {
                    _Ur.AddExceptionMsg("InnerException: ");
                    _Ur.AddExceptionMsg(String.Concat(ex.InnerException.StackTrace, ex.InnerException.Message));
                }
                return _Ur.RetuenCode(-(_ClassID + 52));
            }
            finally
            {
                if (sqlConn.State == ConnectionState.Open)
                {
                    sqlConn.Close(); //关闭数据库连接 
                }
            }

        }

    }

}
