﻿using demo1.Common;
using Npgsql;
using NpgsqlTypes;
using System.Collections.Generic;
using System.Data;

namespace demo1.Models.TestModels
{
    /// <summary>
    /// Author: Kamikawa
    /// Date: 2023-07
    /// LastEditTime: 
    /// Description:  おかしいテスト
    /// 
    /// </summary>
    public class LockTestUpdate : PostCaseCls
    {

        public LockTestUpdate()
        {
            this._ClassID = ClassCode.GetClassId(typeof(LockTestUpdate));
        }

        // POST から実行する
        public void DoPostFunc()
        {

            #region ----------- Request Data の取得 -------------

            // Request Data は Json 形式です。

            //{
            //  datetime: "2023-02-28 10:38:56",
            //  loginid: "L001",
            //  devid: "D001",
            //  action: "A001",
            //  lang: "ja-jp",
            //  dl1max: "1",
            //  dl2max: "",
            //  dl3max: "",
            //  dl1: [
            //        { c: ["syscode", "cuscode", "logistics", "slipno", "programid"]}, 
            //        { c: ["sys01", "cus01", "log01", "slipno2", "yotei1"] }
            //       ],
            //  dl2: [],
            //  dl3: [],
            //}


            // Usage:
            // DataTable 形式のデータ取得
            // JsonParamのパラメータより最大３つListデータを取得可能です。
            // すでに自動でList-->DataTableを変換しました。

            // Set _DataSetIn.Tables["dt1"] --> _TableIn1
            // Set _DataSetIn.Tables["dt2"] --> _TableIn2
            // Set _DataSetIn.Tables["dt3"] --> _TableIn3
            GetTablesFromDataSet();

            // DataTable は以下のとおりで使える
            //_TableIn1.Rows[0]["name"].ToString() --> "田中"

            // Json Class 形式のデータ取得
            //string sLogin = this._JobjIn.loginid;
            //string sLang = this._JobjIn.lang;

            #endregion


            //クラスのプロセス実行
            ProcessFlow();


            #region ----------- Response JsonClassの作成 -------------



            //    public class JobjOut
            //{
            //    public string datetime = "";
            //    public string code = "";
            //    public string msg = "";
            //    public string msgd = "";        // debug + Exception Msg
            //    public string lang = "";
            //    public string dl1max = "";
            //    public string dl2max = "";
            //    public string dl3max = "";
            //    public string dl4max = "";
            //    public string dl5max = "";
            //    public Data_dl[]? dl1;
            //    public Data_dl[]? dl2;
            //    public Data_dl[]? dl3;
            //    public Data_dl[]? dl4;
            //    public Data_dl[]? dl5;
            //}

            //返信用データを _TableOut1 ～ _TableOut5 に設定する
            SetResponseJsonClass();


            #endregion

        }



        //流程处理
        public UtilityReturn ProcessFlow()
        {
            //step1 データチェック
            DataCheck();
            if (_Ur._ReInt != 0) { return _Ur; }

            //step2
            // .......

            //step3
            // .......

            //stepN データ处理
            DataProcess();
            if (_Ur._ReInt != 0) { return _Ur; }

            return _Ur;
        }

        private UtilityReturn DataCheck()
        {
            if (UtilityFunc.IsEmptyDataTable(_TableIn1))
            {
                _Ur.AddExceptionMsg("_TableIn1 パラメータ Empty.");
                return _Ur.RetuenCode(_ClassID + 31);
            }

            // Column 存在チエック
            //DataColumnCollection columns = _TableIn1.Columns;
            //if (columns.Contains("slipno") == false)
            //{
            //    _Ur.AddExceptionMsg("_TableIn1 column slipno not exist.");
            //    return _Ur.RetuenCode(_ClassID + 32);
            //}

            ////必須項目チェック
            //string ss = UtilityFunc.ObjToString(_TableIn1.Rows[0]["slipno"]);
            //if (string.IsNullOrEmpty(ss))
            //{
            //    _Ur.AddExceptionMsg("パラメータ slipno is Empty.");
            //    return _Ur.RetuenCode(_ClassID + 33);
            //}

            return _Ur.RetuenCode(0);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public UtilityReturn DataProcess()
        {
            NpgsqlConnection sqlConn = DbMethod._DummyConn;
            NpgsqlTransaction? transaction = null;
            bool doRollback = false;
            int exeRows = -1;

            try
            {
                // DB Connection の取得
                //sqlConn = new(EnvConst.DB_CONSTR);
                //sqlConn.Open();
                UtilityReturn reUr = DbMethod.GetConnection(out sqlConn);
                if (reUr._ReInt != 0) 
                {
                    return _Ur.RetuenMerge(reUr);
                }

                // Transaction 作成
                transaction = sqlConn.BeginTransaction();


                // Rollbackチェック
                if (doRollback == false) 
                {
                    NpgsqlCommand cmd1 = sqlConn.CreateCommand();
                    cmd1.CommandType = CommandType.Text;
                    cmd1.Transaction = transaction;         
                    cmd1.Parameters.Clear();

                    string tempSql = @"update test_list01
                                set extinfo1 = 'CURRENT_TIMESTAMP'
                                where
                                    tb_key = @tbkey ";

                    string tempDate = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                    tempSql = tempSql.Replace("CURRENT_TIMESTAMP", tempDate);
                    cmd1.CommandText = tempSql;

                    NpgsqlParameter parm1_1 = new NpgsqlParameter("@tbkey", NpgsqlDbType.Varchar, 12);
                    parm1_1.Value = _TableIn1.Rows[0]["tbkey"].ToString();

                    cmd1.Parameters.Add(parm1_1);

                    exeRows = cmd1.ExecuteNonQuery();  // execute rows

                    // Unique チェック
                    if (exeRows != 1)
                    {
                        _Ur.AddExceptionMsg("update test_list01 ,  update row <> 1");
                        doRollback = true;
                        //return _Ur.RetuenCode(_ClassID + 52);
                    }

                    tempDate = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                    _Ur.AddDebugMsg("cmd1-Update was executed at:" + tempDate);


                    //戻り DataTable
                    //_TableOut1 = tb01;

                }


                // Commit || Rollback
                if (doRollback == false)
                {
                    transaction.Commit();
                    return _Ur.RetuenCode(0);
                }
                else 
                {
                    transaction.Rollback();
                    return _Ur.RetuenCode(_ClassID + 52);
                }

            }
            catch (Exception ex)
            {
                if (transaction!= null) { transaction.Rollback(); }                

                _Ur.AddExceptionMsg("Exception Class: " + "NkYoteiDataSearch - DataProcess");
                _Ur.AddExceptionMsg("Exception: " + ex.Message);
                if (ex.InnerException != null)
                {
                    _Ur.AddExceptionMsg("InnerException: ");
                    _Ur.AddExceptionMsg(String.Concat(ex.InnerException.StackTrace, ex.InnerException.Message));
                }
                return _Ur.RetuenCode(-(_ClassID + 53));
            }
            finally
            {
                if (transaction != null) { transaction.Dispose(); }
                DbMethod.CloseConnection(sqlConn);
            }

        }


        




    }
}
