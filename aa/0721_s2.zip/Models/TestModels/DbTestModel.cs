﻿using demo1.Common;
using System.Data;

namespace demo1.Models.TestModels
{
    /// <summary>
    /// Author: Kamikawa
    /// Date: 2023-03
    /// LastEditTime: 
    /// Description: 
    /// 
    /// </summary>
    public class DbTestModel
    {
        public DataTable? Tb1 { get; set; }

        public void GetData()
        {
            //string strSql = "SELECT col1, col2, col3 FROM public.testtb1 where col1 = '111';";
            string strSql = "SELECT col1, col2, col3 FROM testtb1 where col2='a3';";
            DbMethod dm1 = new();
            DataSet ds = dm1.ExecuteQuery(strSql);
            if (ds != null)
            {
                Tb1 = ds.Tables[0];
            }
            else 
            {
                Tb1 = null;
            }
        }
            

    }
}
