/*
 * @Author: Kamikawa
 * @Date: 2023-04-17 10:00:16
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2023-04-17 10:14:28
 * @FilePath: \JS_TEST\JS_EXP\1.js
 * @Description: 
 * 
 * Copyright (c) 2023 by ${git_name_email}, All Rights Reserved. 
 */

function test1() {
    console.log("aa");
}

function test2(argParam) {
    console.log(argParam);
}

test1();
test2("bbbb");