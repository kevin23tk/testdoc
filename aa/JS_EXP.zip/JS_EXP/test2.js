/*
 * @Author: Kamikawa
 * @Date: 2023-02-21 09:31:48
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2023-02-22 09:28:45
 * @FilePath: \JS_TEST\test2.js
 * @Description:
 *
 * Copyright (c) 2023 by ${git_name_email}, All Rights Reserved.
 */


/**
 * @description: 
 * 1： 定义需要拼接进去的字符串变量，可以拼接双引号与单引号
 * 2： 将字符串变量用${}包起来，再写到需要拼接的地方
 * @return {*}
 */
function test_fanyinhao() {
  var str = `
  "测试双引号",
  '测试单引号'
  `;
  console.log(str);
  var a = "测试";
  console.log(`你好，${a}，很高兴见到你`);
}

/**
 * @description:  test Reflect
 * Reflect.apply(target, thisArgument, argumentsList)
 * @return {*}
 */
function test_ReflectApply() {
  const areaOfRectangle = function (width, height) {
    return `area is ${width * height} ${this.units}`;
  };
  const thisValue = {
    units: "Centimeters",
  };
  const argsList = [10, 20];
  const result = Reflect.apply(areaOfRectangle, thisValue, argsList);
  console.log(result);
}


function abc(data) {
  console.log(data);
}
function call_func_by_name() {
  let param = "This is called by func name.";
  //windows is not defined
  window["abc"](param);
  window["abc"].call(this,param);
}
//call_func_by_name();

test_fanyinhao();
test_ReflectApply();