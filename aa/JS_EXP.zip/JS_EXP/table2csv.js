/*
 * @Author: Kamikawa
 * @Date: 2023-04-10 09:46:48
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2023-04-10 11:11:03
 * @FilePath: \JS_TEST\JS_EXP\table2csv.js
 * @Description: 
 * 
 * Copyright (c) 2023 by ${git_name_email}, All Rights Reserved. 
 */
function exportTableToCSV(filename) {
    alert("kk");
    var csv = [];
    var rows = document.querySelectorAll("table tr");
  
    // 提取表头
    var headers = [];
    for (var i = 0; i < rows[0].cells.length; i++) {
      headers.push(rows[0].cells[i].textContent.trim());
    }
    csv.push(headers.join(","));
  
    // 提取表格数据
    for (var i = 1; i < rows.length; i++) {
      var row = [];
      for (var j = 0; j < rows[i].cells.length; j++) {
        row.push(rows[i].cells[j].textContent.trim());
      }
      csv.push(row.join(","));
    }
  
    // 创建并下载CSV文件
    var csvFile = new Blob([csv.join("\n")], { type: "text/csv" });
    var downloadLink = document.createElement("a");
    downloadLink.download = filename;
    downloadLink.href = window.URL.createObjectURL(csvFile);
    downloadLink.style.display = "none";
    document.body.appendChild(downloadLink);
    downloadLink.click();
  }
//   您需要将此代码放置在包含要提取的表格的HTML页面中，并将filename参数替换为您要保存的CSV文件的名称。此代码将在单击按钮时调用exportTableToCSV函数，该函数将提取表格中的数据并将其保存为CSV文件。
//   请注意，此代码仅适用于在同一域中加载的HTML页面。如果HTML页面在不同的域中加载，则会出现安全性问题，并且需要特殊处理才能实现。

  
  
  
  