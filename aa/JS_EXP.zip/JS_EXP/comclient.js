/*
 * @Author: Kamikawa
 * @Date: 2023-03-16 16:27:54
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 
 * @FilePath: \wwwroot\js\comclient.js
 * @Description: 
 * 
 * Copyright (c) 2023 by ${git_name_email}, All Rights Reserved. 
 */

/**
 * @description: 
 * CurrentTime 形式：yyyy-MM-dd HH:MM:SS
 * @return {*}
 */
function getCurrentTime() {
    let date = new Date();//CurrentTime
    let month = zeroFill(date.getMonth() + 1);//月
    let day = zeroFill(date.getDate());//日
    let hour = zeroFill(date.getHours());//時
    let minute = zeroFill(date.getMinutes());//分
    let second = zeroFill(date.getSeconds());//秒
    
    //CurrentTime
    let curTime = date.getFullYear() + "-" + month + "-" + day
        + " " + hour + ":" + minute + ":" + second;

    return curTime;
}

/**
 * @description: 
 * 0～9 --> 00～09
 * @param {*} i
 * @return {*}
 */
function zeroFill(i) {
    if (i >= 0 && i <= 9) {
        return "0" + i;
    } else {
        return i;
    }
}

/**
 * Json 定義
 * { 
 *   "datetime": "2023-02-20 11:28:01", 
 *   "loginid": "L001", 
 *   "devid": "D001", 
 *   "tkid": "T001", 
 *   "snid": "S001", 
 *   "model": "A001", 
 *   "lang": "ja-jp", 
 *   "option": "showheaders|showrequest",
 *   "dl1max": "1",
 *   "dl2max": "",
 *   "dl3max": "",
 *   "dl1": [ 
 *      { "c": [ "name","gender","age"] }, 
 *      { "c": [ "EEEE", "mmmm", "35"] } 
 *          ],
 *   "dl2": [],
 *   "dl3": []
 * } 
 */
class jdatain {
    constructor(datetime, loginid, devid, tkid, snid, module, lang, option) {
        this.datetime = datetime;
        this.loginid = loginid;
        this.devid = devid;
        this.tkid = tkid;
        this.snid = snid;
        this.module = module;
        this.lang = lang;
        this.option = option;
        this.dl1max = "";
        this.dl2max = "";
        this.dl3max = "";
        this.dl1 = [];
        this.dl2 = [];
        this.dl3 = [];
    }
    setdataList(id, value) {
        if (id === 1) { this.dl1 = value; }
        if (id === 2) { this.dl2 = value; }
        if (id === 3) { this.dl3 = value; }        
    }
    getdataList(id) {
        if (id === 1) { return this.dl1; }
        if (id === 2) { return this.dl2; }
        if (id === 3) { return this.dl3; }
    }

    setlistMax(id, value) {
        if (id === 1) { this.dl1max = value; }
        if (id === 2) { this.dl2max = value; }
        if (id === 3) { this.dl3max = value; }
    }
    getlistMax(id) {
        if (id === 1) { return this.dl1max; }
        if (id === 2) { return this.dl2max; }
        if (id === 3) { return this.dl3max; }
    }
}

/**
 * Json 定義 dl 部分
 * *  "dl": [ 
 *      { "c": [ "name","gender","age"] }, 
 *      { "c": [ "EEEE", "mmmm", "35"] } 
 *  ] 
 * } 
 */
class jdatainrow {
    constructor() {
        this.c = [];
    }
    set dataRow(value) {
        this.c = value;
    }
    get dataRow() {
        return this.c;
    }
}

/**
 * @description: 
 * Map data convert to jdatainrow
 * Set dl1 -- only one row data for pass condition or property
 * dl1max = '1'
 * @param {*} argMap
 * @return {*}
 */
function GetJsonReqCls(argMap, sLoginid, sDevid, sTkid, sSnid, sModule, sLang, sOption) {

    // let keys = keys = [...sdata.keys()];
    // let vals = [...sdata.values()];
    let keys = Array.from(argMap.keys());
    let vals = Array.from(argMap.values());

    if (sLang === '') { sLang = 'ja-jp'; }
    // datetime, loginid, devid, model, lang, option
    let jin = new jdatain(getCurrentTime(), sLoginid, sDevid, sTkid, sSnid, sModule, sLang, sOption);

    let mylist = [];
    mylist[0] = new jdatainrow();
    mylist[1] = new jdatainrow();
    //console.log(keys.length);
    for (let i = 0; i < keys.length; i++) {
        mylist[0].c[i] = keys[i];
        mylist[1].c[i] = vals[i];
    }
    jin.setdataList(1, mylist);
    jin.setlistMax(1, "1");
    return jin;
}

/**
 * @description: Get Post URL by Post_Type_Info Array
 * @param {*} fName
 * @return {*}
 */
function GetPtiUrl(fName) {

    // Get Post URL by Post_Type_Info Array
    for (let i = 0; i < Post_Type_Info.length; i++) {
        if (fName === Post_Type_Info[i][0])
        {
            return Post_Type_Info[i][1];
        }
    }
    return "";
}

/**
 * @description: Get Post Module by Post_Type_Info Array
 * @param {*} fName
 * @return {*}
 */
function GetPtiModule(fName) {

    // Get Post URL by Post_Type_Info Array
    for (let i = 0; i < Post_Type_Info.length; i++) {
        if (fName === Post_Type_Info[i][0])
        {
            return Post_Type_Info[i][2];
        }
    }
    return "";
}

/**
 * @description: 
 * Get after process function name by Post_Type_Info Array
 * Call after process function with parameters
 * @param {*} fName
 * @param {*} rData
 * @return {*}
 */
function GetPostResponse(fName, rData) {

    try {

        // Get after process function name by Post_Type_Info Array
        for (let i = 0; i < Post_Type_Info.length; i++) {
            if (fName === Post_Type_Info[i][0]) {
                let dofunctionname = Post_Type_Info[i][3];
                //window["P001After"](rData)   -- Call function by name
                window[dofunctionname](rData);
            }
        }

    } catch (error) {
        console.log(error.message);
        // Expected output: ReferenceError: nonExistentFunction is not defined
        // (Note: the exact output may be browser-dependent)
    }
}

/**
 * @description: 
 * 1. Map to JsonClass
 * 2. Get post URL
 * 3. Call POST
 * @param {*} fName
 * @param {*} sData
 * @return {*}
 */
function SendPostReq(fName, sData, sLoginid, sDevid, sTkid, sSnid, sLang, sOption) {

    let sModule = GetPtiModule(fName);

    //Map to JsonClass
    let jobj = GetJsonReqCls(sData, sLoginid, sDevid, sTkid, sSnid, sModule, sLang, sOption);
    //console.log(JSON.stringify(jobj, null, 4));
    //Get Url
    let sUrl = GetPtiUrl(fName);

    alert(JSON.stringify(jobj));
    //Call axios post
    AxiosPost(fName, sUrl, jobj);
}

/**
 * @description: Call POST
 * @param {*} fName
 * @param {*} sUrl
 * @param {*} jClsData
 * @return {*}
 */
function AxiosPost(fName, sUrl, jClsData) {
    
    axios({
        method: 'post',
        url: sUrl,  //'./GetPostTest/TestPost2',
        data: JSON.stringify(jClsData),
        //timeout: 0
    })
        .then(function (response) {
            //console.log(response);
            
            //let jsonStr = JSON.stringify(response.data);
            //console.log(JSON.stringify(response.data, null, 4));
            //jsonStr = jsonStr.replace(/\\"/g, '"');
            //GetPostResponse(fName, jsonStr);

            GetPostResponse(fName, response.data);
        })
        .catch(function (error) {
            if (error.response) {
                // The request was made and the server responded with a status code
                // that falls out of the range of 2xx
                console.log(error.response.data);
                console.log(error.response.status);
                console.log(error.response.statusText);
                //console.log(error.response.headers);
                console.log(JSON.stringify(error.response.headers, null, 4));
            } else if (error.request) {
                // The request was made but no response was received
                // `error.request` is an instance of XMLHttpRequest in the browser and an instance of
                // http.ClientRequest in node.js
                console.log(error.request);
            } else {
                // Something happened in setting up the request that triggered an Error
                console.log('Error', error.message);
            }
            //console.log(error.config);
        })
        .finally(function () {
            // always executed
        });
}



// const Post_Type_Info = [
//     ["P001", "./GetPostTest/TestPost2", "P001After"],
//     ["P002", "./GetPostTest/TestPost2", "P002After"],
//     ["P003", "./GetPostTest/TestPost2", "P003After"],
// ];

// function P001Before() {
//     let typeName = "P001";
//     // sdata.set( パラメータ名(任意) , パラメータ 値);
//     let sdata = new Map();
//     sdata.set('name', 'EEEE');
//     sdata.set('gender', 'mmmm');
//     sdata.set('age', '35');

//     //共通 Send POST Function
//     SendPostReq(typeName, sdata);
// }

// function P001After(rData) {
//     let output = document.getElementById('msg');
//     output.innerHTML = rData;
// }







/**
 * @description: Get Get URL by Post_Type_Info Array
 * @param {*} fName
 * @return {*}
 */
function GetGtiUrl(fName) {

    // Get Post URL by Get_Type_Info Array
    for (let i = 0; i < Get_Type_Info.length; i++) {
        if (fName === Get_Type_Info[i][0]) {
            return Get_Type_Info[i][1];
        }
    }
    return "";
}

/**
 * @description: 
 * Get after process function name by Get_Type_Info Array
 * Call after process function with parameters
 * @param {*} fName
 * @param {*} rData
 * @return {*}
 */
function GetGetResponse(fName, rData) {

    try {

        // Get after process function name by Get_Type_Info Array
        for (let i = 0; i < Get_Type_Info.length; i++) {
            if (fName === Get_Type_Info[i][0]) {
                let dofunctionname = Get_Type_Info[i][2];
                //window["G001After"](rData)   -- Call function by name
                window[dofunctionname](rData);
            }
        }

    } catch (error) {
        console.log(error.message);
        // Expected output: ReferenceError: nonExistentFunction is not defined
        // (Note: the exact output may be browser-dependent)
    }
}

function SendGetReq(fName, argObj) {

    let sUrl = GetGtiUrl(fName);
    //Call axios post
    AxiosGet(fName, sUrl, argObj);
}


//axios({
//    method: 'get',
//    url: './GetPostTest/TestGet',
//    params: {
//        name: 'NNNN',
//        gender: 'GGGG',
//        age: '7777',
//    },
//})

/**
 * @description: Call Get
 * @param {*} fName
 * @param {*} sUrl
 * @param {*} ObjParam * 
 * @return {*}
 */
function AxiosGet(fName, sUrl, ObjParam) {

    axios({
        method: 'get',
        url: sUrl,  //'./WkpGetPost/DoGet',
        params: ObjParam,
        //timeout: 0
    })
        .then(function (response) {
            //console.log(response);

            //let jsonStr = JSON.stringify(response.data);
            //console.log(JSON.stringify(response.data, null, 4));
            //jsonStr = jsonStr.replace(/\\"/g, '"');
            //GetPostResponse(fName, jsonStr);

            GetGetResponse(fName, response.data);
        })
        .catch(function (error) {
            if (error.response) {
                // The request was made and the server responded with a status code
                // that falls out of the range of 2xx
                console.log(error.response.data);
                console.log(error.response.status);
                console.log(error.response.statusText);
                //console.log(error.response.headers);
                console.log(JSON.stringify(error.response.headers, null, 4));
            } else if (error.request) {
                // The request was made but no response was received
                // `error.request` is an instance of XMLHttpRequest in the browser and an instance of
                // http.ClientRequest in node.js
                console.log(error.request);
            } else {
                // Something happened in setting up the request that triggered an Error
                console.log('Error', error.message);
            }
            //console.log(error.config);
        })
        .finally(function () {
            // always executed
        });
}





//public class JobjOut {
//    public string datetime = "";
//    public string code = "";
//    public string msg = "";
//    public string msgd = "";        // debug + Exception Msg
//    public string lang = "";
//    public string dl1max = "";
//    public string dl2max = "";
//    public string dl3max = "";
//    public string dl4max = "";
//    public string dl5max = "";
//    public Data_dl[] dl1 = new Data_dl[0];
//    public Data_dl[] dl2 = new Data_dl[0];
//    public Data_dl[] dl3 = new Data_dl[0];
//    public Data_dl[] dl4 = new Data_dl[0];
//    public Data_dl[] dl5 = new Data_dl[0];
//}
//public class Data_dl {
//    public string[] c;
//}

/**
 * @description: Get Response Data
 * @param {*} response.data.dl1......dl5
 * @return {*}
 */
function GetRespArrData(responsedata) {

    //responsedata = response.data.dln  n=1-5
    //let r = responsedata.length;
    //let c = responsedata[0].c.length;

    let arrC = new Array();
    for (let i = 0; i < responsedata.length; i++) {

        arrC[i] = new Array();

        for (let j = 0; j < responsedata[i].c.length; j++) {
            arrC[i][j] = responsedata[i].c[j];
        }
    }
    return arrC;
}


