function testOd() {
    //alert("ok1");
    let od = new Object();
    od.name = "aaa";
    od.age = "30";
    od.weight = "90";
    //console.log(JSON.stringify(od,null,4));
    document.getElementById('rejson').value = JSON.stringify(od, null, 4);
    let output = document.getElementById('msg');
    output.innerHTML = JSON.stringify(od, null, 4);;
};

