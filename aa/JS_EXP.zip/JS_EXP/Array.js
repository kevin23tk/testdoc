/*
 * @Author: Kamikawa
 * @Date: 2023-03-16 10:45:07
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2023-04-12 17:11:18
 * @FilePath: \JS_TEST\JS_EXP\Array.js
 * @Description: 
 * 
 * Copyright (c) 2023 by ${git_name_email}, All Rights Reserved. 
 */

//https://www.tohoho-web.com/js/array.htm

//数组定义
// array = [e1, e2, ...]
// 数组index = 0,1,2,3......
// var arr1 = new Array();     // 要素が0個の配列を作成
// var arr2 = new Array(3);    // 要素が3個の空配列を作成
// var arr3 = new Array("Red", "Green", "Blue");  
// var arr3 = ["Red", "Green", "Blue"];

//二维数组定义
// var arr10 = [[1, 2], [2, 4], [4, 8]];
function Set_Two_dimensional_array() {

    let arr11 = new Array();
    for(let i=0;i<3;i++)
    {
        arr11[i] = new Array();
        for(let j=0;j<2;j++)
        {
            arr11[i][j] = i.toString() + j.toString();
        }
    }
    console.log(arr11);
    return arr11;
}

//二维数组定义 使用[]
function Set_Two_dimensional_array2() {

    let arr12 = [];
    for (i = 0; i < 3; i++) {
        arr12[i] = [];
        for (j = 0; j < 4; j++) {
            arr12[i][j] = i * 100 + j;
        }
    }
    console.log(arr12[2][3]);   
    return arr12;
}

//二维数组遍历
function Print_Two_dimensional_array(array2) {
    
    // 不对称二维数组设置
    // array2=new Array(
    //     ['北京市','天津市','上海市','重庆市'],
    //     ['河北省','山西省','辽宁省','吉林省','黑龙江省','江苏省','浙江省','安徽省','福建省','江西省','山东省','河南省','湖北省','湖南省','广东省','海南省','四川省','贵州省','云南省','陕西省','甘肃省','青海省','中国台湾省'],
    //     ['内蒙古自治区','广西壮族自治区','西藏自治区','宁夏回族自治区','新疆维吾尔自治区'],
    //     ['中国香港特别行政区','中国澳门特别行政区']
    //     );
    //二维数组遍历
    for(let i=0;i<array2.length;i++){
        for(var j=0;j<array2[i].length;j++){
            console.log(array2[i][j]);
            // document.write(array2[i][j]);
        }
        // document.write('<br>');
    }
}

//判断是否 二维数组
function determine_array2(array) {
    if(determine_array1(array))
    {
        return Array.isArray(array[0]);
    }
}
//判断是否 一维数组
function determine_array1(array) {
    return Array.isArray(array);
}
//判断是否 数组
function determine_array(array) {
    if(determine_array2(array))
    {
        console.log("二维数组");
        return;
    }
    if(determine_array1(array))
    {
        console.log("一维数组");
    }else
    {
        console.log("不是数组");
    }
}

function sortMultiDimensionalArray(arr, sortColumns, sortDirections) {
    arr.sort(function(a, b) {
      for (var i = 0; i < sortColumns.length; i++) {
        var col = sortColumns[i];
        var direction = sortDirections[i] || 'asc';
        if (col === 'name') {
          // 使用 localeCompare() 方法比较字符串
          var result = a[col].localeCompare(b[col]);
          if (result !== 0) {
            return direction === 'asc' ? result : -result;
          }
        } else {
          if (a[col] > b[col]) {
            return direction === 'asc' ? 1 : -1;
          } else if (a[col] < b[col]) {
            return direction === 'asc' ? -1 : 1;
          }
        }
      }
      return 0;
    });
    return arr;
}

function test_sortMultiDimensionalArray() {

    var arr = [
        { name: 'John', age: 30, score: 90 },
        { name: 'Jane', age: 25, score: 80 },
        { name: 'Bob', age: 35, score: 85 },
        { name: 'Alice', age: 30, score: 95 }
      ];
      
      var sortedArr = sortMultiDimensionalArray(arr, ['name', 'age', 'score'], ['asc', 'asc', 'desc']);
      console.log(sortedArr);
      
}
  

function Gen_M_array() {
    let arrm2 = [];
    arrm2[0] = ['aa','2023-03-21','2','56.32','004','dgdfg-235g3','ヂュエル'];
    arrm2[1] = ['aab','2023-03-02','10','245.6','008','sggh','注文番号'];
    arrm2[2] = ['Afe','2023-03-12','20','3.67','003','sggh','実際'];
    arrm2[3] = ['eea','2023-03-30','6','432.86','020','zxdfg-56ghjr','見積書'];
    return arrm2;
}

function Show_M_array() {

    // data.sort((a, b) => {
    //     if (a[0] < b[0]) return -1;  // 按照第一列升序排序
    //     if (a[0] > b[0]) return 1;
    //     if (a[1] > b[1]) return -1;  // 按照第二列降序排序
    //     if (a[1] < b[1]) return 1;s
    //     if (a[2] < b[2]) return -1;  // 按照第三列升序排序
    //     if (a[2] > b[2]) return 1;
    //     return 0;  // 如果所有列都相等，则保持原有顺序不变
    //   });

    const arr = [3, 1, 4, 1, 5, 9, 2, 6, 5, 3, 5];
    // 对数组进行排序（默认升序）
    arr.sort();
    console.log(arr); // [1, 1, 2, 3, 3, 4, 5, 5, 5, 6, 9]

    // 对数组进行排序（降序）
    arr.sort((a, b) => b - a);
    console.log(arr); // [9, 6, 5, 5, 5, 4, 3, 3, 2, 1, 1]

    const gojuon = [
  'あ', 'い', 'う', 'え', 'お',
  'か', 'き', 'く', 'け', 'こ',
  'さ', 'し', 'す', 'せ', 'そ',
  'た', 'ち', 'つ', 'て', 'と',
  'な', 'に', 'ぬ', 'ね', 'の',
  'は', 'ひ', 'ふ', 'へ', 'ほ',
  'ま', 'み', 'む', 'め', 'も',
  'や', 'ゆ', 'よ',
  'ら', 'り', 'る', 'れ', 'ろ',
  'わ', 'を', 'ん',
  'が', 'ぎ', 'ぐ', 'げ', 'ご',
  'ざ', 'じ', 'ず', 'ぜ', 'ぞ',
  'だ', 'ぢ', 'づ', 'で', 'ど',
  'ば', 'び', 'ぶ', 'べ', 'ぼ',
  'ぱ', 'ぴ', 'ぷ', 'ぺ', 'ぽ',
  'ア', 'イ', 'ウ', 'エ', 'オ',
  'カ', 'キ', 'ク', 'ケ', 'コ',
  'サ', 'シ', 'ス', 'セ', 'ソ',
  'タ', 'チ', 'ツ', 'テ', 'ト',
  'ナ', 'ニ', 'ヌ', 'ネ', 'ノ',
  'ハ', 'ヒ', 'フ', 'ヘ', 'ホ',
  'マ', 'ミ', 'ム', 'メ', 'モ',
  'ヤ', 'ユ', 'ヨ',
  'ラ', 'リ', 'ル', 'レ', 'ロ',
  'ワ', 'ヲ', 'ン',
  'ガ', 'ギ', 'グ', 'ゲ', 'ゴ',
  'ザ', 'ジ', 'ズ', 'ゼ', 'ゾ',
  'ダ', 'ヂ', 'ヅ', 'デ', 'ド',
  'バ', 'ビ', 'ブ', 'ベ', 'ボ',
  'パ', 'ピ', 'プ', 'ペ', 'ポ'
    ];
    gojuon.sort(function(a, b) {
        return a.localeCompare(b, 'ja') // 'zh' 表示中文，可以根据需要替换成其他语言编码
    });
    //console.log(gojuon); 

    const data = [  ['John', 'Doe', 30],
    ['Jane', 'Doe', 25],
    ['John', 'Smith', 40],
    ['Jane', 'Smith', 35],
    ];

    // 将二维数组转换为JSON字符串
    const dataJson = JSON.stringify(data);
    console.log(dataJson); 

    // // 将JSON字符串保存到sessionStorage中
    // sessionStorage.setItem('data', dataJson);
    // // 从sessionStorage中检索JSON字符串
    // const dataJson = sessionStorage.getItem('data');
    // // 将JSON字符串转换为二维数组
    // const data = JSON.parse(dataJson);

    let arrm2 = Gen_M_array();
    // 按照子数组的第一个元素进行升序排序
    let sortedArr = [...arrm2].sort((a, b) => b[2] - a[2]);
    console.log(sortedArr);

    sortedArr = [...arrm2].sort((a, b) => b[3] - a[3]);
    console.log(sortedArr);

    sortedArr = [...arrm2].sort(function(a, b) {
        return a[1].localeCompare(b[1], 'ja') // 'zh' 表示中文，可以根据需要替换成其他语言编码
    });
    console.log(sortedArr);

    sortedArr = [...arrm2].sort(function(a, b) {
        return a[4].localeCompare(b[4], 'ja') // 'zh' 表示中文，可以根据需要替换成其他语言编码
    });
    console.log(sortedArr);

    sortedArr = [...arrm2].sort(function(a, b) {
        return b[5].localeCompare(a[5], 'ja') // 'zh' 表示中文，可以根据需要替换成其他语言编码
    });
    console.log(sortedArr);

    sortedArr = [...arrm2].sort(function(a, b) {
        return b[6].localeCompare(a[6], 'ja') // 'zh' 表示中文，可以根据需要替换成其他语言编码
    });
    console.log(sortedArr);
}

Show_M_array();
test_sortMultiDimensionalArray();

// Print_Two_dimensional_array(Set_Two_dimensional_array());
// determine_array(Set_Two_dimensional_array2());
// determine_array(["Red", "Green", "Blue"]);
// determine_array("12345");

