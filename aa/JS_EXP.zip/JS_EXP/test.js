/*
 * @Author: Kamikawa
 * @Date: 2023-02-16 16:27:54
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2023-03-14 10:35:54
 * @FilePath: \JS_TEST\test.js
 * @Description: 
 * 
 * Copyright (c) 2023 by ${git_name_email}, All Rights Reserved. 
 */


/**
 * @description: 
 * CurrentTime 形式：yyyy-MM-dd HH:MM:SS
 * @return {*}
 */
function getCurrentTime() {
    let date = new Date();//CurrentTime
    let month = zeroFill(date.getMonth() + 1);//月
    let day = zeroFill(date.getDate());//日
    let hour = zeroFill(date.getHours());//時
    let minute = zeroFill(date.getMinutes());//分
    let second = zeroFill(date.getSeconds());//秒

    //CurrentTime
    let curTime = date.getFullYear() + "-" + month + "-" + day
        + " " + hour + ":" + minute + ":" + second;

    return curTime;
}

/**
 * @description: 
 * 0～9 --> 00～09
 * @param {*} i
 * @return {*}
 */
function zeroFill(i) {
    if (i >= 0 && i <= 9) {
        return "0" + i;
    } else {
        return i;
    }
}

/**
 * Json 定義
 * { 
 *   "datetime": "2023-02-20 11:28:01", 
 *  "loginid": "L001", 
 *  "devid": "D001", 
 *  "action": "A001", 
 *  "dl": [ 
 *      { "c": [ "name","gender","age"] }, 
 *      { "c": [ "EEEE", "mmmm", "35"] } 
 *  ] 
 * } 
 */
class jdatain {
    constructor(datetime, loginid, devid, action) {
        this.datetime = datetime;
        this.loginid = loginid;
        this.devid = devid;
        this.action = action;
        this.dl = [];
    }
    set dataList(value) {
        this.dl = value;
    }
    get dataList() {
        return this.dl;
    }
}

/**
 * Json 定義 dl 部分
 * *  "dl": [ 
 *      { "c": [ "name","gender","age"] }, 
 *      { "c": [ "EEEE", "mmmm", "35"] } 
 *  ] 
 * } 
 */
class jdatainrow {
    constructor() {
        this.c = [];
    }
    set dataRow(value) {
        this.c = value;
    }
    get dataRow() {
        return this.c;
    }
}

/**
 * @description: Map data convert to jdatainrow
 * @param {*} argMap
 * @return {*}
 */
function GetJsonReqCls(argMap) {

    // let keys = keys = [...sdata.keys()];
    // let vals = [...sdata.values()];
    let keys = Array.from(argMap.keys());
    let vals = Array.from(argMap.values());
    let jin = new jdatain(getCurrentTime(), 'L001', 'D001', 'A001');

    let mylist = [];
    mylist[0] = new jdatainrow();
    mylist[1] = new jdatainrow();
    console.log(keys.length);
    for (let i = 0; i < keys.length; i++) {
        mylist[0].c[i] = keys[i];
        mylist[1].c[i] = vals[i];
    }
    jin.dataList = mylist;
    return jin;
}


function testclass2json() {

    var jin = new jdatain(getCurrentTime(), 'L001', 'D001', 'A001');
    var mylist = [];
    for (let i = 0; i < 4; i++) {
        mylist[i] = new jdatainrow();
        for (let j = 0; j < 6; j++) {
            mylist[i].c[j] = "data" + i.toString() + j.toString();
        }
    }
    jin.dataList = mylist;

    //JSON.stringify(jin);
    console.log(JSON.stringify(jin,null,4));
}

function testMap() {
    var sdata = new Map();
    sdata.set('name','EEEE');
    sdata.set('gender','mmmm');
    sdata.set('age','35');

    //console.log(JSON.stringify(sdata,null,4));

    var jobj = GetJsonReqCls(sdata);
    console.log(JSON.stringify(jobj,null,4));
}


function testOd() {
    let od = new Object();
    od.name = "aaa";
    od.age = "30";
    od.weight = "90";
    
    console.log(JSON.stringify(od,null,4));
}


//testclass2json();
//testMap();
testOd();