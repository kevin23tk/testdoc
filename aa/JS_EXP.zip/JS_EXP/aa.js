

//二维数组定义 使用[]
function Set_Two_dimensional_array2() {

    let arr12 = [];
    for (i = 0; i < 3; i++) {
        arr12[i] = [];
        for (j = 0; j < 4; j++) {
            arr12[i][j] = i * 100 + j;
        }
    }
    console.log(arr12[2][3]);   
    return arr12;
}


//二维数组遍历
function Print_Two_dimensional_array(array2) {
    
    // 不对称二维数组设置
    // array2=new Array(
    //     ['北京市','天津市','上海市','重庆市'],
    //     ['河北省','山西省','辽宁省','吉林省','黑龙江省','江苏省','浙江省','安徽省','福建省','江西省','山东省','河南省','湖北省','湖南省','广东省','海南省','四川省','贵州省','云南省','陕西省','甘肃省','青海省','中国台湾省'],
    //     ['内蒙古自治区','广西壮族自治区','西藏自治区','宁夏回族自治区','新疆维吾尔自治区'],
    //     ['中国香港特别行政区','中国澳门特别行政区']
    //     );
    //二维数组遍历
    for(let i=0;i<array2.length;i++){
        for(var j=0;j<array2[i].length;j++){
            console.log(array2[i][j]);
            // document.write(array2[i][j]);
        }
        // document.write('<br>');
    }
}

//Print_Two_dimensional_array();
Print_Two_dimensional_array(Set_Two_dimensional_array2());