/*
 * @Author: Kamikawa
 * @Date: 2023-04-14 20:42:47
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2023-04-17 11:25:20
 * @FilePath: \JS_TEST\JS_EXP\setpage.js
 * @Description: 
 * 
 * Copyright (c) 2023 by ${git_name_email}, All Rights Reserved. 
 */


const tbData = [
    ['col01', 'col02', 'col03', 'col04', 'col05', 'col06', 'col07', 'col08', 'col09', 'col10', 'col11', 'col12', 'col13', 'col14'],
    ['tb01serti01', '2023-3-23 09:12:23', 'A001', '商品名001', 'NNS-001', 'KT-63222', 'NK000000002', 'H-0010001', '11', '文字1', '文字2', '文字3', '文字4', '文字5'],
    ['tb01serti02', '2023-3-16 08:15:24', 'A002', '商品名002', 'NNS-001', 'KT-63222', 'NK000000002', 'H-0010002', '9', '文字1', '文字2', '文字3', '文字4', '文字5'],
    ['tb01serti03', '2023-3-14 11:06:25', 'A001', '商品名001', 'NNS-001', 'SE-00652', 'NK000000002', 'H-0010003', '7', '文字1', '文字2', '文字3', '文字4', '文字5'],
    ['tb01serti04', '2023-3-12 21:04:26', 'A001', '商品名001', 'NNS-001', 'SE-00652', 'NK000000002', 'H-0010001', '25', '文字1', '文字2', '文字3', '文字4', '文字5'],
    ['tb01serti05', '2023-3-23 06:11:27', 'A005', '商品名005', 'NNS-002', 'KT-63222', 'NK000000002', 'H-0010002', '4', '文字1', '文字2', '文字3', '文字4', '文字5'],
    ['tb01serti06', '2023-3-11 08:17:28', 'A001', '商品名001', 'NNS-002', 'KT-63222', 'NK000000002', 'H-0010003', '35', '文字1', '文字2', '文字3', '文字4', '文字5'],
    ['tb01serti07', '2023-3-16 07:26:29', 'A005', '商品名005', 'NNS-002', 'AB-0003', 'NK000000002', 'H-0010001', '12', '文字1', '文字2', '文字3', '文字4', '文字5'],
    ['tb01serti08', '2023-3-20 19:32:30', 'A005', '商品名005', 'NNS-002', 'AB-0003', 'NK000000002', 'H-0010002', '2', '文字1', '文字2', '文字3', '文字4', '文字5'],
    ['tb01serti09', '2023-3-22 15:22:31', 'A009', '商品名009', 'NNS-003', 'AB-0003', 'NK000000009', 'H-0010003', '3', '文字1', '文字2', '文字3', '文字4', '文字5'],
    ['tb01serti10', '2023-3-17 08:42:32', 'A009', '商品名009', 'NNS-003', 'SE-00652', 'NK000000009', 'H-0010001', '7', '文字1', '文字2', '文字3', '文字4', '文字5'],
    ['tb01serti11', '2023-3-18 15:52:33', 'A002', '商品名002', 'NNS-003', 'SE-00652', 'NK000000009', 'H-0010002', '12', '文字1', '文字2', '文字3', '文字4', '文字5'],
    ['tb01serti12', '2023-3-23 21:47:34', 'A009', '商品名009', 'NNS-003', 'SE-00652', 'NK000000009', 'H-0010003', '35', '文字1', '文字2', '文字3', '文字4', '文字5'],
    ['tb01serti13', '2023-3-19 08:58:35', 'A001', '商品名001', 'NNS-003', 'KT-63222', 'NK000000009', 'H-0010001', '10', '文字1', '文字2', '文字3', '文字4', '文字5'],
    ['tb01serti14', '2023-3-18 10:32:36', 'A002', '商品名002', 'NNS-003', 'KT-63222', 'NK000000009', 'H-0010002', '8', '文字1', '文字2', '文字3', '文字4', '文字5'],
    ['tb01serti15', '2023-3-20 15:38:37', 'A009', '商品名009', 'NNS-003', 'AB-0003', 'NK000000009', 'H-0010003', '5', '文字1', '文字2', '文字3', '文字4', '文字5']
  ];
  
  const tbSetting =[
    ['col01', 'col02', 'col03', 'col04', 'col05', 'col06', 'col07', 'col08', 'col09', 'col10', 'col11', 'col12', 'col13', 'col14'],
    ['DataKey', '更新_日時', '商品コード', '商品名', '荷主_コード', '拠点_コード', '入荷_伝票_番号', '発注_番号', '数量', '在庫キー（文字1）', '在庫キー（文字2）', '在庫キー（文字3）', '在庫キー（文字4）', '在庫キー（文字5）'],
    ['varchar', 'timestamp', 'varchar', 'varchar', 'varchar', 'varchar', 'varchar', 'varchar', 'integer', 'varchar', 'varchar', 'varchar', 'varchar', 'varchar'],
    ['key', 'hide', 'visible', 'visible', 'visible', 'visible', 'hide', 'hide', 'visible', 'hide', 'hide', 'hide', 'hide', 'hide'],
    ['0', '', '1', '2', '4', '5', '', '', '3', '', '', '', '', ''],
    ['', '', '', '2D', '', '1A', '', '', '3D', '', '', '', '', '']
  ];

  
  function GetHVCols(arrParam, hideOrVisible) {

    let arrV = [];
    let ROW_COL = 0;
    let ROW_NAME = 1;
    let ROW_TYPE = 2;
    let ROW_VISIBLE = 3;
    let ROW_DISPORDER = 4;
    let ROW_SORT = 5;
    let k=0;

    // col01 -- col14
    for (i = 0; i < arrParam[0].length; i++) {

        let khv = arrParam[ROW_VISIBLE][i];
        if(khv === 'key'){khv ='visible';}
        //hideOrVisible = hide || visible
        if (khv===hideOrVisible)
        {
            arrV[k] = [];        
            arrV[k][0] = i;
            arrV[k][1] = arrParam[ROW_NAME][i];
            arrV[k][2] = arrParam[ROW_DISPORDER][i];    
            k++;
        }        
    }
    //console.log(arrV);

    let sortedArr = [...arrV].sort((a, b) => a[2] - b[2]);
    //console.log(sortedArr);
    return sortedArr;    
  }

  function GetSortCols(arrParam) {

    let arrS = [];
    let ROW_COL = 0;
    let ROW_NAME = 1;
    let ROW_TYPE = 2;
    let ROW_VISIBLE = 3;
    let ROW_DISPORDER = 4;
    let ROW_SORT = 5;
    let k=0;

    // col01 -- col14
    for (i = 0; i < arrParam[0].length; i++) {

        if (arrParam[ROW_SORT][i].trim().length === 0) {continue;}        
        arrS[k] = [];        
        arrS[k][0] = i;
        arrS[k][1] = arrParam[ROW_NAME][i];
        arrS[k][2] = arrParam[ROW_SORT][i].substring(0, 1);
        arrS[k][3] = arrParam[ROW_SORT][i].substring(1);
        arrS[k][4] = arrParam[ROW_TYPE][i]; 
        k++; 
    }
    //console.log(arrS);

    let sortedArr = [...arrS].sort(function(a, b) {
        return a[2].localeCompare(b[2], 'ja') // 'zh' 表示中文，可以根据需要替换成其他语言编码
    });
    //console.log(sortedArr);
    return sortedArr;    
  }


  //列排序  
  function GetDispTable2(arrParam) {
    //列变化
    const newArr = Array.from(arrParam, row => [row[2], row[1], row[0]]);
    console.log(newArr);
  }

  
  //指定顺序 列排序  
  function GetDispTable(arrParam, arrOrder) {    
    const vorderArr = [];
    for (let i = 1; i < arrParam.length; i++) {
      let row = [];  
      for (let j = 0; j < arrOrder.length; j++) {
        row.push(arrParam[i][arrOrder[j][0]]);
      }  
      vorderArr.push(row);
    }  
    return vorderArr;
  }


  // 按照第2列（商品编码）和第4列（数量）排序
// data.sort(function(a, b) {
//     if (a[1] < b[1]) {
//       return -1;
//     }
//     if (a[1] > b[1]) {
//       return 1;
//     }
//     if (a[3] < b[3]) {
//       return -1;
//     }
//     if (a[3] > b[3]) {
//       return 1;
//     }
//     return 0;
//   });

// [ [ 5, '拠点_コード', '1', 'A', 'varchar' ],
//   [ 3, '商品名', '2', 'D', 'varchar' ],
//   [ 8, '数量', '3', 'D', 'integer' ] ]

  //需要改进有BUG
  function sortMultiDimensionalArray(arrParam, arrSortSet) {
    let aaa = [...arrParam].sort(function(a, b) {        
      for (var i = 0; i < arrSortSet.length; i++) {
        var col = arrSortSet[i][0];
        var direction = 'asc';
        if(arrSortSet[i][3]==='A'){direction = 'asc';}
        if(arrSortSet[i][3]==='D'){direction = 'desc';}

        if (arrSortSet[i][4] === 'integer') {
            // integer 排序
            if (a[col] > b[col]) {
                return direction === 'asc' ? 1 : -1;
            } else if (a[col] < b[col]) {
                return direction === 'asc' ? -1 : 1;
            }          
        } else {
            // 使用 localeCompare() 方法比较字符串
            var result = a[col].localeCompare(b[col], 'ja');
            if (result !== 0) {
                return direction === 'asc' ? result : -result;
            }          
        }
      }
      return 0;
    });
    return aaa;
  }

  
  console.log(GetHVCols(tbSetting, 'hide'));

  console.log(GetHVCols(tbSetting, 'visible'));

  console.log(GetSortCols(tbSetting));


  let aa = GetDispTable(tbData, GetHVCols(tbSetting, 'visible'));
  console.log(aa);

  let bb = sortMultiDimensionalArray(aa, GetSortCols(tbSetting));
  console.log(bb);
