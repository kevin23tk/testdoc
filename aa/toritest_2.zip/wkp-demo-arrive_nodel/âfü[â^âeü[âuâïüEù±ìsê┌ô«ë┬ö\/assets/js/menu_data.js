 //　右上のハンバーガーメニュー
 $(".openbtn4").click(function () {
    $(this).toggleClass("active");
    $('#container').toggleClass('back-blur');
  });

 //　左上のハンバーガーメニュー 
 $(".openbtn1").click(function () {
    //ボタンがクリックされたら
    $(this).toggleClass("active"); //ボタン自身に activeクラスを付与し
  });
 

  
  //画面リサイズの後サイドバーメニューの表示設置
  
  const resize = ()=>{
   
    let timeoutID = 0;
    let delay = 500;
  
    window.addEventListener("resize", ()=>{
        clearTimeout(timeoutID);
        timeoutID = setTimeout(()=>{
  
            //ここにリサイズした後に実行したい処理を記述
            $(function () {
              if (window.matchMedia('(min-width: 992px)').matches) {
                $('#js-navbarNav').addClass("show");
              }
              else{
                $('#js-navbarNav').removeClass("show");
                $('#container').removeClass('back-blur');
              }   
            });
            console.log("resize");
  
        }, delay);
    }, false);
  };
  resize();
  
  
  
  //サイドメニュー　ドロップダウン
  
  $(function () {
    var Accordion = function (el, multiple) {
      this.el = el || {};
      this.multiple = multiple || false;
  
      // Variables privadas
      var links = this.el.find(".link");
      // Evento
      links.on("click", { el: this.el, multiple: this.multiple }, this.dropdown);
    };
  
    Accordion.prototype.dropdown = function (e) {
      var $el = e.data.el;
      ($this = $(this)), ($next = $this.next());
  
      $next.slideToggle();
      $this.parent().toggleClass("open");
  
      if (!e.data.multiple) {
        $el.find(".submenu").not($next).slideUp().parent().removeClass("open");
      }
    };
  
    var accordion = new Accordion($("#accordion"), false);
  });
  
  
  
  
  // 日時表示
  // timerID = setInterval('clock()',1000); //0.5秒毎にclock()を実行
  document.getElementById("view_today").innerHTML = getToday();
  function getToday() {
      var now = new Date();
      var year = now.getFullYear();
      var mon = now.getMonth()+1; //１を足すこと
      var day = now.getDate();
      var you = now.getDay(); //曜日(0～6=日～土)
  
      //曜日の選択肢
      var youbi = new Array("日","月","火","水","木","金","土");
      //出力用
      var s = year + "年" + mon + "月" + day + "日(" + youbi[you] + ") ";
      return s;
  }
  
  
  document.getElementById("view_time").innerHTML = getNow();
  function getNow() {
      var now = new Date();
      var hour = now.getHours();
      var min = now.getMinutes();
	  var sec = now.getSeconds();

	//出力用
	var s =  hour + ":" + min + ":" + sec; 
	return s;
  }

// 共通パーツ設定//

// head部分//
document.head.insertAdjacentHTML('afterbegin',`
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
<link rel="stylesheet" href="assets/css/layout.css"/>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous"/>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css" />
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.0/font/bootstrap-icons.css">


`);

// header,sidebar,footer部分//
$(function () {
   $('#header').load('header.html'); // #headerにheader.htmlを読み込む
    $('#sidebar').load('sidebar.html'); // #sidebarにsidebar.htmlを読み込む
    $('#footer').load('footer.html'); // #footerにfooter.htmlを読み込む
});
