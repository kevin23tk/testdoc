'use strict';

$(function () {
  $("#myTable").DataTable({
    "language": {
      "url": "//cdn.datatables.net/plug-ins/1.10.22/i18n/Japanese.json"
    }
  });
});

// ヘッダーの高さ分だけコンテンツを下げる
//$(function () {
//const height = $("header").height();
//$("main").css("margin-top", height);
//});

$(function(){
  $('.section').hide();
  $('.home-img').hide();

  $('.secList').on('click',function(){
    $(this).addClass('menu-click');
    $('.secList').not($(this)).removeClass('menu-click');    
    // クリックした要素の ID と違うクラス名のセクションを非表示
    $('.section').not($('.'+$(this).attr('id'))).hide();
    // toggle にすると、同じボタンを 2 回押すと非表示になる
    $('.'+$(this).attr('id')).toggle();
   $('.home-img').hide();
  });

  $('.round_btn').on('click',function(){
    $('.section').hide();
    $('.secList').removeClass('menu-click'); 
  });

  $('#home').on('click',function(){
    $('.home-img').toggle();
  });
});