 var swiper = new Swiper(".mySwiper", {
      slidesPerView: 1,
      spaceBetween: 20,
      pagination: {
        el: ".swiper-pagination",
        clickable: true,
      },
      breakpoints: {
        380: {
          slidesPerView: 4,
          spaceBetween: 5,
        },
        680: {
          slidesPerView: 6,
          spaceBetween: 10,
        },
        980: {
          slidesPerView: 9,
          spaceBetween: 10,
        },
        1280: {
          slidesPerView: 12,
          spaceBetween: 10,
        },
        1680: {
          slidesPerView: 16,
          spaceBetween: 10,
        },
        1980: {
          slidesPerView: 18,
          spaceBetween: 10,
        },
      },
      watchSlidesProgress: true,
            navigation: {
                nextEl: ".swiper-button-next",
                prevEl: ".swiper-button-prev",
            },
        });